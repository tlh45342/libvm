#include <stdint.h>
#include <stdbool.h>
#include "cpu.h"
#include "cpu_flags.h"
#include "shifter.h"
#include "alu.h"
#include "cond.h"      // <-- add this

#ifndef CPU_GPR
#define CPU_GPR cpu.r
#endif

extern debug_flags_t debug_flags;

// -------------------- Per-op handlers (flags set inline) --------------------

// ---------------------------------------------------------------------------
// AND / ANDS (register or immediate)
// ---------------------------------------------------------------------------
void handle_and(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR)
            log_printf("[AND] cond fail (0x%X) -> not taken\n", cond);
        return;
    }

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;
    bool     I  = (instr >> 25) & 1u;

    uint32_t op2, sh_carry;
    if (I) {
        // rotated immediate
        uint32_t imm8 = instr & 0xFFu;
        uint32_t rot  = ((instr >> 8) & 0xFu) * 2u;
        op2 = (imm8 >> rot) | (imm8 << (32u - rot));
        sh_carry = (rot ? (op2 >> 31) & 1u : ((cpu.cpsr >> 29) & 1u));
    } else {
        op2 = dp_operand2(instr, &sh_carry);
    }

    uint32_t lhs = cpu.r[Rn];
    uint32_t res = lhs & op2;
    cpu.r[Rd] = res;

    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry);
    }

    if (debug_flags & DBG_INSTR) {
        if (I) {
            log_printf("[AND imm] r%u = r%u (0x%08X) & 0x%08X => 0x%08X\n",
                       Rd, Rn, lhs, op2, res);
        } else if (S) {
            log_printf("[AND regs] r%u = r%u (0x%08X) & r%u (0x%08X) => 0x%08X\n",
                       Rd, Rn, lhs, instr & 0xFu, cpu.r[instr & 0xFu], res);
        } else {
            log_printf("[AND reg] r%u = r%u (0x%08X) & r%u (0x%08X) => 0x%08X\n",
                       Rd, Rn, lhs, instr & 0xFu, cpu.r[instr & 0xFu], res);
        }
    }
    return;
}

// ---- ADD ----
void handle_add(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint64_t sum = (uint64_t)a + (uint64_t)op2;
    uint32_t res = (uint32_t)sum;

    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sum >> 32);                                   // carry-out
        int overflow = (~(a ^ op2) & (a ^ res) & 0x80000000u) != 0;   // signed overflow
        cpsr_set_V(overflow);
    }
}

// ---- EOR ----
void handle_eor(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = a ^ op2;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry);
        // V unchanged for logical ops
    }
}

// ---- MVN ----
void handle_mvn(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);

    uint32_t res = ~op2;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry);
    }
}

// ---- CMP ----
void handle_cmp(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = a - op2;
    cpsr_set_NZ(res);
    cpsr_set_C_from(a >= op2);
    int overflow = ((a ^ op2) & (a ^ res) & 0x80000000u) != 0;
    cpsr_set_V(overflow);
}

// ---- TST ----
void handle_tst(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = a & op2;
    cpsr_set_NZ(res);
    cpsr_set_C_from(sh_carry);
}

// ---- TEQ ----
void handle_teq(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = a ^ op2;
    cpsr_set_NZ(res);
    cpsr_set_C_from(sh_carry);
}

// ---- CMN ----
void handle_cmn(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = a + op2;
    cpsr_set_NZ(res);
    cpsr_set_C_from(res < a);
    int overflow = (~(a ^ op2) & (a ^ res) & 0x80000000u) != 0;
    cpsr_set_V(overflow);
}

// ---- SUB ----  Rd = Rn - op2
void handle_sub(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    (void)dp_operand2; // keeping symmetry with others; we still use it for shifts/imm
    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = a - op2;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(a >= op2);                           // NOT borrow
        int overflow = ((a ^ op2) & (a ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// ---- RSB ----  Rd = op2 - Rn
void handle_rsb(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t res = op2 - a;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(op2 >= a);                           // NOT borrow (op2 - a)
        int overflow = ((op2 ^ a) & (op2 ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// ---- ADC ----  Rd = Rn + op2 + C
void handle_adc(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t cin      = cpsr_get_C();
    uint64_t sum      = (uint64_t)a + (uint64_t)op2 + (uint64_t)cin;
    uint32_t res      = (uint32_t)sum;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sum >> 32);                           // carry out
        uint32_t b = op2 + cin;
        int overflow = (~(a ^ b) & (a ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// ---- SBC ----  Rd = Rn - op2 - (1 - C)
void handle_sbc(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t cin     = cpsr_get_C();
    uint32_t borrow  = 1u - (cin & 1u);
    uint64_t diff    = (uint64_t)a - (uint64_t)op2 - (uint64_t)borrow;
    uint32_t res     = (uint32_t)diff;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from((diff >> 32) == 0);                  // no borrow -> C=1
        uint32_t btot = op2 + borrow;
        int overflow = ((a ^ btot) & (a ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// ---- RSC ----  Rd = op2 - Rn - (1 - C)
void handle_rsc(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = cpu.r[rn];

    uint32_t cin     = cpsr_get_C();
    uint32_t borrow  = 1u - (cin & 1u);
    uint64_t diff    = (uint64_t)op2 - (uint64_t)a - (uint64_t)borrow;
    uint32_t res     = (uint32_t)diff;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from((diff >> 32) == 0);                  // no borrow -> C=1
        uint32_t atot = a + borrow;
        int overflow = ((op2 ^ atot) & (op2 ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}