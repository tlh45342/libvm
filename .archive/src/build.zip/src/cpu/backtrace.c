#include <string.h>
#include "backtrace.h"
#include "cpu.h"
#include "log.h"

static uint32_t bt_stack[CPU_MAX_BACKTRACE];
static int      bt_depth = 0;

void cpu_bt_push(uint32_t lr) {
    if (bt_depth < CPU_MAX_BACKTRACE) {
        bt_stack[bt_depth++] = lr;
    } else {
        memmove(&bt_stack[0], &bt_stack[1], (CPU_MAX_BACKTRACE-1) * sizeof(uint32_t));
        bt_stack[CPU_MAX_BACKTRACE-1] = lr;
    }
}
void cpu_bt_pop(void) { if (bt_depth > 0) bt_depth--; }
int  cpu_bt_depth(void) { return bt_depth; }
uint32_t cpu_bt_frame(int i) { return (i >= 0 && i < bt_depth) ? bt_stack[i] : 0; }
void cpu_dump_backtrace(void) {
    log_printf("Backtrace (%d calls):\n", bt_depth);
    for (int i = bt_depth - 1; i >= 0; i--) {
        log_printf("  #%d 0x%08x\n", i, bt_stack[i]);
    }
}