// src/cpu/branch.c
#include <stdint.h>
#include <stdbool.h>

#include "cpu.h"     // CPU cpu
#include "log.h"
#include "cond.h"    // evaluate_condition()

extern debug_flags_t debug_flags;

// ---- B (Branch) ----
bool handle_b(uint32_t instr) {
    // condition
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR) log_printf("[B] cond fail (0x%X) -> not taken\n", cond);
        return true;  // stepper will advance +4
    }

    uint32_t A = cpu.r[15];  // address of current instruction
    // Signed (imm24 << 2) with sign-extension: ((imm24 << 8) >> 6)
    int32_t  imm24  = (int32_t)(instr & 0x00FFFFFFu);
    int32_t  offset = (imm24 << 8) >> 6;
    uint32_t target = (uint32_t)(A + 8) + (uint32_t)offset;

    if (debug_flags & DBG_INSTR)
        log_printf("[B] A=0x%08X base=0x%08X off=%d -> target=0x%08X\n",
                   A, A + 8, offset, target);

    cpu.r[15] = target;   // write PC; stepper must NOT add +4
    return true;
}

// ---- BL (Branch with Link) ----
bool handle_bl(uint32_t instr) {
    // condition
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR) log_printf("[BL] cond fail (0x%X) -> not taken\n", cond);
        return true;  // stepper will advance +4
    }

    uint32_t A = cpu.r[15];  // address of current instruction
    // Signed (imm24 << 2) with sign-extension
    int32_t  imm24  = (int32_t)(instr & 0x00FFFFFFu);
    int32_t  offset = (imm24 << 8) >> 6;

    uint32_t LR     = A + 4;                      // return to next instruction
    uint32_t target = (uint32_t)(A + 8) + (uint32_t)offset;

    cpu.r[14] = LR;
    cpu.r[15] = target;

    if (debug_flags & DBG_INSTR) {
        log_printf("[BL] A=0x%08X LR<=0x%08X base=0x%08X imm24=0x%06X off=%d -> target=0x%08X\n",
                   A, LR, A + 8, (unsigned)(instr & 0x00FFFFFFu), offset, target);
    }
    return true;
}

// ---- BX (Branch and Exchange) ----
bool handle_bx(uint32_t instr) {
    // condition
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR) log_printf("[BX] cond fail (0x%X) -> not taken\n", cond);
        return true;  // stepper will advance +4
    }

    uint32_t rm   = instr & 0xF;
    uint32_t addr = cpu.r[rm];

    if (debug_flags & DBG_INSTR) log_printf("[BX] r%u => 0x%08X\n", rm, addr);

    // If bit0==1, that’s a request to enter Thumb; you can log and ignore for now.
    if (addr & 1u) {
        if (debug_flags & DBG_INSTR)
            log_printf("[BX] Thumb request (addr bit0=1) -> continuing in ARM; target=0x%08X\n",
                       addr & ~1u);
        // TODO: set CPSR.T if/when Thumb is implemented.
    }

    cpu.r[15] = addr & ~1u;   // align; write PC; no +4 by stepper
    return true;
}
