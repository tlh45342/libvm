//src/cpu/cpu.c

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <string.h>
#include "log.h"      // log_printf prototype
#include "cpu.h"
#include "mem.h"
#include "hw.h"
#include "execute.h"
#include "backtrace.h"
#include <debug.h>

extern bool trace_all;
extern debug_flags_t debug_flags;

CPU cpu = {0};
uint64_t cycle = 0;
static bool g_cpu_halted = false;

// Forward decl to avoid implicit declaration/conflict
void cpu_halt(void)       { g_cpu_halted = true; }
void cpu_clear_halt(void) { g_cpu_halted = false; }
bool cpu_is_halted(void)  { return g_cpu_halted; }

// -----------------------------------------------------------------------------
// Small utilities
// -----------------------------------------------------------------------------

int execute_one_instruction(void) {
    if (cpu_is_halted()) return 0;

    // Remember the PC before executing
    uint32_t pc    = cpu.r[15];
    uint32_t instr = cpu_fetch();

    bool ok = execute(instr);

    if (cpu_is_halted()) return 0;

    // If execute() didn’t write a new PC (i.e. not a branch),
    // then advance to the next instruction
    if (cpu.r[15] == pc) {
        cpu.r[15] = pc + 4;
    }

    return ok ? 1 : 0;  // VM tracks cycles now
}

uint32_t cpu_fetch(void) {
    uint32_t pc = cpu.r[15];

    if (cpu.cpsr & CPSR_T) {
        log_printf("[WARN] CPSR.T=1 (Thumb) but VM runs in ARM state; clearing T.\n");
        cpu.cpsr &= ~CPSR_T;
    }

#if defined(CPU_STRICT_FETCH)
    if (pc & 3u) {
        log_printf("[ERROR] Unaligned instruction fetch at 0x%08X\n", pc);
        cpu_dump_backtrace();
        cpu_halt();
        return 0xE7F001F0u; // UDF pattern
    }
#endif

    // Range check using the *currently bound* memory
    size_t msz = mem_size();
    if (!mem_is_bound() || msz < 4 || pc > (uint32_t)(msz - 4)) {
        log_printf("[ERROR] PC out of range: 0x%08X (mem_size=%zu, bound=%d)\n",
                   pc, msz, mem_is_bound());
        cpu_dump_backtrace();
        cpu_halt();
        return 0xDEADDEADu;
    }

    uint32_t instr = mem_read32(pc);
    return instr;
}

void cpu_dump_registers() {
    log_printf("Registers:\n");
    for (int i = 0; i < 16; i++) {
        log_printf("r%-2d = 0x%08x  ", i, cpu.r[i]);
        if ((i + 1) % 4 == 0) log_printf("\n");
    }
}


// -----------------------------------------------------------------------------

void cpu_step(void) {
    int cycles = execute_one_instruction();
    if (cycles <= 0) cycles = 1;
    hw_bus_tick(cycles);
    // IRQ handling would go here later
}