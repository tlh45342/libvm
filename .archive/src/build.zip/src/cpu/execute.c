// src/cpu/execute.c

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stddef.h>  // for size_t used in the K12 loop

#include "cpu.h"        // CPU, extern CPU cpu; debug_flags_t, extern debug_flags
#include "log.h"        // log_printf
#include "cond.h"       // evaluate_condition()
#include "shifter.h"    // ror32(), dp_operand2()

// handlers split by area
#include "alu.h"        // handle_AND/EOR/.../MVN (uniform 5-arg signature)
#include "branch.h"     // handle_b(), handle_bl(), handle_bx()
#include "system.h"     // DSB/DMB/ISB, SVC, MRS/MSR, SETEND, CPS, NOP/WFI
#include "logic.h"      // MOVW/MOVT/MOV imm (non-DP fast paths if you keep them)
#include "memops.h"     // LDR/STR/byte forms, LDM/STM, POP, etc.

#include "execute.h"    // bool execute(uint32_t instr)

// --- key12 bits
static inline uint16_t key12(uint32_t instr) {
    uint32_t op1 = (instr >> 25) & 0x7;   // bits 27:25
    uint32_t op2 = (instr >> 20) & 0x1F;  // bits 24:20
    uint32_t op3 = (instr >>  4) & 0x0F;  // bits  7:4
    return (uint16_t)((op1 << 9) | (op2 << 4) | op3);
}

typedef void (*insn_handler_t)(uint32_t instr);

typedef struct {
    uint16_t      mask12;       // mask for key12
    uint16_t      value12;      // value for key12
    uint32_t      xmask32;      // OPTIONAL extra disambiguation (0 = none)
    uint32_t      xvalue32;     // value for xmask32
    bool          check_cond;   // apply ARM cond? (false for DEADBEEF)
    insn_handler_t fn;
    const char*   name;
} k12_entry;

// -------------------------------------------

// --- key12 constants used in the table
#define K12_BX_VALUE   ((0u << 9) | (0x12u << 4) | 0x1u)  // BX exact key = 0x121

// ----------------------------------------

// Mask helpers for DP class (class 00, ignore I and S)
// key12 layout: [11:9]=op1 (bits27:25), [8:4]=op2 (bits24:20), [3:0]=op3 (bits7:4)
#define K12_MASK_OP1_TOP2   0x0C00u      // match bits27:26 == 00
#define K12_MASK_OP2_OPCODE 0x01E0u      // match bits24:21 (opcode), ignore S (bit20)
#define K12_MASK_DP_OPCODE (K12_MASK_OP1_TOP2 | K12_MASK_OP2_OPCODE)  // 0x0DE0

static const k12_entry K12_TABLE[] = {
    // ---- Specific cases first (to avoid being shadowed) ----
    { 0x0F50u, 0x0510u, 0x0C1F0000u, 0x041F0000u, true,  handle_ldr_literal, "LDR(literal)" },

    // ---- DP (register) class: mask ignores I(25) and S(20) ----
    { 0x0DE0u, 0x0000u, 0, 0, true, handle_and, "AND" }, // opcode 0000
    { 0x0DE0u, 0x0020u, 0, 0, true, handle_eor, "EOR" }, // 0001
    { 0x0DE0u, 0x0040u, 0, 0, true, handle_sub, "SUB" }, // 0010
    { 0x0DE0u, 0x0060u, 0, 0, true, handle_rsb, "RSB" }, // 0011
    { 0x0DE0u, 0x0080u, 0, 0, true, handle_add, "ADD" }, // 0100
    { 0x0DE0u, 0x00A0u, 0, 0, true, handle_adc, "ADC" }, // 0101
    { 0x0DE0u, 0x00C0u, 0, 0, true, handle_sbc, "SBC" }, // 0110
    { 0x0DE0u, 0x00E0u, 0, 0, true, handle_rsc, "RSC" }, // 0111
    { 0x0DE0u, 0x0100u, 0, 0, true, handle_tst, "TST" }, // 1000
    { 0x0DE0u, 0x0120u, 0, 0, true, handle_teq, "TEQ" }, // 1001
    { 0x0DE0u, 0x0140u, 0, 0, true, handle_cmp, "CMP" }, // 1010
    { 0x0DE0u, 0x0160u, 0, 0, true, handle_cmn, "CMN" }, // 1011
    { 0x0DE0u, 0x0180u, 0, 0, true, handle_orr, "ORR" }, // 1100
    { 0x0DE0u, 0x01A0u, 0, 0, true, handle_mov, "MOV" }, // 1101
    { 0x0DE0u, 0x01C0u, 0, 0, true, handle_bic, "BIC" }, // 1110
    { 0x0DE0u, 0x01E0u, 0, 0, true, handle_mvn, "MVN" }, // 1111

    // ---- Wide moves (must precede generic DP-imm) ----
    { 0x0F00u, 0x0300u, 0x0FF00000u, 0x03000000u, true, handle_movw,    "MOVW" },
    { 0x0F00u, 0x0340u, 0x0FF00000u, 0x03400000u, true, handle_movt,    "MOVT" },

    // ---- DP (immediate) class (I=1) ----
    { 0x0FE0u, 0x0200u, 0, 0, true, handle_and,    "AND (imm)" },
    { 0x0FE0u, 0x0310u, 0, 0, true, handle_tst_imm,"TST (imm)" }, // you already have a dedicated handler
    { 0x0FE0u, 0x0350u, 0, 0, true, handle_cmp_imm,"CMP (imm)" }, // important: 0x35x, not 0x34x
    { 0x0FE0u, 0x0330u, 0, 0, true, handle_teq,    "TEQ (imm)" },
    { 0x0FE0u, 0x0370u, 0, 0, true, handle_cmn,    "CMN (imm)" },
    { 0x0FE0u, 0x0380u, 0, 0, true, handle_orr,    "ORR (imm)" },
    { 0x0FE0u, 0x03A0u, 0, 0, true, handle_mov_imm,"MOV (imm)" }, // your fast-path MOV imm
    { 0x0FE0u, 0x03C0u, 0, 0, true, handle_bic,    "BIC (imm)" },
    { 0x0FE0u, 0x03E0u, 0, 0, true, handle_mvn,    "MVN (imm)" },

    // ---- Single data transfer (common forms you use) ----
    { 0x0F50u, 0x0510u, 0, 0, true, handle_ldr_preimm,   "LDR  pre-imm" },
    { 0x0F50u, 0x0500u, 0, 0, true, handle_str_preimm,   "STR  pre-imm" },
    { 0x0F50u, 0x0540u, 0, 0, true, handle_strb_preimm,  "STRB pre-imm" },
    { 0x0F50u, 0x0550u, 0, 0, true, handle_ldrb_preimm,  "LDRB pre-imm" },
    { 0x0F50u, 0x0440u, 0, 0, true, handle_strb_postimm, "STRB(post,imm)" },
    { 0x0F50u, 0x0410u, 0, 0, true, handle_ldr_postimm,  "LDR (post,imm)" },
    { 0x0F70u, 0x0400u, 0, 0, true, handle_str_postimm,  "STR (post,imm)" },
    { 0x0F70u, 0x0450u, 0, 0, true, handle_ldrb_postimm, "LDRB post-imm"    }, // W=0
    { 0x0F70u, 0x0470u, 0, 0, true, handle_ldrb_postimm, "LDRB post-imm W"  }, // W=1
    { 0x0E50u, 0x0610u, 0, 0, true, handle_ldr_regoffset,"LDR reg-offset"   },

    // ---- LDRB (register) split by shift exact vs general ----
    { 0x0F7Fu, 0x0750u, 0, 0, true, handle_ldrb_reg,       "LDRB reg pre LSL#0" },
    { 0x0F71u, 0x0750u, 0, 0, true, handle_ldrb_reg_shift, "LDRB reg imm-shift" },

    // ---- Stack-ish specials ----
    { 0x0FF0u, 0x0520u, 0x000F0000u, 0x000D0000u, true, handle_str_predec, "STR(pre-dec SP,imm)" },
    { 0x0FFFu, 0x0490u, 0x0FFFF000u, 0x049DF000u, true, handle_pop_pc,     "POP{..,pc}" },

    // ---- Block transfers ----
    { 0x0E10u, 0x0800u, 0, 0, true, handle_stm, "STM" }, // L=0
    { 0x0E10u, 0x0810u, 0, 0, true, handle_ldm, "LDM" }, // L=1

    // ---- Branch family ----
    { 0x0FFFu, 0x0121u, 0, 0, true, handle_bx, "BX" },
    { 0x0F00u, 0x0A00u, 0, 0, true, handle_b,  "B"  },
    { 0x0F00u, 0x0B00u, 0, 0, true, handle_bl, "BL" },

    // ---- System / exact 32-bit patterns ----
    { 0x0F00u, 0x0F00u, 0x0F000000u, 0x0F000000u, true,  handle_svc, "SVC" },
    { 0x0FBFu, 0x0100u, 0x0FBF0FFFu, 0x010F0000u, true,  handle_mrs, "MRS" },
    { 0x0FFFu, 0x0574u, 0xFFFFFFFFu, 0xF57FF04Fu, false, handle_dsb, "DSB" },
    { 0x0FFFu, 0x0575u, 0xFFFFFFFFu, 0xF57FF05Fu, false, handle_dmb, "DMB" },
    { 0x0FFFu, 0x0576u, 0xFFFFFFFFu, 0xF57FF06Fu, false, handle_isb, "ISB" },
    { 0x0FFFu, 0x0320u, 0xFFFFFFFFu, 0xE320F000u, false, handle_nop, "NOP" },
    { 0x0FFFu, 0x0320u, 0xFFFFFFFFu, 0xE320F003u, false, handle_wfi, "WFI" },

    // ---- Doubleword transfers ----
    { 0x00Fu,  0x00Fu,  0x00500000u, 0x00500000u, true, exec_ldrd_imm, "LDRD(imm)" }, // I=1,L=1
    { 0x00Fu,  0x00Fu,  0x00500000u, 0x00100000u, true, exec_ldrd_reg, "LDRD(reg)" }, // I=0,L=1
    { 0x00Fu,  0x00Fu,  0x00500000u, 0x00400000u, true, exec_strd_imm, "STRD(imm)" }, // I=1,L=0
    { 0x00Fu,  0x00Fu,  0x00500000u, 0x00000000u, true, exec_strd_reg, "STRD(reg)" }, // I=0,L=0

    // ---- Easter egg / halt ----
    { 0x0FFFu, 0x0EAEu, 0xFFFFFFFFu, 0xDEADBEEFu, false, handle_deadbeef, "DEADBEEF" },
};

static inline bool try_decode_key12(uint32_t instr) {
    uint16_t k = key12(instr);

    for (size_t i = 0; i < sizeof(K12_TABLE)/sizeof(K12_TABLE[0]); ++i) {
        const k12_entry *e = &K12_TABLE[i];

        // 12-bit match
        if ((k & e->mask12) != e->value12) continue;

        // optional 32-bit disambiguation
        if (e->xmask32 && ((instr & e->xmask32) != e->xvalue32)) continue;

        // per-entry condition handling
        if (e->check_cond) {
            uint8_t cond = (instr >> 28) & 0xF;
            if (cond != 0xF && !evaluate_condition(cond)) {
                if (debug_flags & DBG_K12)
                    log_printf("[K12] %s cond fail (0x%X)\n", e->name, cond);
                return true; // decoded but skipped
            }
        }

        if (debug_flags & DBG_K12)
            log_printf("[K12] %s match (key=0x%03X)\n", e->name, k);

        // Call handler (ignore return type)
        e->fn(instr);

        return true; // handled
    }
    return false; // no match
}

// -----------------------------------------------------------------------------
// Main single-step executor
// -----------------------------------------------------------------------------
bool execute(uint32_t instr) {
    uint32_t pc = cpu.r[15];

    if (debug_flags & DBG_TRACE) {
        log_printf("[TRACE] PC=0x%08X Instr=0x%08X\n", pc, instr);
    }

	if (debug_flags & DBG_K12) {
		uint16_t k = key12(instr);
		log_printf("[K12] key=0x%03X op1=%u op2=%u op3=%u\n",
				   k, (instr>>25)&7, (instr>>20)&31, (instr>>4)&15);
	}

    // Try the key12 mini-table first (covers BX, B, BL)
    if (try_decode_key12(instr)) return true;

     // Unknown
    log_printf("[ERROR] Unknown instruction: 0x%08X at PC=0x%08X\n", instr, pc);
    uint32_t op = (instr >> 24) & 0xF;
    uint32_t subop = (instr >> 20) & 0xF;
    log_printf("  [Not matched] op=0x%X subop=0x%X\n", op, subop);
    cpu_halt();
    return false;
}
