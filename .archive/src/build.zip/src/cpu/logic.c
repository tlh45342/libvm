// src/cpu/logic.c
#include <stdint.h>
#include <stdbool.h>
#include "cpu.h"
#include "cpu_flags.h"
#include "shifter.h"
#include "cond.h"
#include "logic.h"

extern CPU cpu;

// ------------------------------- helpers -------------------------------
// none required — everything is inlined per your new style

// ------------------------------- ORR -------------------------------
// Rd = Rn | op2 ; flags (N,Z,C from shifter) if S=1
void handle_orr(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t res = cpu.r[rn] | op2;

    cpu.r[rd] = res;
    if (s) { cpsr_set_NZ(res); cpsr_set_C_from(sh_carry); }
}

// ------------------------------- BIC -------------------------------
// Rd = Rn & ~op2 ; flags if S=1
void handle_bic(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t res = cpu.r[rn] & ~op2;

    cpu.r[rd] = res;
    if (s) { cpsr_set_NZ(res); cpsr_set_C_from(sh_carry); }
}

// ------------------------------- AND imm/reg fast paths -------------------------------
// Rd = Rn & op2 ; flags if S=1
void handle_and_imm_dp(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t res = cpu.r[rn] & op2;

    cpu.r[rd] = res;
    if (s) { cpsr_set_NZ(res); cpsr_set_C_from(sh_carry); }
}

void handle_and_reg_simple(uint32_t instr) {
    // Same implementation; dp_operand2() will resolve reg-with-shift form.
    handle_and_imm_dp(instr);
}

// ------------------------------- TST imm/reg -------------------------------
// flags = Rn & op2 (always set flags; no writeback)
void handle_tst_imm(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t res = cpu.r[rn] & op2;

    cpsr_set_NZ(res);
    cpsr_set_C_from(sh_carry);
}

void handle_tst_reg(uint32_t instr) {
    handle_tst_imm(instr);
}

// ------------------------------- CMP reg/imm -------------------------------
// flags = Rn - op2 (always set flags; no writeback)
void handle_cmp_reg(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t a   = cpu.r[rn];

    uint32_t res = a - op2;
    cpsr_set_NZ(res);
    cpsr_set_C_from(a >= op2);                                  // NOT borrow
    int overflow = ((a ^ op2) & (a ^ res) & 0x80000000u) != 0;
    cpsr_set_V(overflow);
}

void handle_cmp_imm(uint32_t instr) {
    handle_cmp_reg(instr);
}

// ------------------------------- MOV (DP; reg or imm via dp_operand2) -------------------------------
// Rd = op2 ; flags if S=1
void handle_mov(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);

    cpu.r[rd] = op2;
    if (s) { cpsr_set_NZ(op2); cpsr_set_C_from(sh_carry); }
}

// ------------------------------- RSB (imm fast path) -------------------------------
// Rd = op2 - Rn ; flags if S=1
void handle_rsb_imm(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t s  = (instr >> 20) & 1u;
    uint32_t rn = (instr >> 16) & 0xFu;
    uint32_t rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t a   = cpu.r[rn];

    uint32_t res = op2 - a;
    cpu.r[rd] = res;
    if (s) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(op2 >= a);                              // NOT borrow
        int overflow = ((op2 ^ a) & (op2 ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// ------------------------------- CMN (imm fast path) -------------------------------
// flags = Rn + op2 (always set flags)
void handle_cmn_imm(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t a   = cpu.r[rn];

    uint32_t res = a + op2;
    cpsr_set_NZ(res);
    cpsr_set_C_from(res < a);                                   // carry out
    int overflow = (~(a ^ op2) & (a ^ res) & 0x80000000u) != 0;
    cpsr_set_V(overflow);
}

// ------------------------------- MOVW / MOVT / MOV(imm fast path) -------------------------------
// MOVW: Rd = imm16 (zero-extend)
void handle_movw(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rd    = (instr >> 12) & 0xFu;
    uint32_t imm4  = (instr >> 16) & 0xFu;      // bits 19:16
    uint32_t imm12 =  instr        & 0xFFFu;    // bits 11:0
    uint32_t imm16 = (imm4 << 12) | imm12;

    cpu.r[rd] = imm16;                           // upper 16 bits cleared
}

// MOVT: Rd[31:16] = imm16 ; Rd[15:0] preserved
void handle_movt(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t rd    = (instr >> 12) & 0xFu;
    uint32_t imm4  = (instr >> 16) & 0xFu;
    uint32_t imm12 =  instr        & 0xFFFu;
    uint32_t imm16 = (imm4 << 12) | imm12;

    cpu.r[rd] = (cpu.r[rd] & 0x0000FFFFu) | (imm16 << 16);
}

// MOV (imm fast path): identical semantics to DP MOV
void handle_mov_imm(uint32_t instr) {
    // Just reuse handle_mov; dp_operand2 will decode the immediate form
    handle_mov(instr);
}
