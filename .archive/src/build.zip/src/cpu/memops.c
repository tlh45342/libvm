// memops.c
#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>

#include "cpu.h"      // CPU + extern CPU cpu, debug_flags, trace_all
#include "mem.h"      // mem_read8/32, mem_write8/32
#include "log.h"      // log_printf
#include "memops.h"   // prototypes
#include "debug.h"
#include "cond.h"   // for evaluate_condition()

void handle_str_postimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t imm = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint32_t val  = cpu.r[rd];

    mem_write32(addr, val);
    cpu.r[rn] = addr + imm;

    if (debug_flags & DBG_INSTR)
        log_printf("  [STR post-imm] mem[0x%08X] <= r%d (0x%08X); r%d += 0x%X\n",
                   addr, rd, val, rn, imm);
    return;
}

void handle_ldrb_reg(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t addr = cpu.r[rn];
    uint8_t byte = mem_read8(addr);
    cpu.r[rd] = byte;
    if (trace_all || (debug_flags & DBG_MEM_READ))
        log_printf("[LDRB reg] r%d = mem8[0x%08X] => 0x%02X\n", rd, addr, byte);
    return;
}

void handle_strb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    bool up  = (instr >> 23) & 1u;
    bool pre = (instr >> 24) & 1u;

    uint32_t addr = cpu.r[rn];
    if (pre) addr = up ? addr + offset : addr - offset;

    uint8_t val = (uint8_t)(cpu.r[rd] & 0xFFu);
    mem_write8(addr, val);

    if (debug_flags & DBG_INSTR)
        log_printf("[STRB pre-%s imm] mem[0x%08X] <= r%d (0x%02X)\n",
                   up ? "inc" : "dec", addr, rd, val);
    return;
}

void handle_stm(uint32_t instr) {
    uint32_t rn      = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back  = ((instr >> 21) & 1u) != 0;
    uint32_t base    = cpu.r[rn];

    int count = __builtin_popcount(reglist);
    uint32_t addr = base - count * 4;  // STMDB/STMFD

    for (int i = 0; i < 16; i++) {
        if (reglist & (1u << i)) {
            uint32_t value = cpu.r[i];
            if (debug_flags & DBG_MEM_WRITE)
                log_printf("[STR] mem[0x%08x] <= 0x%08x\n", addr, value);
            mem_write32(addr, value);
            addr += 4;
        }
    }
    if (write_back) cpu.r[rn] = base - count * 4;
    return;
}

void handle_ldm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back = (instr >> 21) & 1u;
    uint32_t addr = cpu.r[rn];

    for (int i = 0; i < 16; i++) {
        if (reglist & (1u << i)) {
            uint32_t val = mem_read32(addr);
            cpu.r[i] = val;
            if (debug_flags & DBG_MEM_READ)
                log_printf("[LDM] r%d <= mem[0x%08X] => 0x%08X\n", i, addr, val);
            addr += 4;
        }
    }
    if (write_back) cpu.r[rn] = addr;
    return;
}

void handle_strb_postimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint8_t  byte = (uint8_t)(cpu.r[rd] & 0xFFu);
    mem_write8(addr, byte);
    cpu.r[rn] += offset;

    if (debug_flags & DBG_INSTR)
        log_printf("[STRB post-imm] mem[0x%08X] <= r%d (0x%02X); r%d += 0x%X\n",
                   addr, rd, byte, rn, offset);
    return;
}

void handle_str_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    bool up  = (instr >> 23) & 1u;
    bool pre = (instr >> 24) & 1u;

    uint32_t addr = cpu.r[rn];
    if (pre) addr = up ? addr + offset : addr - offset;

    mem_write32(addr, cpu.r[rd]);

    if (debug_flags & DBG_INSTR)
        log_printf("[STR pre-%s imm] mem[0x%08X] <= r%d (0x%08X)\n",
                   up ? "inc" : "dec", addr, rd, cpu.r[rd]);
    return;
}

void handle_str_predec(uint32_t instr) {
    int rd = (instr >> 12) & 0xF;
    int rn = (instr >> 16) & 0xF;
    uint32_t offset = instr & 0xFFF;
    cpu.r[rn] -= offset;
    mem_write32(cpu.r[rn], cpu.r[rd]);
    if (debug_flags & DBG_INSTR)
        log_printf("[STR pre-dec] mem[0x%08X] <= r%d (0x%08X)\n", cpu.r[rn], rd, cpu.r[rd]);
    return;
}

void handle_ldr_literal(uint32_t instr)
{
    // Respect condition
    uint32_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    // Must be: class 01, I=0, P=1, L=1, Rn==15 (execute() already gated this)
    uint32_t rd    = (instr >> 12) & 0xF;
    uint32_t imm12 = instr & 0xFFFu;
    uint32_t U     = (instr >> 23) & 1u;

    // *** PC as seen by the instruction ***
    // In ARM state, base = (current PC + 8), word-aligned.
    // Your core keeps r15 = current + 4, so add 4 and align:
    uint32_t pc_seen = (cpu.r[15] + 4) & ~3u;

    uint32_t addr = U ? (pc_seen + imm12) : (pc_seen - imm12);

    uint32_t val = mem_read32(addr);   // or bus_read32(addr) in your codebase
    cpu.r[rd] = val;

    if (debug_flags & DBG_INSTR) {
        log_printf("[LDR literal] r%d = mem[0x%08X] => 0x%08X (pc_seen=0x%08X, imm=0x%03X, U=%u)\n",
                   rd, addr, val, pc_seen, imm12, U);
    }
    return; // IMPORTANT: mark handled
}

void handle_ldr_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t imm = instr & 0xFFF;
    bool U = (instr >> 23) & 1u;

    uint32_t addr = cpu.r[rn];
    addr = U ? (addr + imm) : (addr - imm);

    uint32_t val = mem_read32(addr);
    cpu.r[rd] = val;

    if (debug_flags & DBG_INSTR)
        log_printf("[LDR pre-%s imm] r%d = mem[0x%08X] => 0x%08X\n",
                   U ? "inc" : "dec", rd, addr, val);
    return;
}

void handle_ldr_postimm(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xF;
    uint8_t rn = (instr >> 16) & 0xF;
    uint32_t imm = instr & 0xFFF;
    uint32_t U   = (instr >> 23) & 1u;

    uint32_t addr = cpu.r[rn];
    uint32_t val  = mem_read32(addr);
    cpu.r[rd] = val;
    cpu.r[rn] = U ? (addr + imm) : (addr - imm);

    if (debug_flags & DBG_INSTR || trace_all)
        log_printf("[LDR post-imm] r%d = mem[0x%08X] => 0x%08X; r%d %c= 0x%X => 0x%08X\n",
                   rd, addr, val, rn, U?'+':'-', imm, cpu.r[rn]);
    return;
}

void handle_ldrb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    bool up  = (instr >> 23) & 1u;
    bool pre = (instr >> 24) & 1u;
    bool wb  = (instr >> 21) & 1u;

    uint32_t addr = cpu.r[rn];
    if (pre) addr = up ? addr + offset : addr - offset;

    uint8_t val = mem_read8(addr);
    cpu.r[rd] = val;

    if (wb || !pre) cpu.r[rn] = addr;

    if (debug_flags & DBG_INSTR)
        log_printf("[LDRB pre-%s%s imm] r%d = mem8[0x%08X] => 0x%02X\n",
                   up ? "inc" : "dec", wb ? "!" : "", rd, addr, val);
    return;
}

void handle_ldrb_postimm(uint32_t instr) {
    uint32_t rn   = (instr >> 16) & 0xF;
    uint32_t rd   = (instr >> 12) & 0xF;
    uint32_t off  =  instr        & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint8_t  val  = mem_read8(addr);

    cpu.r[rd]  = val;
    cpu.r[rn] += off;   // post-index writeback (covers W==0 and W==1 encodings)

    if (trace_all || (debug_flags & DBG_MEM_READ)) {
        log_printf("[LDRB post-imm] r%d = mem8[0x%08X] => 0x%02X; r%d += 0x%X\n",
                   rd, addr, val, rn, off);
    }
}

void handle_pop(uint32_t instr) {
    uint32_t reglist = instr & 0xFFFF;
    uint32_t addr = cpu.r[13];

    size_t msz = mem_size();
    if (!mem_is_bound() || msz < 4) {
        log_printf("  [ERROR] No memory bound while POP\n");
        return;
    }

    for (int i = 0; i < 16; i++) {
        if (reglist & (1u << i)) {
            uint32_t val = mem_read32(addr);

            if (i == 15) { // PC
                // Validate the target against current bound memory.
                if (val >= (uint32_t)msz) {
                    log_printf("  [ERROR] Invalid return address 0x%08X (mem_size=%zu)\n", val, msz);
                    return;
                }
                cpu.r[15] = val;
            } else {
                cpu.r[i] = val;
            }
            addr += 4;
        }
    }
    cpu.r[13] = addr;
    return;
}

void handle_pop_pc(uint32_t instr) {
    int imm = instr & 0xFFF;

    size_t msz = mem_size();
    if (!mem_is_bound() || msz < 4) {
        log_printf("  [ERROR] No memory bound while POP {..,pc}\n");
        return;
    }

    uint32_t ret = mem_read32(cpu.r[13]);
    if (ret >= (uint32_t)msz) {
        log_printf("  [ERROR] Invalid return address 0x%08X from stack! (mem_size=%zu)\n", ret, msz);
        return;
    }

    cpu.r[15] = ret;
    cpu.r[13] += (uint32_t)imm;

    if (debug_flags & DBG_INSTR)
        log_printf("  [POP PC] => 0x%08X, SP=0x%08X\n", cpu.r[15], cpu.r[13]);

    return;
}

// ---- LDRD / STRD -----------------------------------------------------------

#ifndef GET_BITS
#define GET_BITS(x,hi,lo) (((x) >> (lo)) & ((1u << ((hi)-(lo)+1)) - 1))
#endif
#ifndef GET_BIT
#define GET_BIT(x,b) (((x) >> (b)) & 1u)
#endif

static inline uint32_t ldrd_strd_imm_off(uint32_t instr) {
    uint32_t imm4H = GET_BITS(instr, 11, 8);
    uint32_t imm4L = GET_BITS(instr,  3, 0);
    return (imm4H << 4) | imm4L;
}

static bool ldrd_strd_check(uint32_t Rn, uint32_t Rt, bool writeback, const char *mnemonic) {
    // Rt must be even; neither Rt nor Rt+1 may be r15
    if ((Rt & 1u) != 0u || Rt == 15u || (Rt + 1u) == 15u) {
        log_printf("[ERROR] %s: Rt must be even and Rt/Rt+1 must not be r15 (Rt=%u)\n",
                   mnemonic, Rt);
        return false;
    }
    // Writeback may not target a base that overlaps the destination pair
    if (writeback && (Rn == Rt || Rn == (Rt + 1u))) {
        log_printf("[ERROR] %s: writeback hazard: Rn==Rt or Rn==Rt+1 (Rn=%u, Rt=%u)\n",
                   mnemonic, Rn, Rt);
        return false;
    }
    // If you want to enforce base != r15 for these forms, uncomment:
    // if (Rn == 15u) {
    //     log_printf("[ERROR] %s: Rn must not be r15 for this addressing form\n", mnemonic);
    //     return false;
    // }

    return true;
}

static bool do_ldrd(uint32_t addr, uint32_t Rt) {
    if (addr & 3u) {
        log_printf("[ERROR] LDRD unaligned address 0x%08X\n", addr);
        return false;
    }
    uint32_t lo = mem_read32(addr);
    uint32_t hi = mem_read32(addr + 4);
    cpu.r[Rt]     = lo;
    cpu.r[Rt + 1] = hi;

    if (trace_all || (debug_flags & DBG_MEM_READ)) {
        log_printf("[LDRD] r%u=0x%08X r%u=0x%08X from [0x%08X]\n",
                   Rt, lo, Rt + 1, hi, addr);
    }
    return true;
}

static bool do_strd(uint32_t addr, uint32_t Rt) {
    if (addr & 3u) {
        log_printf("[ERROR] STRD unaligned address 0x%08X\n", addr);
        return false;
    }
    uint32_t lo = cpu.r[Rt];
    uint32_t hi = cpu.r[Rt + 1];
    mem_write32(addr,     lo);
    mem_write32(addr + 4, hi);

    if (trace_all || (debug_flags & DBG_MEM_WRITE)) {
        log_printf("[STRD] [0x%08X] <= r%u=0x%08X, [0x%08X] <= r%u=0x%08X\n",
                   addr, Rt, lo, addr + 4, Rt + 1, hi);
    }
    return true;
}

// Immediate form (I=1), bits[7:4]==0b1111
void exec_ldrd_imm(uint32_t instr) {
    uint32_t P = GET_BIT(instr, 24);
    uint32_t U = GET_BIT(instr, 23);
    uint32_t W = GET_BIT(instr, 21);
    uint32_t Rn = GET_BITS(instr, 19, 16);
    uint32_t Rt = GET_BITS(instr, 15, 12);

    bool writeback = W || !P;
    if (!ldrd_strd_check(Rn, Rt, writeback, "LDRD")) return;

    uint32_t base  = cpu.r[Rn];
    uint32_t off   = ldrd_strd_imm_off(instr);
    uint32_t delta = U ? off : (uint32_t)(-((int32_t)off));
    uint32_t addr  = P ? (base + delta) : base;

    bool ok = do_ldrd(addr, Rt);
    if (ok && writeback) cpu.r[Rn] = base + delta;
    return;
}

// Register form (I=0), bits[7:4]==0b1111
void exec_ldrd_reg(uint32_t instr) {
    uint32_t P  = GET_BIT(instr, 24);
    uint32_t U  = GET_BIT(instr, 23);
    uint32_t W  = GET_BIT(instr, 21);
    uint32_t Rn = GET_BITS(instr, 19, 16);
    uint32_t Rt = GET_BITS(instr, 15, 12);
    uint32_t Rm = GET_BITS(instr,  3,  0);

    bool writeback = W || !P;
    if (!ldrd_strd_check(Rn, Rt, writeback, "LDRD")) return;

    uint32_t base  = cpu.r[Rn];
    uint32_t off   = cpu.r[Rm];
    uint32_t delta = U ? off : (uint32_t)(-((int32_t)off));
    uint32_t addr  = P ? (base + delta) : base;

    bool ok = do_ldrd(addr, Rt);
    if (ok && writeback) cpu.r[Rn] = base + delta;
    return;
}

void exec_strd_imm(uint32_t instr) {
    uint32_t P  = GET_BIT(instr, 24);
    uint32_t U  = GET_BIT(instr, 23);
    uint32_t W  = GET_BIT(instr, 21);
    uint32_t Rn = GET_BITS(instr, 19, 16);
    uint32_t Rt = GET_BITS(instr, 15, 12);

    bool writeback = W || !P;
    if (!ldrd_strd_check(Rn, Rt, writeback, "STRD")) return;

    uint32_t base  = cpu.r[Rn];
    uint32_t off   = ldrd_strd_imm_off(instr);
    uint32_t delta = U ? off : (uint32_t)(-((int32_t)off));
    uint32_t addr  = P ? (base + delta) : base;

    bool ok = do_strd(addr, Rt);
    if (ok && writeback) cpu.r[Rn] = base + delta;
    return;
}

void exec_strd_reg(uint32_t instr) {
    uint32_t P  = GET_BIT(instr, 24);
    uint32_t U  = GET_BIT(instr, 23);
    uint32_t W  = GET_BIT(instr, 21);
    uint32_t Rn = GET_BITS(instr, 19, 16);
    uint32_t Rt = GET_BITS(instr, 15, 12);
    uint32_t Rm = GET_BITS(instr,  3,  0);

    bool writeback = W || !P;
    if (!ldrd_strd_check(Rn, Rt, writeback, "STRD")) return;

    uint32_t base  = cpu.r[Rn];
    uint32_t off   = cpu.r[Rm];
    uint32_t delta = U ? off : (uint32_t)(-((int32_t)off));
    uint32_t addr  = P ? (base + delta) : base;

    bool ok = do_strd(addr, Rt);
    if (ok && writeback) cpu.r[Rn] = base + delta;
    return;
}
// --- helpers near others in memops.c ---
static inline uint32_t am2_shift(uint32_t instr, uint32_t rmval) {
    // Addressing Mode 2 register offset shift (imm only, bit4==0)
    uint32_t stype  = (instr >> 5) & 0x3u;   // 0 LSL, 1 LSR, 2 ASR, 3 ROR
    uint32_t shimm  = (instr >> 7) & 0x1Fu;  // shift immediate
    switch (stype) {
        case 0: // LSL
            return (shimm == 0) ? rmval : (rmval << shimm);
        case 1: // LSR
            return (shimm == 0) ? 0 : (rmval >> shimm);
        case 2: // ASR
            if (shimm == 0) shimm = 32;
            return (uint32_t)((int32_t)rmval >> (shimm & 31));
        case 3: // ROR
            if (shimm == 0) {
                // RRX not used by AM2 (but ARM leaves it "rotate right 1 with carry").
                // Keep it simple: treat as RRX using current C for completeness.
                uint32_t c = (cpu.cpsr >> 29) & 1u;
                return (rmval >> 1) | (c << 31);
            }
            shimm &= 31u;
            return (rmval >> shimm) | (rmval << (32 - shimm));
    }
    return rmval;
}

// LDR (word) — register offset addressing (AM2, bit25=1, B=0, L=1)
void handle_ldr_regoffset(uint32_t instr) {
    // Ensure this really is AM2 reg-offset (bit25=1) and bit4==0 (imm shift)
    if (((instr >> 25) & 1u) == 0) return;
    if (((instr >> 4) & 1u) != 0)  return;

    uint32_t P = (instr >> 24) & 1u;
    uint32_t U = (instr >> 23) & 1u;
    uint32_t W = (instr >> 21) & 1u;
    uint32_t L = (instr >> 20) & 1u;
    uint32_t B = (instr >> 22) & 1u;

    if (L != 1 || B != 0) return; // this handler is only LDR word

    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;
    uint32_t Rm =  instr        & 0xFu;

    uint32_t base   = cpu.r[Rn];
    uint32_t rmval  = cpu.r[Rm];
    uint32_t offset = am2_shift(instr, rmval);
    uint32_t delta  = U ? offset : (uint32_t)(-((int32_t)offset));
    uint32_t addr   = P ? (base + delta) : base;

    uint32_t val = mem_read32(addr);
    cpu.r[Rd] = val;

    // Writeback when W=1, or post-indexed form (P=0 implies writeback)
    if (W || !P) cpu.r[Rn] = base + delta;

    if (trace_all || (debug_flags & DBG_MEM_READ)) {
        log_printf("[LDR reg-off] r%u = mem32[0x%08X] => 0x%08X  (Rn=r%u%s, off=%c0x%X%s)\n",
                   Rd, addr, val, Rn,
                   (W||!P)?" wb":"", U?'+':'-', offset,
                   P? " pre": " post");
    }
    return;
}

// Minimal AM2 shift for address calculation (carry ignored for addressing)
static inline uint32_t am2_shift_imm(uint32_t val, uint32_t stype, uint32_t sh_imm) {
    sh_imm &= 0x1F;
    switch (stype & 3u) {
        case 0: // LSL
            return (sh_imm ? (val << sh_imm) : val);
        case 1: // LSR
            return (sh_imm ? (val >> sh_imm) : 0);
        case 2: // ASR
            return (sh_imm ? ((uint32_t)((int32_t)val >> sh_imm)) : (val & 0x80000000u ? 0xFFFFFFFFu : 0));
        case 3: // ROR (sh_imm==0 -> RRX)
            if (sh_imm == 0) {
                // RRX uses C as bit31; address calc doesn’t affect flags—just use cpsr C
                uint32_t c = (cpu.cpsr >> 29) & 1u;
                return (val >> 1) | (c << 31);
            }
            return (val >> sh_imm) | (val << (32 - sh_imm));
    }
    return val;
}

void handle_ldrb_reg_shift(uint32_t instr) {
    // AM2: I=1, B=1, L=1, bit4==0 (imm shift)
    uint32_t rn    = (instr >> 16) & 0xF;
    uint32_t rd    = (instr >> 12) & 0xF;
    uint32_t rm    =  instr        & 0xF;

    uint32_t stype = (instr >> 5) & 0x3u;   // 0 LSL,1 LSR,2 ASR,3 ROR
    uint32_t sh_imm= (instr >> 7) & 0x1Fu;  // shift immediate
    uint32_t P     = (instr >> 24) & 1u;    // pre/post
    uint32_t U     = (instr >> 23) & 1u;    // add/sub
    uint32_t W     = (instr >> 21) & 1u;    // writeback

    uint32_t base   = cpu.r[rn];
    uint32_t off    = am2_shift_imm(cpu.r[rm], stype, sh_imm);
    uint32_t delta  = U ? off : (uint32_t)(-((int32_t)off));
    uint32_t addr   = P ? (base + delta) : base;        // pre: use updated, post: use base
    uint32_t new_rn = base + delta;                     // value for writeback when needed

    uint8_t  val = mem_read8(addr);
    cpu.r[rd] = (uint32_t)val;

    if (W || !P) cpu.r[rn] = new_rn;                    // writeback for W==1 or post-indexed

    if (trace_all || (debug_flags & DBG_MEM_READ)) {
        static const char* S[4] = {"LSL","LSR","ASR","ROR"};
        log_printf("[LDRB reg/shift] r%u = mem8[0x%08X] => 0x%02X  (r%d %c= %s #%u%s)\n",
                   rd, addr, val, rn, U?'+':'-', S[stype], sh_imm, (W||!P)?" wb":"");
    }
    return;
}

