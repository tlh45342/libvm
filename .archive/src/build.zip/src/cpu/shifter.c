#include "shifter.h"

uint32_t dp_operand2(uint32_t instr, uint32_t *sh_carry) {
    const uint32_t I = (instr >> 25) & 1u;

    if (I) {
        uint32_t imm8 = instr & 0xffu;
        uint32_t rot  = ((instr >> 8) & 0xfu) * 2u;
        uint32_t val  = rot ? ((imm8 >> rot) | (imm8 << (32 - rot))) : imm8;
        *sh_carry = rot ? ((val >> 31) & 1u) : cpsr_get_C();
        return val;
    } else {
        uint32_t Rm = cpu.r[instr & 0xfu];
        uint32_t type = (instr >> 5) & 0x3u;       // 0 LSL, 1 LSR, 2 ASR, 3 ROR
        uint32_t by_reg = (instr >> 4) & 1u;
        uint32_t amount = by_reg ? (cpu.r[(instr >> 8) & 0xfu] & 0xffu)
                                 : ((instr >> 7) & 0x1fu);
        uint32_t c_out = cpsr_get_C(), val = Rm;

        switch (type) {
            case 0: // LSL
                if (amount == 0) { /* keep c_out */ }
                else if (amount < 32) { c_out = (Rm >> (32 - amount)) & 1u; val = Rm << amount; }
                else if (amount == 32) { c_out = Rm & 1u; val = 0; }
                else { c_out = 0; val = 0; }
                break;
            case 1: // LSR
                if (amount == 0) { c_out = (Rm >> 31) & 1u; val = 0; }
                else if (amount < 32) { c_out = (Rm >> (amount - 1)) & 1u; val = Rm >> amount; }
                else { c_out = 0; val = 0; }
                break;
            case 2: // ASR
                if (amount == 0) { c_out = (Rm >> 31) & 1u; val = (Rm & 0x80000000u) ? 0xffffffffu : 0; }
                else if (amount < 32) {
                    c_out = (Rm >> (amount - 1)) & 1u;
                    if (Rm & 0x80000000u) val = (Rm >> amount) | ~(~0u >> amount);
                    else                   val =  Rm >> amount;
                } else {
                    c_out = (Rm >> 31) & 1u; val = (Rm & 0x80000000u) ? 0xffffffffu : 0;
                }
                break;
            case 3: // ROR / RRX
                if (!by_reg && amount == 0) { // RRX
                    c_out = Rm & 1u;
                    val = (cpsr_get_C() << 31) | (Rm >> 1);
                } else {
                    uint32_t rot = amount & 31u;
                    if (rot == 0) { c_out = (Rm >> 31) & 1u; val = Rm; }
                    else { val = (Rm >> rot) | (Rm << (32 - rot)); c_out = (val >> 31) & 1u; }
                }
                break;
        }
        *sh_carry = c_out;
        return val;
    }
}