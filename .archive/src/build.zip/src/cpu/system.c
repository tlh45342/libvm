// src/cpu/system.c

#include <stdint.h>
#include <stdbool.h>

#include "cpu.h"         // CPU struct, extern CPU cpu
#include "cpu_flags.h"   // cpsr_set_* helpers, psr_write(), CPSR_* bits
#include "log.h"         // log_printf()
#include "system.h"      // prototypes
#include "debug.h"       // debug_flags, DBG_INSTR

// --- Barriers: treat as NOPs in this VM ---
void handle_dsb(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[DSB SY] Data Synchronization Barrier (nop)\n");
}

void handle_dmb(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[DMB SY] Data Memory Barrier (nop)\n");
}

void handle_isb(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[ISB SY] Instruction Synchronization Barrier (nop)\n");
}

void handle_svc(uint32_t instr) {
    uint32_t A  = (cpu.r[15] - 4);          // address of SVC instruction
    uint32_t lr = cpu.r[15] + 4;            // A+8 (return target for SUBS pc, lr, #4)

    if (debug_flags & DBG_INSTR) {
        log_printf("[SVC] imm=0x%06X A=0x%08X -> LR_svc=0x%08X\n",
                   instr & 0x00FFFFFFu, A, lr);
    }

    // Save old CPSR and LR, then enter SVC (ARM, I=1)
    cpu.spsr   = cpu.cpsr;
    cpu.r[14]  = lr;

    uint32_t p = cpu.cpsr;
    p = (p & ~0x1Fu) | 0x13u;   // SVC mode
    p &= ~(1u << 5);            // T=0 (ARM)
    p |=  (1u << 7);            // I=1
    p &= ~((0x3Fu << 10) | (0x3u << 25)); // clear IT bits
    cpu.cpsr = p;

    // Branch to SVC vector
    cpu.r[15] = 0x00000008u;
}

void handle_mrs(uint32_t instr) {
    uint32_t Rd  = (instr >> 12) & 0xF;
    uint32_t sps = (instr >> 22) & 1u;   // 0=CPSR, 1=SPSR
    uint32_t val = sps ? cpu.spsr : cpu.cpsr;
    cpu.r[Rd] = val;
    if (debug_flags & DBG_INSTR)
        log_printf("[MRS] r%u = %s (0x%08X)\n", Rd, sps ? "SPSR" : "CPSR", val);
}

static void handle_msr_common(uint32_t instr) {
    int spsr_sel = (instr >> 22) & 1u;      // 0=CPSR, 1=SPSR
    uint32_t fields = (instr >> 16) & 0xFu; // {f s x c}
    uint32_t op;

    if ((instr >> 25) & 1u) {
        // immediate form
        uint32_t imm8 = instr & 0xFFu;
        uint32_t rot2 = ((instr >> 8) & 0xFu) * 2u;
        op = rot2 ? ((imm8 >> rot2) | (imm8 << (32 - rot2))) : imm8;
    } else {
        // register form
        uint8_t Rm = instr & 0xFu;
        op = cpu.r[Rm];
    }

    if (spsr_sel) {
        if (is_user_mode()) {
            if (debug_flags & DBG_INSTR)
                log_printf("[MSR] SPSR write ignored in User mode\n");
            return;
        }
        psr_write(&cpu.spsr, op, fields, 0);
    } else {
        psr_write(&cpu.cpsr, op, fields, 1);
    }
}

void handle_msr(uint32_t instr)       { handle_msr_common(instr); }
void handle_msr_reg(uint32_t instr)   { handle_msr_common(instr); }
void handle_msr_imm(uint32_t instr)   { handle_msr_common(instr); }

void handle_setend(uint32_t instr) {
    uint32_t E = (instr >> 9) & 1u;
    if (E) cpu.cpsr |=  CPSR_E; else cpu.cpsr &= ~CPSR_E;
    if (debug_flags & DBG_INSTR)
        log_printf("[SETEND] E=%u -> CPSR=0x%08X (emulator memory remains LE)\n", E, cpu.cpsr);
}

void handle_cps(uint32_t instr) {
    bool disable = ((instr >> 18) & 1u) != 0;
    bool Mbit    = ((instr >> 17) & 1u) != 0;
    uint32_t mask = 0;
    if (instr & (1u << 8)) mask |= (1u << 8);   // A
    if (instr & (1u << 7)) mask |= (1u << 7);   // I
    if (instr & (1u << 6)) mask |= (1u << 6);   // F

    if (disable) cpu.cpsr |= mask; else cpu.cpsr &= ~mask;

    if (Mbit) {
        uint32_t mode = instr & 0x1Fu;
        cpu.cpsr = (cpu.cpsr & ~0x1Fu) | (mode & 0x1Fu);
    }

    if (debug_flags & DBG_INSTR) {
        log_printf("[CPS%s] AIF=%c%c%c mode=%s -> CPSR=0x%08X\n",
            disable ? "ID" : "IE",
            (instr & (1u<<8))?'A':'-',
            (instr & (1u<<7))?'I':'-',
            (instr & (1u<<6))?'F':'-',
            Mbit ? "set" : "unchanged",
            cpu.cpsr);
    }
}

// -----------------------------------------------------------------------------
// Misc simple handlers referenced by execute()
// -----------------------------------------------------------------------------
void handle_nop(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR) log_printf("[NOP]\n");
}

void handle_wfi(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[WFI] Wait for interrupt (simulated pause).\n");
    // behaves as NOP in this VM
}

void handle_deadbeef(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[HALT] DEADBEEF.  Halting VM.\n");
    cpu_halt();
}