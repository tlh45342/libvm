// disasm.c (new)  -- very small starter; grow as you go
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

static inline int signext_24_to_32(int32_t x) { return (x << 8) >> 6; } // imm24<<2 sign-extend

void disasm_line(uint32_t pc, uint32_t instr, char *out, size_t out_sz) {
    uint32_t cond = (instr >> 28) & 0xF;

    // B / BL
    if ((instr & 0x0E000000u) == 0x0A000000u) {
        int32_t imm24  = (int32_t)(instr & 0x00FFFFFFu);
        int32_t offset = signext_24_to_32(imm24);              // ARM rule: imm24<<2 sign-extended
        uint32_t target = pc + 8 + (uint32_t)offset;           // PC is current, pipeline adds +8
        if (instr & 0x01000000u)
            snprintf(out, out_sz, "bl%s  0x%08X", (cond==0xE? "":""), target);
        else
            snprintf(out, out_sz, "b%s   0x%08X", (cond==0xE? "":""), target);
        return;
    }

    // Data processing quick IDs for MOV/CMP/TST (not complete, just enough for now)
    if ((instr & 0x0C000000u) == 0x00000000u) {
        uint32_t op   = (instr >> 21) & 0xF;
        uint32_t S    = (instr >> 20) & 1u;
        uint32_t Rd   = (instr >> 12) & 0xF;
        uint32_t Rn   = (instr >> 16) & 0xF;

        // immediate?
        if (instr & (1u<<25)) {
            uint32_t imm8  = instr & 0xFF;
            uint32_t rot   = ((instr >> 8) & 0xF) * 2;
            uint32_t imm32 = (imm8 >> rot) | (imm8 << (32-rot));
            switch (op) {
                case 0xD: snprintf(out, out_sz, "mov%s r%u, #0x%X", S?"s":"", Rd, imm32); return;
                case 0xA: snprintf(out, out_sz, "cmp r%u, #0x%X", Rn, imm32); return;
                case 0x8: snprintf(out, out_sz, "tst r%u, #0x%X", Rn, imm32); return;
            }
        }
    }

    // Single data transfer (LDR/STR); handle imm offset, byte variants
    if ((instr & 0x0C000000u) == 0x04000000u) {
        uint32_t L = (instr >> 20) & 1u;
        uint32_t B = (instr >> 22) & 1u;
        uint32_t P = (instr >> 24) & 1u;
        uint32_t U = (instr >> 23) & 1u;
        uint32_t Rn= (instr >> 16) & 0xF;
        uint32_t Rd= (instr >> 12) & 0xF;
        uint32_t I = (instr >> 25) & 1u;

        const char *mn = (L ? (B ? "ldrb" : "ldr") : (B ? "strb" : "str"));

        if (!I) {
            uint32_t imm12 = instr & 0xFFF;
            int32_t off = U ? (int32_t)imm12 : -(int32_t)imm12;
            if (P) snprintf(out, out_sz, "%s r%u, [r%u, #%d]", mn, Rd, Rn, off);
            else   snprintf(out, out_sz, "%s r%u, [r%u], #%d", mn, Rd, Rn, off);
            return;
        }
        // (reg-offset variants omitted for brevity)
    }

    // Fallback
    snprintf(out, out_sz, ".word 0x%08X", instr);
}