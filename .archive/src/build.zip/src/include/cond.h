#pragma once
#include <stdbool.h>
#include <stdint.h>

bool evaluate_condition(uint8_t cond);