import subprocess
import os
import sys

VM = "arm-vm.exe"
TEST_NAME = "test_branch"

CHECKS = [
    # First block
    ("MOV decoded #1",          "[K12] MOV match (key=0x3A0)"),
    ("CMP decoded #1",          "[K12] CMP match (key=0x350)"),
    ("B cond fail",             "[K12] B cond fail (0x0)"),

    # Unconditional branch to 0x8014
    ("B decoded #1",            "[K12] B match (key=0xA00)"),
    ("B target #1",             "[B] A=0x0000800C base=0x00008014 off=0 -> target=0x00008014"),

    # Second block
    ("MOV decoded #2",          "[K12] MOV match (key=0x3A0)"),
    ("CMP decoded #2",          "[K12] CMP match (key=0x350)"),
    ("B decoded #2",            "[K12] B match (key=0xA00)"),
    ("B target #2",             "[B] A=0x0000801C base=0x00008024 off=0 -> target=0x00008024"),

    # Halt
    ("DEADBEEF decoded",        "[K12] DEADBEEF match (key=0xEAE)"),
    ("HALT",                    "[HALT] DEADBEEF.  Halting VM."),
]

def run_test():
    print(f"Running {TEST_NAME}...")

    script_path = f"{TEST_NAME}.script"
    bin_path = f"{TEST_NAME}.bin"
    log_path = f"{TEST_NAME}.log"

    if not os.path.exists(script_path):
        print(f"❌ Missing script: {script_path}")
        return False

    if not os.path.exists(bin_path):
        print(f"❌ Missing binary: {bin_path}")
        return False

    try:
        subprocess.run(
            [VM],
            stdin=open(script_path, "r"),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
    except FileNotFoundError:
        print(f"❌ Error: '{VM}' not found in PATH.")
        return False

    if not os.path.exists(log_path):
        print(f"❌ Missing log file: {log_path}")
        return False

    with open(log_path, "r") as f:
        log = f.read()

    passed = True
    for label, expected in CHECKS:
        if expected not in log:
            print(f"  ❌ Check failed: {label}")
            print(f"     Missing: {expected}")
            passed = False
        else:
            print(f"  ✅ {label}")

    print(f"{TEST_NAME}: {'✅ passed' if passed else '❌ failed'}\n")
    return passed

if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)