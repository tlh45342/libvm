import subprocess
import os
import sys

VM = "arm-vm.exe"
TEST_NAME = "test_bics"

CHECKS = [
    ("Debug enabled",        "debug_flags set to 0xFFFFFFFF"),
    ("MOV r0=0xF0",          "[MOV imm] r0 = 0x000000F0"),

    # First BICS: result==0 -> Z=1
    ("BICS r1 zero",         "[BICS] r1 = r0(0x000000F0) & ~op2(0x000000F0) => 0x00000000"),
    ("CPSR Z set",           "MRS] r10 = CPSR (0x40000000)"),

    # Second BICS: result==0xF0 -> Z=0; verify we later see only C set (from shifter/immediate path)
    ("BICS r2 nz",           "[BICS] r2 = r0(0x000000F0) & ~op2(0x80000000) => 0x000000F0"),
    ("CPSR C only",          "MRS] r11 = CPSR (0x20000000)"),

    # Build 0x80000001 into r3, then BICS clears top bit -> r5==1
    ("ORR set N-bit",        "[ORR] r3 = r3|op2 => 0x80000001"),
    ("BICS r5 -> 1",         "[BICS] r5 = r3(0x80000001) & ~op2(0x80000000) => 0x00000001"),
    ("CPSR cleared",         "MRS] r12 = CPSR (0x00000000)"),

    # Write CPSR to set C=1; then BICS with op2=0 leaves r7=r0
    ("CPSR write C",         "[PSR write] CPSR <= 0x20000000"),
    ("BICS r7 keep r0",      "[BICS] r7 = r0(0x000000F0) & ~op2(0x00000000) => 0x000000F0"),
    ("Final CPSR C",         "MRS] r13 = CPSR (0x20000000)"),

    # Halt
    ("HALT",                 "[HALT] DEADBEEF.  Halting VM."),
]

def run_test():
    print(f"Running {TEST_NAME}...")

    script_path = f"{TEST_NAME}.script"
    bin_path = f"{TEST_NAME}.bin"
    log_path = f"{TEST_NAME}.log"

    if not os.path.exists(script_path):
        print(f"❌ Missing script: {script_path}")
        return False

    if not os.path.exists(bin_path):
        print(f"❌ Missing binary: {bin_path}")
        return False

    try:
        subprocess.run(
            [VM],
            stdin=open(script_path, "r"),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
    except FileNotFoundError:
        print(f"❌ Error: '{VM}' not found in PATH.")
        return False

    if not os.path.exists(log_path):
        print(f"❌ Missing log file: {log_path}")
        return False

    with open(log_path, "r") as f:
        log = f.read()

    passed = True
    for label, expected in CHECKS:
        if expected not in log:
            print(f"  ❌ Check failed: {label}")
            print(f"     Missing: {expected}")
            passed = False
        else:
            print(f"  ✅ {label}")

    print(f"{TEST_NAME}: {'✅ passed' if passed else '❌ failed'}\n")
    return passed

if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)