import subprocess
import os
import sys

VM = "arm-vm.exe"
TEST_NAME = "test_bics"

CHECKS = [
    ("Debug enabled",          "[DEBUG] debug_flags set to 0xFFFFFFFF"),

    # Init + clear flags
    ("Init r0 to 0xF0",        "[MOV imm] r0 = 0x000000F0"),
    ("Clear CPSR flags",       "[PSR write] CPSR <= 0x00000000 (fields: ----)"),

    # I=1 (imm, rot=0): result = 0, Z=1
    ("BICS imm zero",          "[BICS] r1 = r0(0x000000F0) & ~op2(0x000000F0) => 0x00000000"),
    ("Z set after imm zero",   "[MRS] r10 = CPSR (0x40000000)"),

    # I=1 (imm, rot!=0 -> 0x80000000): result unchanged, C=1 from shifter
    ("BICS imm rotate",        "[BICS] r2 = r0(0x000000F0) & ~op2(0x80000000) => 0x000000F0"),
    ("C set after rotate",     "[MRS] r11 = CPSR (0x20000000)"),

    # I=0 (reg, LSL #31): result = 0x1, flags clear
    ("Build r3=0x80000001",    "[ORR] r3 = r3|op2 => 0x80000001"),
    ("BICS reg LSL#31",        "[BICS] r5 = r3(0x80000001) & ~op2(0x80000000) => 0x00000001"),
    ("Flags clear after LSL",  "[MRS] r12 = CPSR (0x00000000)"),

    # I=0 (reg, RRX path): set C=1, then RRX clears C
    ("Set C via MSR reg",      "[PSR write] CPSR <= 0x20000000 (fields: ----)"),
    ("BICS reg RRX",           "[BICS] r7 = r0(0x000000F0) & ~op2(0x00000000) => 0x000000F0"),
    ("C cleared after RRX",    "[MRS] r13 = CPSR (0x00000000)"),

    # Halt
    ("Halt",                   "[HALT] DEADBEEF"),
]

def run_test():
    print(f"Running {TEST_NAME}...")

    script_path = f"{TEST_NAME}.script"
    bin_path = f"{TEST_NAME}.bin"
    log_path = f"{TEST_NAME}.log"

    if not os.path.exists(script_path):
        print(f"❌ Missing script: {script_path}")
        return False

    if not os.path.exists(bin_path):
        print(f"❌ Missing binary: {bin_path}")
        return False

    try:
        subprocess.run(
            [VM],
            stdin=open(script_path, "r"),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
    except FileNotFoundError:
        print(f"❌ Error: '{VM}' not found in PATH.")
        return False

    if not os.path.exists(log_path):
        print(f"❌ Missing log file: {log_path}")
        return False

    with open(log_path, "r") as f:
        log = f.read()

    passed = True
    for label, expected in CHECKS:
        if expected not in log:
            print(f"  ❌ Check failed: {label}")
            print(f"     Missing: {expected}")
            passed = False
        else:
            print(f"  ✅ {label}")

    print(f"{TEST_NAME}: {'✅ passed' if passed else '❌ failed'}\n")
    return passed

if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)