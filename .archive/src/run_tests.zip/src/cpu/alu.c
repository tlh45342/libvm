// src/alu.c
#include <stdint.h>
#include <stdbool.h>

#include "cpu.h"
#include "cpu_flags.h"
#include "shifter.h"   // dp_operand2(...)
#include "alu.h"
#include "cond.h"
#include "operand.h"   // arm_read_src_reg(...)

// ------------------------------- helpers ---------------------------------

static inline uint32_t dp_expand_imm(uint32_t instr) {
    // 8-bit immediate rotated right by an even amount (2 * rot)
    uint32_t imm8 = instr & 0xFFu;
    uint32_t rot  = ((instr >> 8) & 0xFu) * 2u;
    return (imm8 >> rot) | (imm8 << (32u - rot));
}

// Minimal Operand2(register, imm-shift) value for ADD fast path.
// Uses arm_read_src_reg(rm) so PC as source is PC+offset.
static inline uint32_t dp_op2_reg_value_for_add(uint32_t instr) {
    uint32_t rm    =  instr        & 0xFu;
    uint32_t type  = (instr >> 5)  & 3u;   // 0 LSL, 1 LSR, 2 ASR, 3 ROR
    uint32_t shimm = (instr >> 7)  & 0x1Fu;
    uint32_t rmval = arm_read_src_reg((int)rm);

    switch (type) {
        case 0: // LSL
            return shimm ? (rmval << shimm) : rmval;
        case 1: // LSR
            return shimm ? (rmval >> shimm) : 0;
        case 2: // ASR
            return shimm ? ((uint32_t)((int32_t)rmval >> shimm))
                         : (rmval & 0x80000000u ? 0xFFFFFFFFu : 0);
        default: { // ROR (shimm==0 => RRX with CPSR C)
            if (shimm == 0) {
                uint32_t c = (cpu.cpsr >> 29) & 1u;
                return (rmval >> 1) | (c << 31);
            }
            shimm &= 31u;
            return (rmval >> shimm) | (rmval << (32u - shimm));
        }
    }
}

// ------------------------------- handlers --------------------------------

// ADD / ADDS  Rd = Rn + op2
void handle_add(uint32_t instr) {
    // (Dispatcher already did cond check, but keep it here for safety/clarity)
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    const int rn = (instr >> 16) & 0xF;
    const int rd = (instr >> 12) & 0xF;
    const bool I = ((instr >> 25) & 1u) != 0;
    const bool S = ((instr >> 20) & 1u) != 0;

    const uint32_t op1 = arm_read_src_reg(rn); // *** PC+8 if rn==15 (ARM) / +4 (Thumb)
    const uint32_t op2 = I ? dp_expand_imm(instr)
                           : dp_op2_reg_value_for_add(instr);

    const uint32_t res = op1 + op2;
    cpu.r[rd] = res;

    if (S) {
        const uint32_t N = res >> 31;
        const uint32_t Z = (res == 0u);
        const uint32_t C = ((uint64_t)op1 + (uint64_t)op2) >> 32;
        const uint32_t V = (~(op1 ^ op2) & (op1 ^ res)) >> 31;
        cpu.cpsr = (cpu.cpsr & ~((1u<<31)|(1u<<30)|(1u<<29)|(1u<<28)))
                 | (N<<31) | (Z<<30) | (C<<29) | (V<<28);
        // If rd==15 and ADDS pc should return from exception, hook it here.
    }
}

// MOV / MOVS  (DP form; immediate or reg via dp_operand2)
void handle_mov_dp(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t res      = op2;

    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry & 1u); // MOVS: C := shifter carry
    }

    if (S && Rd == 15u) {
        // Architecture-specific: ADCS/MOVS to pc may restore state.
        cpu_exception_return(res);
        return;
    }

    cpu.r[Rd] = res;
}

// SUB / SUBS  Rd = Rn - op2
void handle_sub(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);
    uint32_t res      = a - op2;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(a >= op2); // NOT borrow
        int overflow = ((a ^ op2) & (a ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// AND / ANDS
void handle_and(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t res      = arm_read_src_reg(Rn) & op2;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry & 1u);
    }
}

// EOR / EORS
void handle_eor(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t res      = arm_read_src_reg(Rn) ^ op2;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry & 1u);
    }
}

// MVN / MVNS
void handle_mvn(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t res      = ~op2;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(sh_carry & 1u);
    }
}

// CMP  (sets flags only)  Rn - op2
void handle_cmp(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t Rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);
    uint32_t res      = a - op2;

    cpsr_set_NZ(res);
    cpsr_set_C_from(a >= op2);
    int overflow = ((a ^ op2) & (a ^ res) & 0x80000000u) != 0;
    cpsr_set_V(overflow);
}

// TST  (sets N,Z and C from shifter)
void handle_tst(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t Rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t res      = arm_read_src_reg(Rn) & op2;

    cpsr_set_NZ(res);
    cpsr_set_C_from(sh_carry & 1u);
}

// TEQ  (sets N,Z and C from shifter)
void handle_teq(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t Rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t res      = arm_read_src_reg(Rn) ^ op2;

    cpsr_set_NZ(res);
    cpsr_set_C_from(sh_carry & 1u);
}

// CMN  (sets flags only)  Rn + op2
void handle_cmn(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t Rn = (instr >> 16) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);
    uint32_t res      = a + op2;

    cpsr_set_NZ(res);
    cpsr_set_C_from(res < a); // carry out
    int overflow = (~(a ^ op2) & (a ^ res) & 0x80000000u) != 0;
    cpsr_set_V(overflow);
}

// RSB / RSBS  Rd = op2 - Rn
void handle_rsb(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);
    uint32_t res      = op2 - a;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(op2 >= a);
        int overflow = ((op2 ^ a) & (op2 ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// ADC / ADCS  Rd = Rn + op2 + C
void handle_adc(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);

    uint32_t cin      = cpsr_get_C();
    uint64_t sum      = (uint64_t)a + (uint64_t)op2 + (uint64_t)cin;
    uint32_t res      = (uint32_t)sum;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from((sum >> 32) & 1u);
        uint32_t b = op2 + cin;
        int overflow = (~(a ^ b) & (a ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// SBC / SBCS  Rd = Rn - op2 - (1 - C)
void handle_sbc(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);

    uint32_t cin      = cpsr_get_C();
    uint32_t borrow   = 1u - (cin & 1u);
    uint64_t diff     = (uint64_t)a - (uint64_t)op2 - (uint64_t)borrow;
    uint32_t res      = (uint32_t)diff;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from((diff >> 32) == 0); // no borrow -> C=1
        uint32_t btot = op2 + borrow;
        int overflow = ((a ^ btot) & (a ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}

// RSC / RSCS  Rd = op2 - Rn - (1 - C)
void handle_rsc(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0xFu;
    if (cond != 0xF && !evaluate_condition(cond)) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2      = dp_operand2(instr, &sh_carry);
    uint32_t a        = arm_read_src_reg(Rn);

    uint32_t cin      = cpsr_get_C();
    uint32_t borrow   = 1u - (cin & 1u);
    uint64_t diff     = (uint64_t)op2 - (uint64_t)a - (uint64_t)borrow;
    uint32_t res      = (uint32_t)diff;

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from((diff >> 32) == 0);
        uint32_t atot = a + borrow;
        int overflow = ((op2 ^ atot) & (op2 ^ res) & 0x80000000u) != 0;
        cpsr_set_V(overflow);
    }
}
