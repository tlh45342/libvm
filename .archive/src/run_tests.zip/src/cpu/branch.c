// src/cpu/branch.c
#include <stdint.h>
#include <stdbool.h>
#include "cpu.h"
#include "cond.h"   // evaluate_condition()

// ---- B (Branch) ----
// If condition passes: write PC to target (stepper will see PC changed and not +4).
// If condition fails: leave PC unchanged (stepper will add +4).
void handle_b(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        return; // not taken
    }

    uint32_t A    = cpu.r[15];
    int32_t  imm  = (int32_t)(instr & 0x00FFFFFFu);
    int32_t  off  = (imm << 8) >> 6;          // sign-extend of (imm24 << 2)
    uint32_t tgt  = (A + 8) + (uint32_t)off;  // ARM PC is A+8 in ARM state

    cpu.r[15] = tgt;
}

// ---- BL (Branch with Link) ----
void handle_bl(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        return; // not taken
    }

    uint32_t A    = cpu.r[15];
    int32_t  imm  = (int32_t)(instr & 0x00FFFFFFu);
    int32_t  off  = (imm << 8) >> 6;
    uint32_t tgt  = (A + 8) + (uint32_t)off;

    cpu.r[14] = A + 4;   // LR returns to the instruction after this one
    cpu.r[15] = tgt;
}

// ---- BX (Branch and Exchange) ----
// We ignore Thumb switching for now; just clear bit0 on the target.
void handle_bx(uint32_t instr) {
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        return; // not taken
    }

    uint32_t rm   = instr & 0xF;
    uint32_t addr = cpu.r[rm];

    // If Thumb is ever implemented, check bit0 and set CPSR.T accordingly.
    cpu.r[15] = addr & ~1u; // align to ARM state
}
