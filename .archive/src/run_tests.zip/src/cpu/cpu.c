// src/cpu/cpu.c

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <string.h>

#include "log.h"      // log_printf prototype (kept for cpu_dump_registers)
#include "cpu.h"
#include "mem.h"
#include "hw.h"
#include "execute.h"
#include "debug.h"    // debug_flags_t, trace_all

extern bool trace_all;
extern debug_flags_t debug_flags;

CPU cpu = {0};
uint64_t cycle = 0;
static bool g_cpu_halted = false;

// Forward decls / minimal control of run-state
void cpu_halt(void)       { g_cpu_halted = true; }
void cpu_clear_halt(void) { g_cpu_halted = false; }
bool cpu_is_halted(void)  { return g_cpu_halted; }

// -----------------------------------------------------------------------------
// Small utilities
// -----------------------------------------------------------------------------

uint32_t arm_read_src_reg(int r) {
    r &= 15;
    uint32_t v = cpu.r[r];
    if (r == 15) v += 8u;  // PC reads as PC+8 in DP shifter operands
    return v;
}

static int execute_one_instruction(void) {
    if (cpu_is_halted()) return 0;

    // Remember the PC before executing
    uint32_t pc    = cpu.r[15];
    uint32_t instr = cpu_fetch();

    bool ok = execute(instr);

    if (cpu_is_halted()) return 0;

    // If execute() didn’t write a new PC (i.e. not a branch),
    // then advance to the next instruction
    if (cpu.r[15] == pc) {
        cpu.r[15] = pc + 4;
    }

    return ok ? 1 : 0;  // VM tracks cycles now
}

uint32_t cpu_fetch(void) {
    uint32_t pc = cpu.r[15];

    // If T was set, normalize to ARM state (silent)
    if (cpu.cpsr & CPSR_T) {
        cpu.cpsr &= ~CPSR_T;
    }

#if defined(CPU_STRICT_FETCH)
    if (pc & 3u) {
        // Unaligned fetch → halt; return an undefined instruction pattern
        cpu_halt();
        return 0xE7F001F0u; // UDF
    }
#endif

    // Range check using the *currently bound* memory
    size_t msz = mem_size();
    if (!mem_is_bound() || msz < 4 || pc > (uint32_t)(msz - 4)) {
        // Out-of-bounds PC → halt; return sentinel
        cpu_halt();
        return 0xDEADDEADu;
    }

    uint32_t instr = mem_read32(pc);
    return instr;
}

void cpu_dump_registers() {
    // This remains a convenience printer for whoever calls it.
    // It's not invoked automatically by the CPU core.
    log_printf("Registers:\n");
    for (int i = 0; i < 16; i++) {
        log_printf("r%-2d = 0x%08x  ", i, cpu.r[i]);
        if ((i + 1) % 4 == 0) log_printf("\n");
    }
}

// -----------------------------------------------------------------------------
// Public stepping
// -----------------------------------------------------------------------------

void cpu_step(void) {
    int cycles = execute_one_instruction();
    if (cycles <= 0) cycles = 1;
    hw_bus_tick(cycles);
    // IRQ handling would go here later
}

// -----------------------------------------------------------------------------
// Exception return helpers
// -----------------------------------------------------------------------------

// If your CPU model already has banked SPSRs, replace this with the real getter.
// For many simple cores, a single 'cpu.spsr' is used for the current exception mode.
static inline uint32_t cpu_get_spsr_current(void) {
    return cpu.spsr;   // adjust if you later add banked SPSRs
}

void cpu_exception_return(uint32_t new_pc) {
    // Restore CPSR from the current mode's SPSR and branch.
    cpu.cpsr = cpu_get_spsr_current();
    cpu.r[15] = new_pc;

    // If you later support Thumb, you may want to align PC based on CPSR.T.
    // bool T = (cpu.cpsr >> 5) & 1;
    // if (T) cpu.r[15] &= ~1u; else cpu.r[15] &= ~3u;
}
