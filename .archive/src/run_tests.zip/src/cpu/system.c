// src/cpu/system.c

#include <stdint.h>
#include <stdbool.h>

#include "cpu.h"         // CPU struct, extern CPU cpu
#include "cpu_flags.h"   // psr_write(), CPSR_* bits, is_user_mode()
#include "system.h"      // prototypes

// --- Barriers: treat as NOPs in this VM ---
void handle_dsb(uint32_t instr) { (void)instr; }
void handle_dmb(uint32_t instr) { (void)instr; }
void handle_isb(uint32_t instr) { (void)instr; }

// --- Software interrupt / SVC ---
void handle_svc(uint32_t instr) {
    (void)instr; // unused in this simplified VM

    uint32_t lr = cpu.r[15] + 4;   // architectural return

    cpu.spsr  = cpu.cpsr;
    cpu.r[14] = lr;

    uint32_t p = cpu.cpsr;
    p = (p & ~0x1Fu) | 0x13u;                 // SVC mode
    p &= ~(1u << 5);                           // T=0 (ARM)
    p |=  (1u << 7);                           // I=1 (mask IRQ)
    p &= ~((0x3Fu << 10) | (0x3u << 25));      // clear IT bits
    cpu.cpsr = p;

    cpu.r[15] = 0x00000008u;                  // vector address
}

// --- MRS (move PSR to register) ---
void handle_mrs(uint32_t instr) {
    uint32_t Rd  = (instr >> 12) & 0xFu;
    uint32_t sps = (instr >> 22) & 1u;   // 0=CPSR, 1=SPSR
    uint32_t val = sps ? cpu.spsr : cpu.cpsr;
    cpu.r[Rd] = val;
}

// --- MSR helpers ---
static void handle_msr_common(uint32_t instr) {
    int spsr_sel   = (instr >> 22) & 1u;      // 0=CPSR, 1=SPSR
    uint32_t fields= (instr >> 16) & 0xFu;    // {f s x c}
    uint32_t op;

    if ((instr >> 25) & 1u) {
        uint32_t imm8 = instr & 0xFFu;
        uint32_t rot2 = ((instr >> 8) & 0xFu) * 2u;
        op = rot2 ? ((imm8 >> rot2) | (imm8 << (32 - rot2))) : imm8;
    } else {
        uint32_t Rm = instr & 0xFu;
        op = cpu.r[Rm];
    }

    if (spsr_sel) {
        if (!is_user_mode()) {
            psr_write(&cpu.spsr, op, fields, 0);
        }
    } else {
        psr_write(&cpu.cpsr, op, fields, 1);
    }
}

void handle_msr(uint32_t instr)     { handle_msr_common(instr); }
void handle_msr_reg(uint32_t instr) { handle_msr_common(instr); }
void handle_msr_imm(uint32_t instr) { handle_msr_common(instr); }

// --- SETEND (endian select) ---
void handle_setend(uint32_t instr) {
    uint32_t E = (instr >> 9) & 1u;
    if (E) cpu.cpsr |=  CPSR_E; else cpu.cpsr &= ~CPSR_E;
}

// --- CPS (change processor state / mask bits / mode change) ---
void handle_cps(uint32_t instr) {
    bool disable = ((instr >> 18) & 1u) != 0;
    bool Mbit    = ((instr >> 17) & 1u) != 0;

    uint32_t mask = 0;
    if (instr & (1u << 8)) mask |= CPSR_A;
    if (instr & (1u << 7)) mask |= CPSR_I;
    if (instr & (1u << 6)) mask |= CPSR_F;

    if (disable) cpu.cpsr |= mask; else cpu.cpsr &= ~mask;

    if (Mbit) {
        uint32_t mode = instr & 0x1Fu;
        cpu.cpsr = (cpu.cpsr & ~0x1Fu) | (mode & 0x1Fu);
    }
}

// -----------------------------------------------------------------------------
// Misc simple handlers referenced by execute()
// -----------------------------------------------------------------------------
void handle_nop(uint32_t instr) { (void)instr; }

void handle_wfi(uint32_t instr) { (void)instr; }

void handle_deadbeef(uint32_t instr) {
    (void)instr;
    cpu.halt_reason = HALT_DEADBEEF;
    cpu_halt();
}

// BKPT #imm16
void handle_bkpt(uint32_t instr) {
    (void)instr; // imm16 not stored
    cpu.halt_reason = HALT_BKPT;
    cpu_halt();
}

// BFC Rd, #lsb, #width   (A32)
// Encoding fields (A/RM v7):
//   Rd   = bits [15:12]
//   lsb  = bits [11:7]
//   msb  = bits [20:16]   (width = msb - lsb + 1)
//   (For BFC the Rn field in the BFI encoding is set to 0b1111.)
// BFC Rd, #lsb, #width  (A32)
void handle_bfc(uint32_t instr) {
    uint32_t Rd  = (instr >> 12) & 0xFu;
    uint32_t lsb = (instr >> 7)  & 0x1Fu;
    uint32_t msb = (instr >> 16) & 0x1Fu;

    if (msb < lsb) {
        // UNPREDICTABLE per ARM ARM; ignore in this VM
        return;
    }

    // IMPORTANT: width must not wrap modulo 32.
    uint32_t raw_width = msb - lsb + 1u;
    uint32_t width     = (raw_width >= 32u) ? 32u : raw_width;

    uint32_t clear_mask;
    if (width == 32u) {
        clear_mask = 0u;  // clear all bits
    } else {
        clear_mask = ~(((1u << width) - 1u) << lsb);
    }

    cpu.r[Rd] &= clear_mask;
    // Flags unaffected
}

// BFI Rd, Rn, #lsb, #width  (A32)
void handle_bfi(uint32_t instr) {
    uint32_t Rd  = (instr >> 12) & 0xFu;
    uint32_t Rn  = (instr >> 0)  & 0xFu;
    uint32_t lsb = (instr >> 7)  & 0x1Fu;
    uint32_t msb = (instr >> 16) & 0x1Fu;

    if (msb < lsb) {
        // Architecturally UNPREDICTABLE; ignore in this VM.
        return;
    }

    uint32_t raw_width = msb - lsb + 1u;
    uint32_t width     = (raw_width >= 32u) ? 32u : raw_width;

    uint32_t field_mask;
    if (width == 32u) {
        field_mask = 0xFFFFFFFFu;             // full 32-bit field
    } else {
        field_mask = ((1u << width) - 1u) << lsb;
    }

    uint32_t src = cpu.r[Rn];
    uint32_t ins = (width == 32u) ? src : ((src << lsb) & field_mask);

    cpu.r[Rd] = (cpu.r[Rd] & ~field_mask) | ins;
    // Flags unaffected.
}

void handle_clz(uint32_t instr) {
    uint32_t Rd = (instr >> 12) & 0xF;
    uint32_t Rm =  instr        & 0xF;
    uint32_t x  = cpu.r[Rm];

    uint32_t n;
#if defined(__GNUC__) || defined(__clang__)
    n = (x == 0) ? 32u : (uint32_t)__builtin_clz(x);
#else
    // Portable fallback
    if (x == 0) {
        n = 32u;
    } else {
        n = 0u;
        while ((x & 0x80000000u) == 0u) { x <<= 1; n++; }
    }
#endif
    cpu.r[Rd] = n;

    // CLZ does NOT modify CPSR flags.
}