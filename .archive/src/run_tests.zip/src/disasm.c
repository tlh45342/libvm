// disasm.c (small starter; grow as you go)
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>   // snprintf

static inline uint32_t ror32(uint32_t x, unsigned r) {
    r &= 31;
    return (x >> r) | (x << (32 - r));
}

// imm24<<2 with sign extension (for B/BL)
static inline int32_t signext_imm24_shl2(uint32_t imm24) {
    return ((int32_t)(imm24 << 8)) >> 6; // arithmetic >> keeps sign; net <<2
}

void disasm_line(uint32_t pc, uint32_t instr, char *out, size_t out_sz) {
    // Default fallback
    snprintf(out, out_sz, ".word 0x%08X", instr);

    uint32_t cond = (instr >> 28) & 0xF; (void)cond;

    // ----- B / BL -----
    if ((instr & 0x0E000000u) == 0x0A000000u) {
        uint32_t imm24  = instr & 0x00FFFFFFu;
        int32_t  offset = signext_imm24_shl2(imm24);
        uint32_t target = pc + 8 + (uint32_t)offset;  // ARM pipeline adds +8
        if (instr & 0x01000000u)
            snprintf(out, out_sz, "bl  0x%08X", target);
        else
            snprintf(out, out_sz, "b   0x%08X", target);
        return;
    }

    // ----- Data-processing (quick MOV/CMP/TST imm) -----
    if ((instr & 0x0C000000u) == 0x00000000u) {
        uint32_t op   = (instr >> 21) & 0xF;
        uint32_t S    = (instr >> 20) & 1u;
        uint32_t Rd   = (instr >> 12) & 0xF;
        uint32_t Rn   = (instr >> 16) & 0xF;

        if (instr & (1u<<25)) { // immediate shifter
            uint32_t imm8  = instr & 0xFF;
            uint32_t rot2  = ((instr >> 8) & 0xF) * 2;
            uint32_t imm32 = ror32(imm8, rot2);

            switch (op) {
                case 0xD: snprintf(out, out_sz, "mov%s r%u, #0x%X", S?"s":"", Rd, imm32); return; // MOV
                case 0xA: snprintf(out, out_sz, "cmp r%u, #0x%X",   Rn, imm32); return;           // CMP
                case 0x8: snprintf(out, out_sz, "tst r%u, #0x%X",   Rn, imm32); return;           // TST
                default: break; // fall through to generic cases below if needed
            }
        }
    }

    // ----- Single data transfer (LDR/STR imm & byte) -----
    if ((instr & 0x0C000000u) == 0x04000000u) {
        uint32_t L = (instr >> 20) & 1u;
        uint32_t B = (instr >> 22) & 1u;
        uint32_t P = (instr >> 24) & 1u;
        uint32_t U = (instr >> 23) & 1u;
        uint32_t Rn= (instr >> 16) & 0xF;
        uint32_t Rd= (instr >> 12) & 0xF;
        uint32_t I = (instr >> 25) & 1u;

        const char *mn = (L ? (B ? "ldrb" : "ldr") : (B ? "strb" : "str"));

        if (!I) {
            uint32_t imm12 = instr & 0xFFF;
            int32_t off = U ? (int32_t)imm12 : -(int32_t)imm12;

            char base[6];
            if      (Rn == 13) snprintf(base, sizeof base, "sp");
            else if (Rn == 15) snprintf(base, sizeof base, "pc");
            else               snprintf(base, sizeof base, "r%u", Rn);

            if (P) snprintf(out, out_sz, "%s r%u, [%s, #%d]", mn, Rd, base, off);
            else   snprintf(out, out_sz, "%s r%u, [%s], #%d", mn, Rd, base, off);
            return;
        }
        // (reg-offset variants omitted for brevity)
    }
	
	// ----- Data-processing (quick MOV/CMP/TST/SUB/ADD imm) -----
	if ((instr & 0x0C000000u) == 0x00000000u) {
		uint32_t op   = (instr >> 21) & 0xF;
		uint32_t S    = (instr >> 20) & 1u;
		uint32_t Rd   = (instr >> 12) & 0xF;
		uint32_t Rn   = (instr >> 16) & 0xF;

		if (instr & (1u<<25)) { // immediate shifter
			uint32_t imm8  = instr & 0xFF;
			uint32_t rot2  = ((instr >> 8) & 0xF) * 2;
			uint32_t imm32 = (imm8 >> rot2) | (imm8 << (32 - rot2)); // simple ror

			switch (op) {
				case 0xD: snprintf(out, out_sz, "mov%s r%u, #0x%X", S?"s":"", Rd, imm32); return; // MOV
				case 0xA: snprintf(out, out_sz, "cmp r%u, #0x%X",   Rn, imm32); return;           // CMP
				case 0x8: snprintf(out, out_sz, "tst r%u, #0x%X",   Rn, imm32); return;           // TST
				case 0x2: snprintf(out, out_sz, "sub%s r%u, r%u, #0x%X", S?"s":"", Rd, Rn, imm32); return; // SUB
				case 0x4: snprintf(out, out_sz, "add%s r%u, r%u, #0x%X", S?"s":"", Rd, Rn, imm32); return; // ADD
				case 0x0: snprintf(out, out_sz, "and%s r%u, r%u, #0x%X", S?"s":"", Rd, Rn, imm32); return; // AND
				case 0x1: snprintf(out, out_sz, "eor%s r%u, r%u, #0x%X", S?"s":"", Rd, Rn, imm32); return; // EOR
				case 0xC: snprintf(out, out_sz, "orr%s r%u, r%u, #0x%X", S?"s":"", Rd, Rn, imm32); return; // ORR
			}
		}
	}

    // ----- Block transfers: LDM/STM (bits 27:25 == 0b100) -----
    if ((instr & 0x0E000000u) == 0x08000000u) {
        uint32_t P = (instr >> 24) & 1u;
        uint32_t U = (instr >> 23) & 1u;
        uint32_t W = (instr >> 21) & 1u;
        uint32_t L = (instr >> 20) & 1u;
        uint32_t Rn = (instr >> 16) & 0xF;
        uint32_t reglist = instr & 0xFFFF;

        const char *mn = L ? "ldm" : "stm";
        const char *am = (!U && !P) ? "da" :
                         (!U &&  P) ? "db" :
                         ( U && !P) ? "ia" : "ib";

        char base[8];
        if      (Rn == 13) snprintf(base, sizeof base, "sp");
        else if (Rn == 15) snprintf(base, sizeof base, "pc");
        else               snprintf(base, sizeof base, "r%u", Rn);

        char regs[128]; size_t n = 0;
        n += snprintf(regs+n, sizeof regs - n, "{");
        bool first = true;
        for (int r = 0; r <= 15; ++r) {
            if (reglist & (1u << r)) {
                if (!first) n += snprintf(regs+n, sizeof regs - n, ", ");
                if      (r == 13) n += snprintf(regs+n, sizeof regs - n, "sp");
                else if (r == 14) n += snprintf(regs+n, sizeof regs - n, "lr");
                else if (r == 15) n += snprintf(regs+n, sizeof regs - n, "pc");
                else              n += snprintf(regs+n, sizeof regs - n, "r%d", r);
                first = false;
            }
        }
        n += snprintf(regs+n, sizeof regs - n, "}");

        snprintf(out, out_sz, "%s%s %s%s, %s", mn, am, base, W ? "!" : "", regs);
        return;
    }

    // Fallback is already set at the top
}
