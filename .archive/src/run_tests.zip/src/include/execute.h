#pragma once
#include <stdint.h>
#include <stdbool.h>
bool execute(uint32_t instr);