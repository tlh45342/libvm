// src/include/version.h
#ifndef VERSION_H
#define VERSION_H

#define VERSION "0.0.128"

#endif