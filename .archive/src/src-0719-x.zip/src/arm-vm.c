#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BUILD "0.0.19"
#define RAM_SIZE (512 * 1024 * 1024)
#define ENTRY_POINT 0x8000
#define UART_BASE 0x09000000
#define UART_DR   0x00
#define CRT_BASE  0x20000000
#define CRT_ROWS 25
#define CRT_COLS 80
#define CRT_SIZE (CRT_ROWS * CRT_COLS * 2)
#define MAX_CYCLES 1000000

bool trace_all = true;

// ARM CPU state
struct arm_cpu {
    uint32_t r[16];     // R0-R15 (R15 is PC)
    uint32_t cpsr;      // Basic CPSR for flags
};

uint8_t *ram;
struct arm_cpu cpu;

static inline uint32_t ror(uint32_t val, int r) {
    return (val >> r) | (val << (32 - r));
}

void dump_registers() {
    printf("Registers:\n");
    for (int i = 0; i < 16; i++) {
        printf("r%-2d = 0x%08x  ", i, cpu.r[i]);
        if ((i + 1) % 4 == 0) printf("\n");
    }
}

uint32_t fetch_instruction() {
    uint32_t pc = cpu.r[15];
    if (pc >= RAM_SIZE - 4) {
        fprintf(stderr, "PC out of range: 0x%08x\n", pc);
        exit(1);
    }

    uint8_t *p = ram + pc;
    uint32_t instr = p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);

    cpu.r[15] += 4;
    return instr;
}

void write_uart(uint8_t val) {
    putchar(val);
    fflush(stdout);
}

void display_crt() {
    printf("\n==== CRT OUTPUT ====\n");
    for (int row = 0; row < CRT_ROWS; row++) {
        for (int col = 0; col < CRT_COLS; col++) {
            uint32_t offset = CRT_BASE + (row * CRT_COLS + col) * 2;
            char ch = ram[offset];
            putchar((ch >= 32 && ch < 127) ? ch : '.');
        }
        printf("\n");
    }
    printf("====================\n");
}

uint32_t read_mem32(uint32_t addr) {
    if (addr >= UART_BASE && addr < UART_BASE + 0x1000) {
        return 0;
    }
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "Read out of bounds: 0x%08x\n", addr);
        exit(1);
    }
    return *(uint32_t*)(ram + addr);
}

void write_mem32(uint32_t addr, uint32_t val) {
    if (addr == UART_BASE + UART_DR) {
        write_uart(val & 0xFF);
        return;
    }
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "Write out of bounds: 0x%08x\n", addr);
        exit(1);
    }
    *(uint32_t*)(ram + addr) = val;
    if (trace_all && addr >= 0x1fff0000) {
        printf("  [mem write] mem[0x%08x] <= 0x%08x\n", addr, val);
    }
}

bool execute(uint32_t instr) {
    static int cycle = 0;
    if (trace_all) {
        printf("[Cycle %08d] PC=0x%08x Instr=0x%08x\n", cycle++, cpu.r[15] - 4, instr);
    }

    if ((instr & 0x0fffffff) == 0xe320f000) {
        if (trace_all) printf("  [WFI] Halt\n");
        return false;

    } else if ((instr & 0x0ffffff0) == 0xe1a00000) {
        int rd = (instr >> 12) & 0xf;
        int rn = instr & 0xf;
        cpu.r[rd] = cpu.r[rn];
        if (trace_all) printf("  [MOV] r%d = r%d (0x%08x)\n", rd, rn, cpu.r[rd]);

    } else if ((instr & 0x0fe00000) == 0xe2800000) {
        int rd = (instr >> 12) & 0xf;
        int rn = (instr >> 16) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[rd] = cpu.r[rn] + imm;
        if (trace_all) printf("  [ADD] r%d = r%d + 0x%x => 0x%08x\n", rd, rn, imm, cpu.r[rd]);

    } else if ((instr & 0x0fe00000) == 0xe2400000) {
        int rd = (instr >> 12) & 0xf;
        int rn = (instr >> 16) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[rd] = cpu.r[rn] - imm;
        if (trace_all) printf("  [SUB] r%d = r%d - 0x%x => 0x%08x\n", rd, rn, imm, cpu.r[rd]);

    } else if ((instr & 0x0ff00000) == 0x03a00000 ||
               (instr & 0x0ff00000) == 0x03e00000) {
        int rd = (instr >> 12) & 0xf;
        uint32_t imm8 = instr & 0xff;
        int rotate = ((instr >> 8) & 0xf) * 2;
        uint32_t imm = (rotate == 0) ? imm8 : ror(imm8, rotate);
        cpu.r[rd] = imm;
        if (trace_all) printf("  [MOV imm] r%d = 0x%08x (rotate=%d)\n", rd, imm, rotate);

    } else if ((instr & 0x0f7f0000) == 0x049f0000 && ((instr >> 12) & 0xf) == 15) {
        uint32_t offset = instr & 0xfff;
        cpu.r[15] = read_mem32(cpu.r[13]);
        cpu.r[13] += offset;
        if (trace_all) printf("  [LDR PC, [SP], #%d] => PC=0x%08x\n", offset, cpu.r[15]);
        return true;

    } else if ((instr & 0xfffff000) == 0xe49df000) {
        int imm = instr & 0xfff;
        cpu.r[15] = read_mem32(cpu.r[13]);
        cpu.r[13] += imm;
        if (trace_all) {
            printf("  [LDR post] PC <= mem[SP]=0x%08x; SP += 0x%x => 0x%08x\n",
                   cpu.r[15], imm, cpu.r[13]);
        }
        return true;

    } else if ((instr & 0x0fff0000) == 0x059f0000) {
        int rd = (instr >> 12) & 0xf;
        int imm = instr & 0xfff;
        uint32_t addr = (cpu.r[15] & ~3) + imm;
        uint32_t val = read_mem32(addr);
        cpu.r[rd] = val;
        if (trace_all) printf("  [LDR literal] r%d = mem[0x%08x] => 0x%08x\n", rd, addr, val);
        if (rd == 15) return true;

    } else if ((instr & 0x0f000000) == 0x0a000000) {
        int offset = instr & 0x00ffffff;
        if (offset & 0x00800000) offset |= 0xff000000;
        offset <<= 2;
        cpu.r[15] += offset;
        if (trace_all) printf("  [B] Branch to 0x%08x\n", cpu.r[15]);

    } else if ((instr & 0x0f000000) == 0x0b000000) {
        int offset = instr & 0x00ffffff;
        if (offset & 0x00800000) offset |= 0xff000000;
        offset <<= 2;
        cpu.r[14] = cpu.r[15];
        cpu.r[15] += offset;
        if (trace_all) printf("  [BL] Branch with link to 0x%08x\n", cpu.r[15]);

    } else if ((instr & 0x0ffff000) == 0xe8bd0000) {
        uint16_t reglist = instr & 0xFFFF;
        if (trace_all) printf("  [POP] reglist=0x%04x\n", reglist);
        for (int i = 0; i < 16; i++) {
            if (reglist & (1 << i)) {
                cpu.r[i] = read_mem32(cpu.r[13]);
                if (trace_all) printf("    r%d <= [sp] = 0x%08x\n", i, cpu.r[i]);
                cpu.r[13] += 4;
            }
        }
        if (reglist & (1 << 15)) {
            if (trace_all) printf("    PC restored => 0x%08x\n", cpu.r[15]);
            return true;
        }

    } else if ((instr & 0xffff0000) == 0xe52d0000) {
        int rd = (instr >> 12) & 0xf;
        int imm = instr & 0xfff;
        bool u_bit = instr & (1 << 23);
        cpu.r[13] = u_bit ? (cpu.r[13] + imm) : (cpu.r[13] - imm);
        write_mem32(cpu.r[13], cpu.r[rd]);
        if (trace_all) printf("  [STR pre-%s] mem[SP=0x%08x] = r%d (0x%08x)\n",
               u_bit ? "inc" : "dec", cpu.r[13], rd, cpu.r[rd]);

    } else {
        printf("Unknown instruction: 0x%08x at 0x%08x\n", instr, cpu.r[15] - 4);
        dump_registers();
        return false;
    }
    return true;
}

void load_binary(const char* path, uint32_t addr) {
    FILE* f = fopen(path, "rb");
    if (!f) { perror("open"); exit(1); }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    fread(ram + addr, 1, size, f);
    fclose(f);
}

void repl_shell() {
    char line[256];
    while (1) {
        printf("arm-vm> ");
        if (!fgets(line, sizeof(line), stdin)) break;

        if (strncmp(line, "quit", 4) == 0) break;
        else if (strncmp(line, "load", 4) == 0) {
            char filename[128];
            uint32_t addr;
            if (sscanf(line + 4, "%127s %x", filename, &addr) == 2) {
                load_binary(filename, addr);
                printf("Loaded %s at 0x%08x\n", filename, addr);
                cpu.r[15] = addr;
            } else {
                printf("Usage: load <file> <hex addr>\n");
            }
        } else if (strncmp(line, "run", 3) == 0) {
            for (int cycles = 0; cycles < MAX_CYCLES; cycles++) {
                uint32_t instr = fetch_instruction();
                if (!execute(instr)) break;
            }
            printf("\n[VM halted]\n");
        } else if (strncmp(line, "regs", 4) == 0) {
            dump_registers();
        } else if (strncmp(line, "show crt", 9) == 0) {
            display_crt();
        } else {
            printf("Unknown command. Available: load, run, regs, show crt, quit\n");
        }
    }
}

int main() {
    printf("ARM VM Emulator %s\n", BUILD);

    ram = calloc(1, RAM_SIZE);
    if (!ram) { perror("calloc"); return 1; }

    memset(&cpu, 0, sizeof(cpu));
    cpu.r[13] = RAM_SIZE - 4; // SP
    cpu.r[15] = ENTRY_POINT;  // PC

    repl_shell();

    free(ram);
    return 0;
}
