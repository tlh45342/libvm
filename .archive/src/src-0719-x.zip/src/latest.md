O:\min-kernel-2>arm-none-eabi-objdump -D -b binary -m arm -M reg-names-std -EL --adjust-vma=0x8000 kernel.bin

kernel.bin:     file format binary


Disassembly of section .data:

00008000 <.data>:
    8000:       e3a0d902        mov     sp, #32768      ; 0x8000
    8004:       e59fe008        ldr     lr, [pc, #8]    ; 0x8014
    8008:       eb00008e        bl      0x8248
    800c:       e320f003        wfi
    8010:       eafffffd        b       0x800c
    8014:       0000800c        andeq   r8, r0, r12
    8018:       e52db004        push    {r11}           ; (str r11, [sp, #-4]!)
    801c:       e28db000        add     r11, sp, #0
    8020:       e24dd014        sub     sp, sp, #20
    8024:       e50b200c        str     r2, [r11, #-12]
    8028:       e50b3010        str     r3, [r11, #-16]
    802c:       e1a03000        mov     r3, r0
    8030:       e54b3005        strb    r3, [r11, #-5]
    8034:       e1a03001        mov     r3, r1
    8038:       e54b3006        strb    r3, [r11, #-6]
    803c:       e51b300c        ldr     r3, [r11, #-12]
    8040:       e3530000        cmp     r3, #0
    8044:       ba000022        blt     0x80d4
    8048:       e51b300c        ldr     r3, [r11, #-12]
    804c:       e3530018        cmp     r3, #24
    8050:       ca00001f        bgt     0x80d4
    8054:       e51b3010        ldr     r3, [r11, #-16]
    8058:       e3530000        cmp     r3, #0
    805c:       ba00001c        blt     0x80d4
    8060:       e51b3010        ldr     r3, [r11, #-16]
    8064:       e353004f        cmp     r3, #79 ; 0x4f
    8068:       ca000019        bgt     0x80d4
    806c:       e3a01202        mov     r1, #536870912  ; 0x20000000
    8070:       e51b200c        ldr     r2, [r11, #-12]
    8074:       e1a03002        mov     r3, r2
    8078:       e1a03103        lsl     r3, r3, #2
    807c:       e0833002        add     r3, r3, r2
    8080:       e1a03203        lsl     r3, r3, #4
    8084:       e1a02003        mov     r2, r3
    8088:       e51b3010        ldr     r3, [r11, #-16]
    808c:       e0823003        add     r3, r2, r3
    8090:       e1a03083        lsl     r3, r3, #1
    8094:       e0813003        add     r3, r1, r3
    8098:       e55b2005        ldrb    r2, [r11, #-5]
    809c:       e5c32000        strb    r2, [r3]
    80a0:       e3a01202        mov     r1, #536870912  ; 0x20000000
    80a4:       e51b200c        ldr     r2, [r11, #-12]
    80a8:       e1a03002        mov     r3, r2
    80ac:       e1a03103        lsl     r3, r3, #2
    80b0:       e0833002        add     r3, r3, r2
    80b4:       e1a03203        lsl     r3, r3, #4
    80b8:       e1a02003        mov     r2, r3
    80bc:       e51b3010        ldr     r3, [r11, #-16]
    80c0:       e0823003        add     r3, r2, r3
    80c4:       e1a03083        lsl     r3, r3, #1
    80c8:       e0813003        add     r3, r1, r3
    80cc:       e55b2006        ldrb    r2, [r11, #-6]
    80d0:       e5c32001        strb    r2, [r3, #1]
    80d4:       e320f000        nop     {0}
    80d8:       e28bd000        add     sp, r11, #0
    80dc:       e49db004        pop     {r11}           ; (ldr r11, [sp], #4)
    80e0:       e12fff1e        bx      lr
    80e4:       e52db008        str     r11, [sp, #-8]!
    80e8:       e58de004        str     lr, [sp, #4]
    80ec:       e28db004        add     r11, sp, #4
    80f0:       e24dd008        sub     sp, sp, #8
    80f4:       e1a03000        mov     r3, r0
    80f8:       e54b3005        strb    r3, [r11, #-5]
    80fc:       e55b3005        ldrb    r3, [r11, #-5]
    8100:       e353000a        cmp     r3, #10
    8104:       1a00000b        bne     0x8138
    8108:       e3083290        movw    r3, #33424      ; 0x8290
    810c:       e3403000        movt    r3, #0
    8110:       e3a02000        mov     r2, #0
    8114:       e5832000        str     r2, [r3]
    8118:       e308328c        movw    r3, #33420      ; 0x828c
    811c:       e3403000        movt    r3, #0
    8120:       e5933000        ldr     r3, [r3]
    8124:       e2832001        add     r2, r3, #1
    8128:       e308328c        movw    r3, #33420      ; 0x828c
    812c:       e3403000        movt    r3, #0
    8130:       e5832000        str     r2, [r3]
    8134:       ea00001f        b       0x81b8
    8138:       e308328c        movw    r3, #33420      ; 0x828c
    813c:       e3403000        movt    r3, #0
    8140:       e5932000        ldr     r2, [r3]
    8144:       e3083290        movw    r3, #33424      ; 0x8290
    8148:       e3403000        movt    r3, #0
    814c:       e5933000        ldr     r3, [r3]
    8150:       e55b0005        ldrb    r0, [r11, #-5]
    8154:       e3a01007        mov     r1, #7
    8158:       ebffffae        bl      0x8018
    815c:       e3083290        movw    r3, #33424      ; 0x8290
    8160:       e3403000        movt    r3, #0
    8164:       e5933000        ldr     r3, [r3]
    8168:       e2832001        add     r2, r3, #1
    816c:       e3083290        movw    r3, #33424      ; 0x8290
    8170:       e3403000        movt    r3, #0
    8174:       e5832000        str     r2, [r3]
    8178:       e3083290        movw    r3, #33424      ; 0x8290
    817c:       e3403000        movt    r3, #0
    8180:       e5933000        ldr     r3, [r3]
    8184:       e353004f        cmp     r3, #79 ; 0x4f
    8188:       da00000a        ble     0x81b8
    818c:       e3083290        movw    r3, #33424      ; 0x8290
    8190:       e3403000        movt    r3, #0
    8194:       e3a02000        mov     r2, #0
    8198:       e5832000        str     r2, [r3]
    819c:       e308328c        movw    r3, #33420      ; 0x828c
    81a0:       e3403000        movt    r3, #0
    81a4:       e5933000        ldr     r3, [r3]
    81a8:       e2832001        add     r2, r3, #1
    81ac:       e308328c        movw    r3, #33420      ; 0x828c
    81b0:       e3403000        movt    r3, #0
    81b4:       e5832000        str     r2, [r3]
    81b8:       e308328c        movw    r3, #33420      ; 0x828c
    81bc:       e3403000        movt    r3, #0
    81c0:       e5933000        ldr     r3, [r3]
    81c4:       e3530018        cmp     r3, #24
    81c8:       da000003        ble     0x81dc
    81cc:       e308328c        movw    r3, #33420      ; 0x828c
    81d0:       e3403000        movt    r3, #0
    81d4:       e3a02000        mov     r2, #0
    81d8:       e5832000        str     r2, [r3]
    81dc:       e320f000        nop     {0}
    81e0:       e24bd004        sub     sp, r11, #4
    81e4:       e59db000        ldr     r11, [sp]
    81e8:       e28dd004        add     sp, sp, #4
    81ec:       e49df004        pop     {pc}            ; (ldr pc, [sp], #4)
    81f0:       e52db008        str     r11, [sp, #-8]!
    81f4:       e58de004        str     lr, [sp, #4]
    81f8:       e28db004        add     r11, sp, #4
    81fc:       e24dd008        sub     sp, sp, #8
    8200:       e50b0008        str     r0, [r11, #-8]
    8204:       ea000005        b       0x8220
    8208:       e51b3008        ldr     r3, [r11, #-8]
    820c:       e2832001        add     r2, r3, #1
    8210:       e50b2008        str     r2, [r11, #-8]
    8214:       e5d33000        ldrb    r3, [r3]
    8218:       e1a00003        mov     r0, r3
    821c:       ebffffb0        bl      0x80e4
    8220:       e51b3008        ldr     r3, [r11, #-8]
    8224:       e5d33000        ldrb    r3, [r3]
    8228:       e3530000        cmp     r3, #0
    822c:       1afffff5        bne     0x8208
    8230:       e320f000        nop     {0}
    8234:       e320f000        nop     {0}
    8238:       e24bd004        sub     sp, r11, #4
    823c:       e59db000        ldr     r11, [sp]
    8240:       e28dd004        add     sp, sp, #4
    8244:       e49df004        pop     {pc}            ; (ldr pc, [sp], #4)
    8248:       e52db008        str     r11, [sp, #-8]!
    824c:       e58de004        str     lr, [sp, #4]
    8250:       e28db004        add     r11, sp, #4
    8254:       e308026c        movw    r0, #33388      ; 0x826c
    8258:       e3400000        movt    r0, #0
    825c:       ebffffe3        bl      0x81f0
    8260:       e320f003        wfi
    8264:       eafffffd        b       0x8260
    8268:       20000000        andcs   r0, r0, r0
    826c:       6c6c6548        cfstr64vs       mvdx6, [r12], #-288     ; 0xfffffee0
    8270:       7266206f        rsbvc   r2, r6, #111    ; 0x6f
    8274:       76206d6f        strtvc  r6, [r0], -pc, ror #26
    8278:       75747269        ldrbvc  r7, [r4, #-617]!        ; 0xfffffd97
    827c:       43206c61                        ; <UNDEFINED> instruction: 0x43206c61
    8280:       6b205452        blvs    0x81d3d0
    8284:       656e7265        strbvs  r7, [lr, #-613]!        ; 0xfffffd9b
    8288:       000a216c        andeq   r2, r10, r12, ror #2