#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define VERSION "0.0.46"
#define RAM_SIZE (512 * 1024 * 1024)
#define ENTRY_POINT 0x8000
#define UART_BASE 0x09000000
#define UART_DR   0x00

#define CRT_BASE   0x0A000000  // 160MB (just above UART)
#define CRT_ROWS 25
#define CRT_COLS 80
#define CRT_SIZE (CRT_ROWS * CRT_COLS * 2)
#define MAX_CYCLES 1000000

bool trace_all = true;

#define MAX_BACKTRACE 64
uint32_t call_stack[MAX_BACKTRACE];
int call_depth = 0;
bool cpu_halted = false;

typedef enum {
    DBG_NONE        = 0,
    DBG_INSTR       = 1 << 0,  // Instruction decode
    DBG_MEM_READ    = 1 << 1,  // Memory read access
    DBG_MEM_WRITE   = 1 << 2,  // Memory write access
    DBG_STACK       = 1 << 3,  // Stack-specific access
    DBG_REG         = 1 << 4,  // Register set/read
    DBG_ALL         = 0xFFFFFFFF
} DebugFlags;

DebugFlags debug_flags = DBG_NONE;

struct arm_cpu {
    uint32_t r[16];
    uint32_t cpsr;
};

uint8_t *ram;
struct arm_cpu cpu;

// ----------

void execute_line(char* line);
void show_crt(void);  
bool execute(uint32_t instr);
void load_binary(const char* path, uint32_t addr);
void dump_backtrace(void);
uint8_t read_mem8(uint32_t addr);
void write_mem8(uint32_t addr, uint8_t val);

// ----------

void examine_memory(uint32_t start, uint32_t end) {
    if (start >= RAM_SIZE || end >= RAM_SIZE || start > end) {
        printf("[ERROR] Invalid memory range 0x%08x - 0x%08x\n", start, end);
        return;
    }

    for (uint32_t addr = start; addr <= end; addr += 16) {
        printf("0x%08x: ", addr);
        for (int i = 0; i < 16 && (addr + i) <= end; i++) {
            printf("%02x ", ram[addr + i]);
        }
        printf(" |");
        for (int i = 0; i < 16 && (addr + i) <= end; i++) {
            uint8_t c = ram[addr + i];
            printf("%c", (c >= 32 && c < 127) ? c : '.');
        }
        printf("|\n");
    }
}

static inline uint32_t ror(uint32_t val, int r) {
    return (val >> r) | (val << (32 - r));
}

void dump_registers() {
    printf("Registers:\n");
    for (int i = 0; i < 16; i++) {
        printf("r%-2d = 0x%08x  ", i, cpu.r[i]);
        if ((i + 1) % 4 == 0) printf("\n");
    }
}

uint32_t fetch_instruction() {
    uint32_t pc = cpu.r[15];
    if (pc >= RAM_SIZE - 4) {
        fprintf(stderr, "[ERROR] PC out of range: 0x%08x\n", pc);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xDEADDEAD;
    }
    uint8_t *p = ram + pc;
    uint32_t instr = p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
    cpu.r[15] += 4;
    return instr;
}

void write_uart(uint8_t val) {
    putchar(val);
    fflush(stdout);
}

void show_crt() {
    printf("\n==== CRT OUTPUT ====\n");
    for (int row = 0; row < CRT_ROWS; row++) {
        for (int col = 0; col < CRT_COLS; col++) {
            uint32_t offset = CRT_BASE + (row * CRT_COLS + col) * 2;
            char ch = ram[offset];
            putchar((ch >= 32 && ch < 127) ? ch : '.');
        }
        printf("\n");
    }
    printf("====================\n");
}

uint8_t read_mem8(uint32_t addr) {
    if (addr >= UART_BASE && addr < UART_BASE + 0x1000)
        return 0;

    if (addr >= RAM_SIZE) {
        fprintf(stderr, "Read8 out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xFF;
    }

    return ram[addr];
}

uint32_t read_mem32(uint32_t addr) {
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "[ERROR] Read out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
       cpu_halted = true;
       return 0xDEADDEAD;
   }
   return *(uint32_t*)(ram + addr);  // ✅ FIX: perform the actual read
}

void write_mem8(uint32_t addr, uint8_t val) {
    if (addr >= RAM_SIZE) {
        fprintf(stderr, "[ERROR] write_mem8 out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return;
    }

    ram[addr] = val;

    // Optional: show stack or CRT writes
    if (trace_all && (addr == cpu.r[13] || (addr >= cpu.r[13] && addr <= cpu.r[13] + 16)))
        printf("  [stack byte write] mem[0x%08x] <= 0x%02x (SP=0x%08x)\n", addr, val, cpu.r[13]);

    if (trace_all && addr >= CRT_BASE && addr < CRT_BASE + CRT_SIZE)
        printf("  [CRT write] mem[0x%08x] <= 0x%02x\n", addr, val);
}

void write_mem32(uint32_t addr, uint32_t val) {
    if (addr == UART_BASE + UART_DR) {
        write_uart(val & 0xFF);
        return;
    }

    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "[ERROR] Write out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return;
    }

    *(uint32_t*)(ram + addr) = val;

    if (trace_all && (addr == cpu.r[13] || (addr >= cpu.r[13] && addr <= cpu.r[13] + 16)))
        printf("  [stack write] mem[0x%08x] <= 0x%08x (SP=0x%08x)\n", addr, val, cpu.r[13]);

    if (trace_all && addr >= 0x1fff0000)
       if (debug_flags & DBG_MEM_WRITE) {
            printf("  [mem write] mem[0x%08x] <= 0x%08x\n", addr, val);
       }
}

bool handle_mov(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rm = instr & 0xf;
    cpu.r[rd] = cpu.r[rm];
    if (trace_all) {
        printf("  [MOV] r%d = r%d (0x%08x)\n", rd, rm, cpu.r[rd]);
    }
	return true;
}

bool handle_add(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rn = (instr >> 16) & 0xf;
    int imm = instr & 0xfff;
    cpu.r[rd] = cpu.r[rn] + imm;
    if (trace_all) printf("  [ADD] r%d = r%d + 0x%x => 0x%08x\n", rd, rn, imm, cpu.r[rd]);
    return true;
}

bool handle_ldrb_reg(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf;
    uint8_t rd = (instr >> 12) & 0xf;
    uint32_t addr = cpu.r[rn];

    uint8_t byte = read_mem8(addr);  // ✅ Safe access with bounds check

    cpu.r[rd] = byte;

    if (trace_all || (debug_flags & DBG_MEM_READ)) {
        printf("  [LDRB reg] r%d = mem[0x%08x] => 0x%02x\n", rd, addr, byte);
    }

    return true;
}

bool handle_sub(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rn = (instr >> 16) & 0xf;
    int imm = instr & 0xfff;
    cpu.r[rd] = cpu.r[rn] - imm;

    if (trace_all) {
        if (rd == 13 || rn == 13) {
            printf("  [SUB] SP adjustment: r%d = r%d - 0x%x => 0x%08x\n",
                   rd, rn, imm, cpu.r[rd]);
        } else {
            printf("  [SUB] r%d = r%d - 0x%x => 0x%08x\n",
                   rd, rn, imm, cpu.r[rd]);
        }
    }

    return true;
}

bool handle_mov_imm(uint32_t instr) {
    if (debug_flags & DBG_INSTR) {
        printf(">> Trying handle_mov_imm for 0x%08x\n", instr);
        printf("  [DEBUG] Inside handle_mov_imm: instr = 0x%08x\n", instr);
    }

    if ((instr & 0x0ff00000) != 0x03a00000) {
        if (debug_flags & DBG_INSTR) {
            printf("  [DEBUG] MOV IMM check failed: instr & 0x0ff00000 = 0x%08x\n", instr & 0x0ff00000);
        }
        return false;
    }

    int rd = (instr >> 12) & 0xF;
    uint32_t imm8 = instr & 0xFF;
    int rotate = ((instr >> 8) & 0xF) * 2;
    uint32_t imm = (rotate == 0) ? imm8 : ror(imm8, rotate);

    cpu.r[rd] = imm;

    if (debug_flags & DBG_INSTR) {
        printf("  [MOV imm] r%d = 0x%08x\n", rd, imm);
    }

    return true;
}

bool handle_ldr_literal(uint32_t instr) {
    int rd = (instr >> 12) & 0xF;
    uint32_t imm12 = instr & 0xFFF;

    // PC was already incremented by 4 in fetch_instruction()
    uint32_t pc = cpu.r[15] - 4;
    uint32_t literal_addr = pc + 8 + imm12;

    if (literal_addr >= RAM_SIZE - 4) {
        fprintf(stderr, "LDR literal address out of bounds: 0x%08x\n", literal_addr);
        return false;
    }

    uint32_t value = read_mem32(literal_addr);
    cpu.r[rd] = value;

    if (trace_all) {
        printf("  [LDR literal] r%d = mem[0x%08x] => 0x%08x\n",
               rd, literal_addr, value);
    }

    return true;
}

bool handle_str_predec(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rn = (instr >> 16) & 0xf;
    int offset = instr & 0xfff;
    cpu.r[rn] -= offset;
    write_mem32(cpu.r[rn], cpu.r[rd]);
    if (trace_all) {
        printf("  [mem write] mem[0x%08x] <= 0x%08x\n", cpu.r[rn], cpu.r[rd]);
        printf("  [STR pre-dec] mem[SP=0x%08x] = r%d (0x%08x)\n", cpu.r[rn], rd, cpu.r[rd]);
    }
    return true;
}

bool handle_b(uint32_t instr) {
    int32_t offset = (instr & 0x00ffffff) << 2;

    // Sign-extend 26-bit offset
    if (offset & (1 << 25)) {
        offset |= 0xfc000000;
    }

    // Branch target: PC was incremented by 4 already (in fetch_instruction)
    cpu.r[15] = cpu.r[15] + 4 + offset;

    if (trace_all) {
        printf("  [B] Branch to 0x%08x\n", cpu.r[15]);
    }

    return true;
}

bool handle_strb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf; // base register
    uint8_t rd = (instr >> 12) & 0xf; // source register
    uint32_t offset = instr & 0xfff;
    bool up = instr & (1 << 23);      // U bit: add/subtract

    uint32_t base = cpu.r[rn];
    uint32_t addr = up ? base + offset : base - offset;

    uint8_t byte = cpu.r[rd] & 0xff;
    ram[addr] = byte;

    if (trace_all) {
        printf("  [STRB pre-%s imm] mem[0x%08x] <= r%d (byte=0x%02x)\n",
               up ? "inc" : "dec", addr, rd, byte);
    }

    return true;
}

bool handle_strb_postimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;  // base register
    uint8_t rd = (instr >> 12) & 0xF;  // source register
    uint32_t offset = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint8_t byte = cpu.r[rd] & 0xFF;

    write_mem8(addr, byte);  // ✅ use proper memory write

    cpu.r[rn] += offset;     // ✅ post-increment

    if (trace_all) {
        printf("  [STRB post-imm] mem[0x%08x] <= r%d (byte=0x%02x); r%d += 0x%x => 0x%08x\n",
               addr, rd, byte, rn, offset, cpu.r[rn]);
    }

    return true;
}

bool handle_bl(uint32_t instr) {
    int32_t offset = (instr & 0x00ffffff) << 2;

    // Sign-extend 26-bit offset
    if (offset & (1 << 25)) {
        offset |= 0xfc000000;  // Fill upper bits with 1s
    }

    cpu.r[14] = cpu.r[15];           // Save return address (already PC + 4)
    cpu.r[15] = cpu.r[15] + offset;  // Add offset (relative to PC + 8)
                                     // Since r15 was PC+4, we add offset to PC+4, then add +4 more
    cpu.r[15] += 4;                  // Adjust for ARM PC being PC+8 during execution

    if (trace_all) {
        printf("  [BL] Branch with link to 0x%08x\n", cpu.r[15]);
    }
	
	if (call_depth < MAX_BACKTRACE) {
    call_stack[call_depth++] = cpu.r[15];
    }
	
    return true;
}

bool handle_str_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf;     // Base register
    uint8_t rd = (instr >> 12) & 0xf;     // Source register (value to store)
    uint32_t offset = instr & 0xfff;      // Immediate 12-bit offset
    bool up = instr & (1 << 23);          // U bit: add (1) or subtract (0)

    uint32_t base = cpu.r[rn];
    uint32_t addr = up ? base + offset : base - offset;

    cpu.r[rn] = addr;                     // Write-back with pre-indexing
    write_mem32(addr, cpu.r[rd]);        // Store 32-bit word

    if (trace_all) {
        printf("  [STR pre-%s imm] mem[0x%08x] <= r%d (0x%08x)\n",
               up ? "inc" : "dec", addr, rd, cpu.r[rd]);
    }

    return true;
}

bool handle_add_imm(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rn = (instr >> 16) & 0xf;
    int imm = instr & 0xfff;
    cpu.r[rd] = cpu.r[rn] + imm;
    if (trace_all) {
        printf("  [ADD imm] r%d = r%d (0x%08x) + 0x%x => 0x%08x\n",
               rd, rn, cpu.r[rn], imm, cpu.r[rd]);
    }
    return true;
}

bool handle_movw(uint32_t instr) {
    uint32_t rd = (instr >> 12) & 0xf;
    uint32_t imm4 = (instr >> 16) & 0xf;
    uint32_t imm12 = instr & 0xfff;
    uint32_t imm = (imm4 << 12) | imm12;

    cpu.r[rd] = imm;

    if (trace_all) {
        printf("  [MOVW] r%d = 0x%08x (imm4=0x%x, imm12=0x%03x)\n",
               rd, imm, imm4, imm12);
    }
    return true;
}

bool handle_cmp_imm(uint32_t instr) {
    int rn = (instr >> 16) & 0xf;
    uint32_t imm8 = instr & 0xff;
    int rotate = ((instr >> 8) & 0xf) * 2;
    uint32_t imm = (rotate == 0) ? imm8 : ror(imm8, rotate);

    uint32_t result = cpu.r[rn] - imm;

    // Set CPSR flags (only Z and N for now)
    if (result == 0)
        cpu.cpsr |= (1 << 30);  // Z flag
    else
        cpu.cpsr &= ~(1 << 30);

    if (result & 0x80000000)
        cpu.cpsr |= (1 << 31);  // N flag
    else
        cpu.cpsr &= ~(1 << 31);

    if (trace_all) {
        printf("  [CMP imm] r%d (0x%08x) - 0x%08x => 0x%08x  [N=%d Z=%d]\n",
               rn, cpu.r[rn], imm, result,
               (cpu.cpsr >> 31) & 1, (cpu.cpsr >> 30) & 1);
    }

    return true;
}

bool handle_ldrb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf; // base register
    uint8_t rd = (instr >> 12) & 0xf; // destination register
    uint32_t offset = instr & 0xfff;
    bool up = instr & (1 << 23);      // U bit: add/subtract

    uint32_t base = cpu.r[rn];
    uint32_t addr = up ? base + offset : base - offset;

    uint8_t byte = ram[addr];
    cpu.r[rd] = byte;

    if (trace_all) {
        printf("  [LDRB pre-%s imm] r%d = mem[0x%08x] => 0x%02x\n",
               up ? "inc" : "dec", rd, addr, byte);
    }

    return true;
}

bool handle_stm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back = (instr >> 21) & 1;
    uint32_t addr = cpu.r[rn];

    // Usually STMFD = full descending = SP -= 4 per reg, then store
    int count = __builtin_popcount(reglist);
    addr -= count * 4;

    for (int i = 0; i < 16; i++) {
        if (reglist & (1 << i)) {
            write_mem32(addr, cpu.r[i]);
            addr += 4;
        }
    }

    if (write_back)
        cpu.r[rn] -= count * 4;

    return true;
}

bool handle_ldmfd_sp_pc(uint32_t instr) {
    uint32_t addr = cpu.r[13];
    uint32_t ret = read_mem32(addr);

    if (ret < 0x8000 || ret >= RAM_SIZE) {
        printf("  [ERROR] Invalid return address 0x%08x from LDMFD!\n", ret);
        dump_registers();
        return false;
    }

    cpu.r[15] = ret;
    cpu.r[13] += 4;  // Only one register: pc

    if (trace_all)
        printf("  [LDMFD] PC <= mem[SP]=0x%08x; SP += 4 => 0x%08x\n", ret, cpu.r[13]);

    if (call_depth > 0) call_depth--;

    return true;
}

bool handle_ldr_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf; // base register
    uint8_t rd = (instr >> 12) & 0xf; // destination register
    uint32_t offset = instr & 0xfff;  // 12-bit immediate
    bool up = instr & (1 << 23);      // U bit
    bool pre = instr & (1 << 24);     // P bit

    uint32_t addr = cpu.r[rn];
    if (pre) {
        addr = up ? addr + offset : addr - offset;
    }
    uint32_t val = read_mem32(addr);
    cpu.r[rd] = val;

    if (trace_all) {
        printf("  [LDR pre-%s imm] r%d = mem[0x%08x] => 0x%08x\n",
               up ? "inc" : "dec", rd, addr, val);
    }

    return true;
}

bool handle_pop(uint32_t instr) {
    uint32_t reglist = instr & 0xffff;
    uint32_t addr = cpu.r[13];
    for (int i = 0; i < 16; i++) {
        if (reglist & (1 << i)) {
            uint32_t val = read_mem32(addr);
            if (i == 15) {
                if (val < 0x8000 || val >= RAM_SIZE) {
                    printf("  [ERROR] Invalid return address 0x%08x\n", val);
                    dump_registers();
                    return false;
                }
                cpu.r[15] = val;
                if (call_depth > 0) call_depth--;
                if (trace_all)
                    printf("  [POP] PC <= 0x%08x\n", val);
            } else {
                cpu.r[i] = val;
                if (trace_all)
                    printf("  [POP] r%d <= 0x%08x\n", i, val);
            }
            addr += 4;
        }
    }
    cpu.r[13] = addr;
    return true;
}

bool handle_nop(uint32_t instr) {
    if (trace_all) {
        printf("  [NOP]\n");
    }
    return true;
}

bool handle_movt(uint32_t instr) {
    uint32_t rd = (instr >> 12) & 0xf;
    uint32_t imm4 = (instr >> 16) & 0xf;
    uint32_t imm12 = instr & 0xfff;
    uint32_t imm16 = (imm4 << 12) | imm12;

    // Set top half of register, keep bottom half
    cpu.r[rd] = (cpu.r[rd] & 0x0000FFFF) | (imm16 << 16);

    if (trace_all) {
        printf("  [MOVT] r%d = 0x%08x (imm4=0x%x, imm12=0x%03x)\n",
               rd, cpu.r[rd], imm4, imm12);
    }

    return true;
}

bool handle_pop_pc(uint32_t instr) {
    int imm = instr & 0xfff;
    uint32_t ret = read_mem32(cpu.r[13]);

    if (trace_all)
        printf("  [stack read]  PC <= mem[SP=0x%08x] = 0x%08x\n", cpu.r[13], ret);

    // 🔴 Add check: return address must be valid
    if (ret < 0x8000 || ret >= RAM_SIZE) {
        printf("  [ERROR] Invalid return address 0x%08x from stack!\n", ret);
        dump_registers();
        return false;
    }

    cpu.r[15] = ret;
    cpu.r[13] += imm;

    if (call_depth > 0) {
        call_depth--;
    }

    if (trace_all)
        printf("  [LDR post] PC <= mem[SP]=0x%08x; SP += 0x%x => 0x%08x\n", cpu.r[15], imm, cpu.r[13]);

    return true;
}

void dump_backtrace() {
    printf("Backtrace (%d calls):\n", call_depth);
    for (int i = call_depth - 1; i >= 0; i--) {
        printf("  #%d 0x%08x\n", i, call_stack[i]);
    }
}

bool handle_ldm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back = (instr >> 21) & 1;
    uint32_t addr = cpu.r[rn];

    for (int i = 0; i < 16; i++) {
        if (reglist & (1 << i)) {
            uint32_t val = read_mem32(addr);    // ✅ capture the loaded value
            cpu.r[i] = val;                      // ✅ store into register

            if (debug_flags & DBG_MEM_READ) {
                printf("  [LDM] r%d <= mem[0x%08x] => 0x%08x\n", i, addr, val);  // ✅ use correct vars
            }

            addr += 4;
        }
    }

    if (write_back)
        cpu.r[rn] = addr;

    return true;
}

bool handle_ldrb_postimm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    uint32_t addr = cpu.r[rn];

    uint8_t value = read_mem8(addr);
    cpu.r[rd] = value;

    if (trace_all) {
        printf("  [LDRB post-imm] r%d = mem[0x%08x] => 0x%02x\n",
               rd, addr, value);
    }

    // post-index: base not modified because offset is 0 in your case
    // If non-zero offset and W bit set, update rn here

    return true;
}

void execute_script(const char* filename) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        perror("do fopen");
        return;
    }

    char buf[256];
    while (fgets(buf, sizeof(buf), f)) {
        buf[strcspn(buf, "\r\n")] = 0;  // Strip newline
        printf(">> %s\n", buf);
        execute_line(buf);
    }

    fclose(f);
}

void execute_line(char* line) {
    char* cmd = strtok(line, " \t\r\n");
    if (!cmd || cmd[0] == '#') return;

    if (strcmp(cmd, "load") == 0) {
        char* path = strtok(NULL, " \t\r\n");
        char* addr_str = strtok(NULL, " \t\r\n");
        if (!path || !addr_str) {
            printf("Usage: load <file> <addr>\n");
            return;
        }
        uint32_t addr = strtoul(addr_str, NULL, 0);
        load_binary(path, addr);
        printf("Loaded %s at 0x%08x\n", path, addr);
    }

    else if (strcmp(cmd, "run") == 0) {
        cpu_halted = false;
        while (!cpu_halted) {
            uint32_t instr = fetch_instruction();
            execute(instr);
        }
    }

	else if (strcasecmp(cmd, "e") == 0 || strcasecmp(cmd, "examine") == 0) {
		char* range = strtok(NULL, " \t\r\n");
		if (!range) {
			printf("Usage: e <start>-<end> or e <start> <end>\n");
			return;
		}

		uint32_t start = 0, end = 0;
		char* dash = strchr(range, '-');

		if (dash) {
			*dash = '\0';
			start = strtoul(range, NULL, 0);
			end = strtoul(dash + 1, NULL, 0);
		} else {
			char* end_str = strtok(NULL, " \t\r\n");
			if (!end_str) {
				printf("Usage: e <start>-<end> or e <start> <end>\n");
				return;
			}
			start = strtoul(range, NULL, 0);
			end = strtoul(end_str, NULL, 0);
		}

		examine_memory(start, end);
		return;
	}

    else if (strcasecmp(cmd, "set") == 0) {
        char* arg1 = strtok(NULL, " \t\r\n");
        char* arg2 = strtok(NULL, " \t\r\n");
        char* arg3 = strtok(NULL, " \t\r\n");

        // Handle: set cpu debug=LEVEL
        if (arg1 && arg2 &&
            strcasecmp(arg1, "cpu") == 0 &&
            strncasecmp(arg2, "debug=", 6) == 0) {

            const char* level = arg2 + 6;

            if (strcasecmp(level, "all") == 0) {
                debug_flags = DBG_ALL;
                trace_all = true;
            } else if (strcasecmp(level, "none") == 0) {
                debug_flags = DBG_NONE;
                trace_all = false;
            } else if (strcasecmp(level, "instruction") == 0) {
                debug_flags = DBG_INSTR;
            } else if (strcasecmp(level, "read") == 0) {
                debug_flags = DBG_MEM_READ;
            } else if (strcasecmp(level, "write") == 0) {
                debug_flags = DBG_MEM_WRITE;
            } else if (strcasecmp(level, "memory") == 0) {
                debug_flags = DBG_MEM_READ | DBG_MEM_WRITE;
            } else {
                printf("Unknown debug level: %s (use ALL, NONE, INSTRUCTION, READ, WRITE, MEMORY, HALT)\n", level);
                return;
            }

            printf("[DEBUG] debug_flags set to 0x%08x\n", debug_flags);
            return;
        }

        // Fall back to: set rX Y
        if (!arg1 || !arg2 || arg1[0] != 'r') {
            printf("Usage: set r<regnum> <value>\n");
            return;
        }

        int regnum = atoi(arg1 + 1);
        if (regnum < 0 || regnum > 15) {
            printf("Invalid register: %s\n", arg1);
            return;
        }

        cpu.r[regnum] = strtoul(arg2, NULL, 0);
        printf("Set r%d = 0x%08x\n", regnum, cpu.r[regnum]);
    }

    else if (strcmp(cmd, "step") == 0) {
        char* count_str = strtok(NULL, " \t\r\n");
        int steps = count_str ? atoi(count_str) : 1;
        if (steps <= 0) {
            printf("Step count must be positive.\n");
            return;
        }
        cpu_halted = false;
        for (int i = 0; i < steps && !cpu_halted; i++) {
            uint32_t instr = fetch_instruction();
            execute(instr);
        }
    }

    else if (strcmp(cmd, "regs") == 0) {
        dump_registers();
    }

    else if (strcmp(cmd, "bt") == 0) {
        dump_backtrace();
    }

    else if (strcmp(cmd, "version") == 0) {
        printf("VERSION %s\n", VERSION);
    }

    else if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
        exit(0);
    }

    else if (strcmp(cmd, "show") == 0) {
        char* arg = strtok(NULL, " \t\r\n");
        if (arg && strcmp(arg, "crt") == 0) {
            show_crt();
        } else {
            printf("Unknown subcommand for 'show'. Try: show crt\n");
        }
    }

    else if (strcmp(cmd, "do") == 0) {
        char* path = strtok(NULL, " \t\r\n");
        if (!path) {
            printf("Usage: do <scriptfile>\n");
            return;
        }
        execute_script(path);
    }

    else {
        printf("Unknown command. Available: load, run, set, step, regs, show crt, bt, version, quit\n");
    }
}

bool execute(uint32_t instr) {
    static int cycle = 0;
    static uint32_t last_pc = 0;
    static int spin_count = 0;

    uint32_t pc = cpu.r[15] - 4;

    if (debug_flags & DBG_INSTR)
        printf("[Cycle %08d] PC=0x%08x Instr=0x%08x\n", cycle++, pc, instr);

    if (instr == 0xDEADBEEF) {
        if (debug_flags & DBG_INSTR) {
            printf("  [HALT] Reached DEADBEEF sentinel. Halting VM.\n");     
        }
        cpu_halted = true;
        return false;
    }

    // Detect WFI instruction (wait for interrupt)
    if ((instr & 0xfffffff0) == 0xe320f000) {
        if (trace_all) printf("  [WFI] Halt requested.\n");
        cpu_halted = true;
        return false;
    }

    if ((instr & 0x0fe00000) == 0x01a00000 && ((instr >> 21) & 0xf) == 0xd)
        return handle_mov(instr);

    if ((instr & 0x0e000000) == 0x08100000)
        return handle_ldm(instr);

    if ((instr & 0x0fffffff) == 0xe8bd8000)
        return handle_ldmfd_sp_pc(instr);

    if ((instr & 0x0fff0000) == 0x059f0000)
        return handle_ldr_literal(instr);

    if ((instr & 0x0e000000) == 0x08000000) {
        if (instr & (1 << 20))
            return handle_ldm(instr);
        else
            return handle_stm(instr);
    }

    if ((instr & 0x0c500ff0) == 0xe4c00000)
        return handle_strb_postimm(instr);

    if ((instr & 0x0ff00000) == 0xe8bd0000)
        return handle_pop(instr);

    if ((instr & 0x0fe00000) == 0xe2800000)
        return handle_add(instr);

    if ((instr & 0x0f000000) == 0x0a000000)
        return handle_b(instr);

    if ((instr & 0x0fe00000) == 0x02400000)
        return handle_sub(instr);

    if ((instr & 0x0c500ff0) == 0xe5d00000)
        return handle_ldrb_reg(instr);

    if ((instr & 0x0ff00000) == 0x03500000)
        return handle_cmp_imm(instr);

    if ((instr & 0x0c400000) == 0x04000000 &&
        (instr & (1 << 20)) && !(instr & (1 << 25)) && (instr & (1 << 24))) {
        return handle_ldr_preimm(instr);
    }

    if ((instr & 0x0ff00000) == 0x03400000)
        return handle_movt(instr);

    if ((instr & 0x0fe00000) == 0x03a00000)
        return handle_mov_imm(instr);

    if ((instr & 0x0ffff000) == 0xe52de000)
        return handle_str_predec(instr);

    if ((instr & 0xffff0000) == 0xe4c00000)
        return handle_strb_postimm(instr);

    if ((instr & 0x0ff00000) == 0x03000000)
        return handle_movw(instr);

    if ((instr & 0x0fe00000) == 0x02800000)
        return handle_add_imm(instr);

    if ((instr & 0x0c500000) == 0x04400000 &&
        !(instr & (1 << 20)) && (instr & (1 << 22)) && (instr & (1 << 24)))
        return handle_strb_preimm(instr);

    if ((instr & 0x0c500000) == 0x04000000 &&
        !(instr & (1 << 20)) && !(instr & (1 << 25)) && (instr & (1 << 24)))
        return handle_str_preimm(instr);

    if ((instr & 0x0f000000) == 0x0b000000)
        return handle_bl(instr);

    if ((instr & 0x0c500000) == 0x04500000 &&
        (instr & (1 << 20)) && (instr & (1 << 22)) && (instr & (1 << 24)))
        return handle_ldrb_preimm(instr);

    if ((instr & 0xfffff000) == 0xe49df000)
        return handle_pop_pc(instr);

    if (instr == 0xe320f000)
        return handle_nop(instr);

    // 🛑 Unknown instruction fallback
    printf("[ERROR] Unknown instruction: 0x%08x at PC=0x%08x\n", instr, pc);
    uint32_t op = (instr >> 24) & 0xF;
    uint32_t subop = (instr >> 20) & 0xF;
    printf("  [Not matched] op=0x%x subop=0x%x\n", op, subop);
    cpu_halted = true;
    return false;
}
void load_binary(const char* path, uint32_t addr) {
    FILE* f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "[ERROR] Cannot open file: %s\n", path);    
        cpu_halted = true;
        return;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    fread(ram + addr, 1, size, f);
    fclose(f);
   // write_mem32(RAM_SIZE - 8, 0xDEADDEAD);  // now it's safely within bounds
}

void repl_shell() {
    char line[256];
    // printf("[DEBUG] debug_flags at startup: 0x%08x\n", debug_flags)	;
    while (1) {
        printf("arm-vm> ");
        if (!fgets(line, sizeof(line), stdin)) break;
        execute_line(line);
    }
}

int main(int argc, char* argv[]) {
    if (argc > 1 && strcmp(argv[1], "-V") == 0) {
        printf("ARM VM Emulator %s\n", VERSION);
        return 0;
    }

    ram = calloc(1, RAM_SIZE);
    if (!ram) { perror("calloc"); return 1; }

    memset(&cpu, 0, sizeof(cpu));
    cpu.r[13] = RAM_SIZE - 4; // SP
    cpu.r[15] = ENTRY_POINT;  // PC

    repl_shell();

    free(ram);
    return 0;
}
