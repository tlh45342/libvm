/* arm_vm.c - Minimal ARM emulator that supports 17 core instructions and 512MB RAM */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define RAM_SIZE (512 * 1024 * 1024)
#define ENTRY_POINT 0x8000
#define UART_BASE 0x09000000
#define UART_DR   0x00

// ARM CPU state
struct arm_cpu {
    uint32_t r[16];     // R0-R15 (R15 is PC)
    uint32_t cpsr;      // Basic CPSR for flags
};

uint8_t *ram;
struct arm_cpu cpu;

uint32_t fetch_instruction() {
    uint32_t pc = cpu.r[15];
    if (pc >= RAM_SIZE - 4) {
        fprintf(stderr, "PC out of range: 0x%08x\n", pc);
        exit(1);
    }
    uint32_t instr = *(uint32_t*)(ram + pc);
    cpu.r[15] += 4;
    return instr;
}

void write_uart(uint8_t val) {
    putchar(val);
    fflush(stdout);
}

uint32_t read_mem32(uint32_t addr) {
    if (addr >= UART_BASE && addr < UART_BASE + 0x1000) {
        return 0; // No input for now
    }
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "Read out of bounds: 0x%08x\n", addr);
        exit(1);
    }
    return *(uint32_t*)(ram + addr);
}

void write_mem32(uint32_t addr, uint32_t val) {
    if (addr == UART_BASE + UART_DR) {
        write_uart(val & 0xFF);
        return;
    }
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "Write out of bounds: 0x%08x\n", addr);
        exit(1);
    }
    *(uint32_t*)(ram + addr) = val;
}

bool execute(uint32_t instr) {
    // Handle a small set of instructions
    if ((instr & 0x0fffffff) == 0xe320f000) { // NOP or WFI
        return false; // Stop on WFI
    } else if ((instr & 0x0ffffff0) == 0xe1a00000) { // MOV Rd, Rn
        int rd = (instr >> 12) & 0xf;
        int rn = instr & 0xf;
        cpu.r[rd] = cpu.r[rn];
    } else if ((instr & 0x0fe00000) == 0xe2800000) { // ADD Rd, Rn, #imm
        int rd = (instr >> 12) & 0xf;
        int rn = (instr >> 16) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[rd] = cpu.r[rn] + imm;
    } else if ((instr & 0x0fe00000) == 0xe2400000) { // SUB Rd, Rn, #imm
        int rd = (instr >> 12) & 0xf;
        int rn = (instr >> 16) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[rd] = cpu.r[rn] - imm;
    } else if ((instr & 0x0ff000f0) == 0xe1a00000) { // MOV Rd, #imm
        int rd = (instr >> 12) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[rd] = imm;
    } else if ((instr & 0x0f000000) == 0xea000000) { // B offset
        int offset = instr & 0x00ffffff;
        if (offset & 0x00800000)
            offset |= 0xff000000; // sign extend
        offset <<= 2;
        cpu.r[15] += offset;
    } else if ((instr & 0x0f000000) == 0xeb000000) { // BL offset
        int offset = instr & 0x00ffffff;
        if (offset & 0x00800000)
            offset |= 0xff000000; // sign extend
        offset <<= 2;
        cpu.r[14] = cpu.r[15];
        cpu.r[15] += offset;
    } else if ((instr & 0x0c500000) == 0xe4000000) { // STR Rn, [SP, #-imm]!
        int rn = (instr >> 12) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[13] -= imm;
        write_mem32(cpu.r[13], cpu.r[rn]);
    } else if ((instr & 0x0c500000) == 0xe8000000) { // LDR Rd, [SP], #imm
        int rd = (instr >> 12) & 0xf;
        int imm = instr & 0xfff;
        cpu.r[rd] = read_mem32(cpu.r[13]);
        cpu.r[13] += imm;
    } else if ((instr & 0x0c100000) == 0xe4100000) { // POP {reg}
        int reg = (instr >> 12) & 0xf;
        cpu.r[reg] = read_mem32(cpu.r[13]);
        cpu.r[13] += 4;
    } else {
        printf("Unknown instruction: 0x%08x at 0x%08x\n", instr, cpu.r[15] - 4);
        return false;
    }
    return true;
}

void load_binary(const char* path, uint32_t addr) {
    FILE* f = fopen(path, "rb");
    if (!f) { perror("open"); exit(1); }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    fread(ram + addr, 1, size, f);
    fclose(f);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s kernel.bin\n", argv[0]);
        return 1;
    }

    ram = calloc(1, RAM_SIZE);
    if (!ram) { perror("calloc"); return 1; }

    memset(&cpu, 0, sizeof(cpu));
    cpu.r[13] = RAM_SIZE - 4; // SP
    cpu.r[15] = ENTRY_POINT; // PC

    load_binary(argv[1], ENTRY_POINT);

    while (1) {
        uint32_t instr = fetch_instruction();
        if (!execute(instr)) break;
    }

    printf("\n[VM halted]\n");
    free(ram);
    return 0;
}