#include <stdio.h>
#include <stdint.h>     // REQUIRED for uint8_t, uint32_t, etc.
#include <stdbool.h>    // REQUIRED for bool, true, false
#include <stdarg.h>     // For variadic logging/debugging
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

#include "log.h"      // fixes: implicit declaration of log_printf
#include "arm_mul.h"
#include "cpu.h"      // for RAM_SIZE, ENTRY_POINT, cpu, etc.  <-- add this if missing
#include "log.h"      // keep this
#ifdef _WIN32
  #include <windows.h>
#else
  #include <time.h>
  #include <sys/time.h>
#endif

#include "wincrt.h"   // for wincrt_enabled, wincrt_present_text
#include "arm-vm.h"   // for g_ram, CRT_BASE, CRT_COLS/ROWS, etc.

#define VERSION "0.0.115"

bool enable_crt = false;
bool crt_dirty = false;

#define MAX_BACKTRACE 64
uint32_t call_stack[MAX_BACKTRACE];
int call_depth = 0;
bool cpu_halted = false;

// Force immediate repaint from VRAM buffer (full screen or dirty region)
void crt_refresh(void);

// Show CRT window (could be same as init in some setups)
void show_crt(void);


// ----------------------------------------------------

void show_crt() {
    printf("\n==== CRT OUTPUT ====\n");
    for (int row = 0; row < CRT_ROWS; row++) {
        for (int col = 0; col < CRT_COLS; col++) {
            uint32_t offset = CRT_BASE + (row * CRT_COLS + col) * 2;
            char ch = ram[offset];
            putchar((ch >= 32 && ch < 127) ? ch : '.');
        }
        printf("\n");
    }
    printf("====================\n");
}

void crt_mark_dirty(uint32_t addr, size_t len) {
    // If the write touches the CRT memory region, mark CRT as dirty
    const uint32_t CRT_START = 0x0A000000;
    const uint32_t CRT_END = CRT_START + (80 * 25 * 2); // 80x25 chars, 2 bytes each

    if (addr < CRT_END && (addr + len) > CRT_START) {
        crt_dirty = true;
    }
}

void crt_refresh() {
    if (!enable_crt)   // ✅ only check your VM’s own flag
        return;

    wincrt_present_text((const uint8_t *)ram + CRT_BASE, 0, 0, CRT_COLS, CRT_ROWS); // ✅ cast to const uint8_t *
}

// ------------------------------------

uint64_t cycle = 0;
uint8_t *ram;

#ifndef BIT
#define BIT(x) (1u << (x))
#endif

// CPSR bit masks
#define CPSR_N   BIT(31)
#define CPSR_Z   BIT(30)
#define CPSR_C   BIT(29)
#define CPSR_V   BIT(28)
#define CPSR_Q   BIT(27)
#define CPSR_GE0 BIT(16)
#define CPSR_GE1 BIT(17)
#define CPSR_GE2 BIT(18)
#define CPSR_GE3 BIT(19)
#define CPSR_GE_MASK (BIT(16)|BIT(17)|BIT(18)|BIT(19))
#define CPSR_E   BIT(9)
#define CPSR_A   BIT(8)
#define CPSR_I   BIT(7)
#define CPSR_F   BIT(6)
#define CPSR_T   BIT(5)
#define CPSR_MODE_MASK 0x1Fu

static inline uint32_t cpsr_mode(void){ return cpu.cpsr & CPSR_MODE_MASK; }
static inline int is_user_mode(void){ return (cpsr_mode() == 0x10u); } // User=0x10

uint32_t disk_lba = 0;
uint32_t disk_buffer_addr = 0;
uint32_t disk_status = 0;

// ----------

void execute_line(char* line);
void show_crt(void);  
bool execute(uint32_t instr);
void load_binary(const char* path, uint32_t addr);
void dump_backtrace(void);

uint8_t read_mem8(uint32_t addr);
void write_mem8(uint32_t addr, uint8_t val);
uint16_t read_mem16(uint32_t addr);
void write_mem16(uint32_t addr, uint16_t val);

bool handle_mrs(uint32_t instr);
bool handle_msr_reg(uint32_t instr);
bool handle_msr_imm(uint32_t instr);
bool handle_cps(uint32_t instr);
bool handle_setend(uint32_t instr);

// ----------

void examine_memory(uint32_t start, uint32_t end) {
    if (start >= RAM_SIZE || end >= RAM_SIZE || start > end) {
        log_printf("[ERROR] Invalid memory range 0x%08x - 0x%08x\n", start, end);
        return;
    }

    for (uint32_t addr = start; addr <= end; addr += 16) {
        log_printf("0x%08x: ", addr);
        for (int i = 0; i < 16 && (addr + i) <= end; i++) {
            log_printf("%02x ", ram[addr + i]);
        }
        log_printf(" |");
        for (int i = 0; i < 16 && (addr + i) <= end; i++) {
            uint8_t c = ram[addr + i];
           log_printf("%c", (c >= 32 && c < 127) ? c : '.');
        }
        log_printf("|\n");
    }
}

static inline uint32_t ror(uint32_t val, int r) {
    return (val >> r) | (val << (32 - r));
}

void dump_registers() {
    log_printf("Registers:\n");
    for (int i = 0; i < 16; i++) {
        log_printf("r%-2d = 0x%08x  ", i, cpu.r[i]);
        if ((i + 1) % 4 == 0) log_printf("\n");
    }
}

uint32_t fetch_instruction() {
    uint32_t pc = cpu.r[15];
    if (pc >= RAM_SIZE - 4) {
        fprintf(stderr, "[ERROR] PC out of range: 0x%08x\n", pc);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xDEADDEAD;
    }
    uint8_t *p = ram + pc;
    uint32_t instr = p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
    cpu.r[15] += 4;
    return instr;
}

// -------------------------------------------------------------

void write_uart(uint8_t val) {
    putchar(val);
    fflush(stdout);
}

// ----------------------

// portable version
uint64_t host_now_ns(void) {
#ifdef _WIN32
    LARGE_INTEGER freq, ctr;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&ctr);
    return (uint64_t)((__int128)ctr.QuadPart * 1000000000ull / (uint64_t)freq.QuadPart);
#else
  #ifdef CLOCK_MONOTONIC
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
  #else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000000000ull + (uint64_t)tv.tv_usec * 1000ull;
  #endif
#endif
}

// ----------

// Called periodically inside the VM execution loop to update CRT if enabled
static void maybe_update_crt(void) {
	if (!enable_crt)
		return;
	wincrt_pump_messages();
	static uint64_t last_update_ns = 0;
	const uint64_t now = host_now_ns();
	const uint64_t REFRESH_INTERVAL = 16 * 1000 * 1000; 
	// ~60Hz 
	if (now - last_update_ns >= REFRESH_INTERVAL) { 
	   crt_refresh();
	   last_update_ns = now;
	}
}

// -----------------

uint16_t read_mem16(uint32_t addr) {
    if (addr >= RAM_SIZE - 1) {
        fprintf(stderr, "[ERROR] Read16 out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xFFFF;
    }
    // Use 8-bit accessor so MMIO paths get hit correctly
    uint16_t lo = read_mem8(addr);
    uint16_t hi = read_mem8(addr + 1);
    return (uint16_t)(lo | (hi << 8));
}

void write_mem16(uint32_t addr, uint16_t val) {
    if (addr >= RAM_SIZE - 1) {
        fprintf(stderr, "[ERROR] Write16 out of bounds: 0x%08x\n", addr);
        exit(1);
    }
    // Use 8-bit writes so MMIO side effects occur
    write_mem8(addr,     (uint8_t)(val & 0xFF));
    write_mem8(addr + 1, (uint8_t)((val >> 8) & 0xFF));
}

uint8_t read_mem8(uint32_t addr) {
    if (addr >= UART_BASE && addr < UART_BASE + 0x1000)
        return 0;

    if (addr >= RAM_SIZE) {
        fprintf(stderr, "Read8 out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xFF;
    }

	if (addr >= DISK_BASE && addr < DISK_BASE + DISK_SIZE) {
		return handle_disk_read(addr);
	}

    return ram[addr];
}

uint32_t read_mem32(uint32_t addr) {
    if (addr > RAM_SIZE - 4) {  // was >=
        fprintf(stderr, "[ERROR] Read out of bounds: 0x%08x\n", addr);
        dump_registers(); dump_backtrace(); cpu_halted = true;
        return 0xDEADDEAD;
    }
    if (addr >= DISK_BASE && addr < DISK_BASE + DISK_SIZE) return handle_disk_read(addr);

    uint32_t v;
    memcpy(&v, ram + addr, 4);  // ✅ avoids UB on unaligned platforms
    return v;
}

void write_mem8(uint32_t addr, uint8_t v){
    if (addr == UART_BASE + UART_DR){ write_uart(v); return; }
    if (addr >= DISK_BASE && addr < DISK_BASE + DISK_SIZE){ handle_disk_write(addr, v); return; }
    ram[addr] = v;
    if (enable_crt && addr >= CRT_BASE && addr < CRT_BASE + CRT_SIZE) { crt_mark_dirty(addr,1); crt_refresh(); }
}

void write_mem32(uint32_t addr, uint32_t v){
    if (addr == UART_BASE + UART_DR){ write_uart((uint8_t)(v & 0xFF)); return; }
    if (addr >= DISK_BASE && addr < DISK_BASE + DISK_SIZE){ handle_disk_write(addr, v); return; }
    memcpy(ram + addr, &v, 4); // avoids UB on unaligned
    if (enable_crt && addr >= CRT_BASE && addr < CRT_BASE + CRT_SIZE) { crt_mark_dirty(addr,4); }
}

void dump_backtrace() {
    log_printf("Backtrace (%d calls):\n", call_depth);
    for (int i = call_depth - 1; i >= 0; i--) {
        log_printf("  #%d 0x%08x\n", i, call_stack[i]);
    }
}

// -------------------------------------------------------------------------------------

void execute_script(const char* filename) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        perror("fopen");
        return;
    }

    char buf[256];
    while (fgets(buf, sizeof(buf), f)) {
        // Remove newline
        buf[strcspn(buf, "\r\n")] = 0;

        // Skip blank or comment lines
        char* trimmed = buf;
        while (*trimmed == ' ' || *trimmed == '\t') trimmed++; // skip leading whitespace

        if (*trimmed == '\0' || *trimmed == ';') {
            continue;  // blank line or comment
        }

        printf(">> %s\n", buf);
        execute_line(trimmed);
    }

    fclose(f);
}

void execute_line(char* line) {
    // First: strip out comments (semicolon to end-of-line) unless inside quotes
    char* p = line;
    bool in_quotes = false;
    while (*p) {
        if (*p == '"') {
            in_quotes = !in_quotes;
        } else if (*p == ';' && !in_quotes) {
            *p = '\0';  // strip the comment
            break;
        }
        p++;
    }

    // Skip leading whitespace
    while (*line == ' ' || *line == '\t') line++;

    if (*line == '\0') return;  // Blank or comment-only line

    // Tokenize command
    char* cmd = strtok(line, " \t\r\n");
    if (!cmd || cmd[0] == '#') return;

    if (strcmp(cmd, "load") == 0) {
        char* path = strtok(NULL, " \t\r\n");
        char* addr_str = strtok(NULL, " \t\r\n");
        if (!path || !addr_str) {
            log_printf("Usage: load <file> <addr>\n");
            return;
        }
        uint32_t addr = strtoul(addr_str, NULL, 0);
        load_binary(path, addr);
        log_printf("Loaded %s at 0x%08x\n", path, addr);
    }

    else if (strcmp(cmd, "run") == 0) {
        cpu_halted = false;
		cycle = 0;
		while (!cpu_halted) {
			uint32_t instr = read_mem32(cpu.r[15]);
			cpu.r[15] += 4;
			if (!execute(instr) || cpu_halted) break;
			cycle++; 
			maybe_update_crt();
		}
    }

    else if (strcasecmp(cmd, "e") == 0 || strcasecmp(cmd, "examine") == 0) {
        char* range = strtok(NULL, " \t\r\n");
        if (!range) {
            log_printf("Usage: e <start>-<end> or e <start> <end>\n");
            return;
        }

        uint32_t start = 0, end = 0;
        char* dash = strchr(range, '-');
        if (dash) {
            *dash = '\0';
            start = strtoul(range, NULL, 0);
            end = strtoul(dash + 1, NULL, 0);
        } else {
            char* end_str = strtok(NULL, " \t\r\n");
            if (!end_str) {
                printf("Usage: e <start>-<end> or e <start> <end>\n");
                return;
            }
            start = strtoul(range, NULL, 0);
            end = strtoul(end_str, NULL, 0);
        }

        examine_memory(start, end);
    }

    else if (strcmp(cmd, "set") == 0) {
        char* arg1 = strtok(NULL, " \t\r\n");
        char* arg2 = strtok(NULL, " \t\r\n");

        // set cpu debug=XXX
        if (arg1 && arg2 &&
            strcasecmp(arg1, "cpu") == 0 &&
            strncasecmp(arg2, "debug=", 6) == 0) {

            const char* level = arg2 + 6;

            if (strcasecmp(level, "all") == 0) {
                debug_flags = DBG_ALL;
                trace_all = true;
            } else if (strcasecmp(level, "none") == 0) {
                debug_flags = DBG_NONE;
                trace_all = false;
            } else if (strcasecmp(level, "instruction") == 0) {
                debug_flags = DBG_INSTR;
            } else if (strcasecmp(level, "read") == 0) {
                debug_flags = DBG_MEM_READ;
            } else if (strcasecmp(level, "write") == 0) {
                debug_flags = DBG_MEM_WRITE;
            } else if (strcasecmp(level, "memory") == 0) {
                debug_flags = DBG_MEM_READ | DBG_MEM_WRITE;
            } else {
                log_printf("Unknown debug level: %s\n", level);
                return;
            }

            log_printf("[DEBUG] debug_flags set to 0x%08x\n", debug_flags);
            return;
        }

        // fallback: set rX Y
        if (!arg1 || !arg2 || arg1[0] != 'r') {
            log_printf("Usage: set r<regnum> <value>\n");
            return;
        }

        int regnum = atoi(arg1 + 1);
        if (regnum < 0 || regnum > 15) {
            log_printf("Invalid register: %s\n", arg1);
            return;
        }

        cpu.r[regnum] = strtoul(arg2, NULL, 0);
        log_printf("Set r%d = 0x%08x\n", regnum, cpu.r[regnum]);
    }


	else if (strcmp(cmd, "do") == 0) {
		char* script_path = strtok(NULL, " \t\r\n");
		if (!script_path) {
			log_printf("Usage: do <scriptfile>\n");
			return;
		}

		FILE* f = fopen(script_path, "r");
		if (!f) {
			log_printf("Could not open script file: %s\n", script_path);
			return;
		}

		char buf[256];
		while (fgets(buf, sizeof(buf), f)) {
			// Trim newline and print to console/log
			buf[strcspn(buf, "\r\n")] = '\0';
			log_printf(">> %s\n", buf);
			execute_line(buf);
		}

		fclose(f);
	}

    else if (strcmp(cmd, "step") == 0) {
        char* count_str = strtok(NULL, " \t\r\n");
        int steps = count_str ? atoi(count_str) : 1;
        if (steps <= 0) {
            log_printf("Step count must be positive.\n");
            return;
        }
        cpu_halted = false;
        for (int i = 0; i < steps && !cpu_halted; i++) {
            uint32_t instr = fetch_instruction();
            execute(instr);
			cycle++;
        }
    }

    else if (strcmp(cmd, "bt") == 0) {
        dump_backtrace();
    }

    else if (strcmp(cmd, "regs") == 0) {
        dump_registers();
    }

    else if (strcmp(cmd, "show") == 0) {
        char* what = strtok(NULL, " \t\r\n");
        if (!what) {
           log_printf("Usage: show <crt>\n");
        } else if (strcasecmp(what, "crt") == 0) {
            show_crt();
        } else {
            log_printf("Unknown show target: %s\n", what);
        }
    }

	else if (strcmp(cmd, "logfile") == 0) {
		char* filename = strtok(NULL, " \t\r\n");
		if (!filename) {
			log_printf("Usage: logfile <filename>\n");
			return;
		}
		if (log_set_file(filename)) {
			log_printf("Logging to %s\n", filename);
		} else {
			log_printf("Failed to open logfile: %s\n", filename);
		}
	}

    else if (strcmp(cmd, "version") == 0) {
		log_printf("VERSION %s\n", VERSION);
    }

	else if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
		exit(0);
	}

    else {
        log_printf("Unknown command: %s\n", cmd);
    }
}

void load_binary(const char* path, uint32_t addr) {
    FILE* f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "[ERROR] Cannot open file: %s\n", path);    
        cpu_halted = true;
        return;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    fread(ram + addr, 1, size, f);
    fclose(f);
   // write_mem32(RAM_SIZE - 8, 0xDEADDEAD);  // now it's safely within bounds
}

void repl_shell() {
    char line[256];
    // printf("[DEBUG] debug_flags at startup: 0x%08x\n", debug_flags)	;
    while (1) {
        printf("arm-vm> ");
        if (!fgets(line, sizeof(line), stdin)) break;
        execute_line(line);
    }
}

int main(int argc, char* argv[]) {
    if (argc > 1 && strcmp(argv[1], "-V") == 0) {
        printf("ARM VM Emulator %s\n", VERSION);
        return 0;
    }

	for (int i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-crt") == 0) {
			enable_crt = true;
		}
	}

	if (enable_crt) {
		wincrt_init_text(CRT_COLS, CRT_ROWS);  // E.g. 80x25
	}

    ram = calloc(1, RAM_SIZE);
    if (!ram) { perror("calloc"); return 1; }

    memset(&cpu, 0, sizeof(cpu));
    cpu.r[13] = RAM_SIZE - 4; // SP
    cpu.r[15] = ENTRY_POINT;  // PC

    repl_shell();

    free(ram);
    return 0;
}
