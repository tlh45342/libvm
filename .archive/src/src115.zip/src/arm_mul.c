// src/arm_mul.c
#include <stdint.h>
#include "arm-vm.h"   // must expose struct arm_cpu and extern cpu
#include "arm_mul.h"

#ifndef BIT
#define BIT(x) (1u << (x))
#endif

// Only set N/Z; leave C/V unchanged for these long-multiply ops.
static inline void set_nz_64(uint64_t val) {
    if (val == 0) cpu.cpsr |= BIT(30); else cpu.cpsr &= ~BIT(30);                    // Z
    if (val & 0x8000000000000000ULL) cpu.cpsr |= BIT(31); else cpu.cpsr &= ~BIT(31); // N
}

// UMULL{S} RdLo,RdHi,Rm,Rs
void handle_umull(uint32_t instr) {
    uint32_t S    = (instr >> 20) & 1u;
    uint32_t RdHi = (instr >> 16) & 0xFu;
    uint32_t RdLo = (instr >> 12) & 0xFu;
    uint32_t Rs   = (instr >> 8)  & 0xFu;
    uint32_t Rm   =  instr        & 0xFu;

    uint64_t res = (uint64_t)cpu.r[Rm] * (uint64_t)cpu.r[Rs];
    cpu.r[RdLo]  = (uint32_t)res;
    cpu.r[RdHi]  = (uint32_t)(res >> 32);
    if (S) set_nz_64(res);
}

// UMLAL{S} RdLo,RdHi,Rm,Rs
void handle_umlal(uint32_t instr) {
    uint32_t S    = (instr >> 20) & 1u;
    uint32_t RdHi = (instr >> 16) & 0xFu;
    uint32_t RdLo = (instr >> 12) & 0xFu;
    uint32_t Rs   = (instr >> 8)  & 0xFu;
    uint32_t Rm   =  instr        & 0xFu;

    uint64_t acc = ((uint64_t)cpu.r[RdHi] << 32) | cpu.r[RdLo];
    uint64_t res = acc + (uint64_t)cpu.r[Rm] * (uint64_t)cpu.r[Rs];
    cpu.r[RdLo]  = (uint32_t)res;
    cpu.r[RdHi]  = (uint32_t)(res >> 32);
    if (S) set_nz_64(res);
}

// SMULL{S} RdLo,RdHi,Rm,Rs
void handle_smull(uint32_t instr) {
    uint32_t S    = (instr >> 20) & 1u;
    uint32_t RdHi = (instr >> 16) & 0xFu;
    uint32_t RdLo = (instr >> 12) & 0xFu;
    uint32_t Rs   = (instr >> 8)  & 0xFu;
    uint32_t Rm   =  instr        & 0xFu;

    int64_t res = (int64_t)(int32_t)cpu.r[Rm] * (int64_t)(int32_t)cpu.r[Rs];
    cpu.r[RdLo] = (uint32_t)res;
    cpu.r[RdHi] = (uint32_t)((uint64_t)res >> 32);
    if (S) set_nz_64((uint64_t)res);
}

// SMLAL{S} RdLo,RdHi,Rm,Rs
void handle_smlal(uint32_t instr) {
    uint32_t S    = (instr >> 20) & 1u;
    uint32_t RdHi = (instr >> 16) & 0xFu;
    uint32_t RdLo = (instr >> 12) & 0xFu;
    uint32_t Rs   = (instr >> 8)  & 0xFu;
    uint32_t Rm   =  instr        & 0xFu;

    int64_t acc = ((int64_t)(int32_t)cpu.r[RdHi] << 32) | cpu.r[RdLo];
    int64_t res = acc + (int64_t)(int32_t)cpu.r[Rm] * (int64_t)(int32_t)cpu.r[Rs];
    cpu.r[RdLo] = (uint32_t)res;
    cpu.r[RdHi] = (uint32_t)((uint64_t)res >> 32);
    if (S) set_nz_64((uint64_t)res);
}
