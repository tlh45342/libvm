// cpu.c
#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>

#include "cpu.h"      // cpu, cycle, cpu_halted, debug_flags, trace_all, log_printf
#include "arm-vm.h"   // MMIO bases (UART/CRT/DISK) if any handler needs them
#include "log.h"      // log_printf prototype

#ifndef BIT
#define BIT(x) (1u << (x))
#endif

CPU cpu = {0};

bool evaluate_condition(uint8_t cond);

// -----------------------------------------------------------------------------
// External memory accessors (implemented in arm-vm.c)
// -----------------------------------------------------------------------------
extern uint8_t  read_mem8 (uint32_t addr);
extern void     write_mem8(uint32_t addr, uint8_t v);
extern uint16_t read_mem16(uint32_t addr);
extern void     write_mem16(uint32_t addr, uint16_t v);
extern uint32_t read_mem32(uint32_t addr);
extern void     write_mem32(uint32_t addr, uint32_t v);

// -----------------------------------------------------------------------------
// Minimal CPSR helpers used locally
// -----------------------------------------------------------------------------
static inline uint32_t cpsr_get_C(void) { return (cpu.cpsr >> 29) & 1u; }
static inline uint32_t cpsr_get_V(void) { return (cpu.cpsr >> 28) & 1u; }

static inline void cpsr_set_NZ(uint32_t result) {
    if (result & 0x80000000u) cpu.cpsr |=  BIT(31); else cpu.cpsr &= ~BIT(31); // N
    if (result == 0)           cpu.cpsr |=  BIT(30); else cpu.cpsr &= ~BIT(30); // Z
}
static inline void cpsr_set_C_from(uint32_t c) { if (c) cpu.cpsr |= BIT(29); else cpu.cpsr &= ~BIT(29); }
static inline void cpsr_set_V(uint32_t v)      { if (v) cpu.cpsr |= BIT(28); else cpu.cpsr &= ~BIT(28); }

// CPSR layout bits used by MSR/SETEND/CPS
#define CPSR_N   BIT(31)
#define CPSR_Z   BIT(30)
#define CPSR_C   BIT(29)
#define CPSR_V   BIT(28)
#define CPSR_Q   BIT(27)
#define CPSR_GE0 BIT(16)
#define CPSR_GE1 BIT(17)
#define CPSR_GE2 BIT(18)
#define CPSR_GE3 BIT(19)
#define CPSR_GE_MASK (CPSR_GE0|CPSR_GE1|CPSR_GE2|CPSR_GE3)
#define CPSR_E   BIT(9)
#define CPSR_A   BIT(8)
#define CPSR_I   BIT(7)
#define CPSR_F   BIT(6)
#define CPSR_T   BIT(5)
#define CPSR_MODE_MASK 0x1Fu

static inline uint32_t cpsr_mode(void){ return cpu.cpsr & CPSR_MODE_MASK; }
static inline int is_user_mode(void){ return (cpsr_mode() == 0x10u); } // User=0x10

// MSR helper: write selected PSR fields
static void psr_write(uint32_t *psr, uint32_t value, uint32_t fields, int is_cpsr)
{
    uint32_t p = *psr;

    if (fields & BIT(16)) { // c: control (M,T,F,I,A,E)
        uint32_t keep = p & ~(CPSR_E|CPSR_A|CPSR_I|CPSR_F|CPSR_T|CPSR_MODE_MASK);
        uint32_t set  = value & (CPSR_E|CPSR_A|CPSR_I|CPSR_F|CPSR_MODE_MASK);
        // ignore T (we don't model Thumb)
        p = keep | set;
    }
    if (fields & BIT(17)) { /* x: ignored in this VM */ }
    if (fields & BIT(18)) { // s: GE[3:0]
        p &= ~CPSR_GE_MASK;
        p |= (value & CPSR_GE_MASK);
    }
    if (fields & BIT(19)) { // f: NZCVQ
        uint32_t keep = p & ~(CPSR_N|CPSR_Z|CPSR_C|CPSR_V|CPSR_Q);
        uint32_t set  = value &  (CPSR_N|CPSR_Z|CPSR_C|CPSR_V|CPSR_Q);
        p = keep | set;
    }

    *psr = p;

    if (debug_flags & DBG_INSTR) {
        log_printf("  [PSR write] %s <= 0x%08X (fields: %c%c%c%c)\n",
            is_cpsr ? "CPSR" : "SPSR", value,
            (fields&BIT(19))?'f':'-',
            (fields&BIT(18))?'s':'-',
            (fields&BIT(17))?'x':'-',
            (fields&BIT(16))?'c':'-');
    }
}

// -----------------------------------------------------------------------------
// Small utilities
// -----------------------------------------------------------------------------
static inline uint32_t ror32(uint32_t v, unsigned r){
    r &= 31u; return r ? ((v >> r) | (v << (32 - r))) : v;
}

// -----------------------------------------------------------------------------
// Data-processing operand2 (immediate or shifted register)
// Returns the value; writes shifter carry-out to *sh_carry.
// -----------------------------------------------------------------------------
static inline uint32_t dp_operand2(uint32_t instr, uint32_t *sh_carry) {
    const uint32_t I = (instr >> 25) & 1u;

    if (I) {
        uint32_t imm8 = instr & 0xffu;
        uint32_t rot  = ((instr >> 8) & 0xfu) * 2u;
        uint32_t val  = rot ? ((imm8 >> rot) | (imm8 << (32 - rot))) : imm8;
        *sh_carry = rot ? ((val >> 31) & 1u) : cpsr_get_C();
        return val;
    } else {
        uint32_t Rm = cpu.r[instr & 0xfu];
        uint32_t type = (instr >> 5) & 0x3u;       // 0 LSL, 1 LSR, 2 ASR, 3 ROR
        uint32_t by_reg = (instr >> 4) & 1u;       // shift by register?
        uint32_t amount = by_reg ? (cpu.r[(instr >> 8) & 0xfu] & 0xffu)
                                 : ((instr >> 7) & 0x1fu);
        uint32_t c_out = cpsr_get_C(), val = Rm;

        switch (type) {
            case 0: // LSL
                if (amount == 0) { /* keep c_out */ }
                else if (amount < 32) { c_out = (Rm >> (32 - amount)) & 1u; val = Rm << amount; }
                else if (amount == 32) { c_out = Rm & 1u; val = 0; }
                else { c_out = 0; val = 0; }
                break;
            case 1: // LSR
                if (amount == 0) { c_out = (Rm >> 31) & 1u; val = 0; } // LSR #32
                else if (amount < 32) { c_out = (Rm >> (amount - 1)) & 1u; val = Rm >> amount; }
                else { c_out = 0; val = 0; }
                break;
            case 2: // ASR
                if (amount == 0) { c_out = (Rm >> 31) & 1u; val = (Rm & 0x80000000u) ? 0xffffffffu : 0; }
                else if (amount < 32) {
                    c_out = (Rm >> (amount - 1)) & 1u;
                    if (Rm & 0x80000000u) val = (Rm >> amount) | ~(~0u >> amount);
                    else                   val =  Rm >> amount;
                } else {
                    c_out = (Rm >> 31) & 1u; val = (Rm & 0x80000000u) ? 0xffffffffu : 0;
                }
                break;
            case 3: // ROR / RRX
                if (!by_reg && amount == 0) { // RRX
                    c_out = Rm & 1u;
                    val = (cpsr_get_C() << 31) | (Rm >> 1);
                } else {
                    uint32_t rot = amount & 31u;
                    if (rot == 0) { c_out = (Rm >> 31) & 1u; val = Rm; }
                    else { val = (Rm >> rot) | (Rm << (32 - rot)); c_out = (val >> 31) & 1u; }
                }
                break;
        }
        *sh_carry = c_out;
        return val;
    }
}

// -----------------------------------------------------------------------------
// Arithmetic ops core (ADD/ADC/SBC/RSB)
// -----------------------------------------------------------------------------
typedef enum { OP_ADC, OP_SBC, OP_RSB, OP_ADD } arith_op_t;

static inline int overflow_add(uint32_t a, uint32_t b, uint32_t res) {
    return (~(a ^ b) & (a ^ res) & 0x80000000u) != 0;
}
static inline int overflow_sub(uint32_t a, uint32_t b, uint32_t res) {
    return ((a ^ b) & (a ^ res) & 0x80000000u) != 0;
}

static inline void exec_arith(uint32_t instr, arith_op_t op) {
    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xfu;
    uint32_t Rd = (instr >> 12) & 0xfu;

    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);
    uint32_t a   = cpu.r[Rn];
    uint32_t res = 0, carry_out = 0;
    int overflow = 0;

    switch (op) {
        case OP_ADD: {
            uint64_t tmp = (uint64_t)a + (uint64_t)op2;
            res = (uint32_t)tmp;
            carry_out = (uint32_t)((tmp >> 32) & 1u);
            overflow = overflow_add(a, op2, res);
            break;
        }
        case OP_ADC: {
            uint64_t tmp = (uint64_t)a + (uint64_t)op2 + (uint64_t)cpsr_get_C();
            res = (uint32_t)tmp;
            carry_out = (uint32_t)((tmp >> 32) & 1u);
            overflow = overflow_add(a, op2 + cpsr_get_C(), res);
            break;
        }
        case OP_SBC: {
            uint64_t tmp = (uint64_t)a - (uint64_t)op2 - (uint64_t)(1u - cpsr_get_C());
            res = (uint32_t)tmp;
            carry_out = ((uint64_t)a >= (uint64_t)op2 + (1u - cpsr_get_C()));
            overflow = overflow_sub(a, op2 + (1u - cpsr_get_C()), res);
            break;
        }
        case OP_RSB: {
            uint64_t tmp = (uint64_t)op2 - (uint64_t)a;
            res = (uint32_t)tmp;
            carry_out = ((uint64_t)op2 >= (uint64_t)a);
            overflow = overflow_sub(op2, a, res);
            break;
        }
    }

    cpu.r[Rd] = res;
    if (S) {
        cpsr_set_NZ(res);
        cpsr_set_C_from(carry_out);
        cpsr_set_V(overflow);
    }
}

// Handle SUB / SUBS (immediate or register w/ shift)
// Uses dp_operand2() and bit-based CPSR helpers.
static void handle_sub_or_subs(uint32_t instr) {
    uint32_t opcode = (instr >> 21) & 0xF;   // 0x2 = SUB
    if (opcode != 0x2) return;

    uint32_t S  = (instr >> 20) & 1u;
    uint32_t Rn = (instr >> 16) & 0xFu;
    uint32_t Rd = (instr >> 12) & 0xFu;

    // Build operand2 via your shared barrel shifter
    uint32_t sh_carry = cpsr_get_C();
    uint32_t op2 = dp_operand2(instr, &sh_carry);

    uint32_t a   = cpu.r[Rn];
    uint32_t res = a - op2;

    // Special case: SUBS pc, lr, #imm (exception return)
    if (S && Rd == 15) {
        if (!is_user_mode()) {
            cpu.cpsr = cpu.spsr;  // restore CPSR from SPSR in privileged modes
        }
        cpu.r[15] = res;          // branch to (lr - imm)
        if (debug_flags & DBG_INSTR) {
            log_printf("[SUBS pc, r%u, op2] => 0x%08X; CPSR<=%s\n",
                       Rn, res, is_user_mode() ? "unchanged" : "SPSR");
        }
        return;
    }

    // Normal SUB/SUBS
    cpu.r[Rd] = res;

    if (S) {
        // N,Z from result
        cpsr_set_NZ(res);
        // C for SUB: NOT borrow = (a >= op2)
        cpsr_set_C_from(a >= op2);
        // V for SUB: signed overflow on subtraction
        cpsr_set_V(overflow_sub(a, op2, res));
    }

    if (debug_flags & DBG_INSTR) {
        log_printf("  [%s %s] r%u = r%u - 0x%08X => 0x%08X\n",
            S ? "SUBS" : "SUB",
            ((instr >> 25) & 1u) ? "imm" : "reg",
            Rd, Rn, op2, res);
    }
}


static inline bool handle_str_postimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t imm = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint32_t val  = cpu.r[rd];

    write_mem32(addr, val);
    cpu.r[rn] = addr + imm;

    if (debug_flags & DBG_INSTR)
        log_printf("  [STR post-imm] mem[0x%08X] <= r%d (0x%08X); r%d += 0x%X\n",
                   addr, rd, val, rn, imm);
    return true;
}

static inline void log_add_after(uint32_t instr) {
    if (!(debug_flags & DBG_INSTR)) return;

    uint32_t Rd = (instr >> 12) & 0xF;
    uint32_t Rn = (instr >> 16) & 0xF;
    bool I = (instr >> 25) & 1;
    bool S = (instr >> 20) & 1;

    if (I) {
        uint32_t imm8 = instr & 0xFF;
        uint32_t rot  = ((instr >> 8) & 0xF) * 2;
        uint32_t val  = (rot == 0) ? imm8 : ((imm8 >> rot) | (imm8 << (32 - rot)));
        if (S) {
            log_printf("[ADD imm] r%u = r%u + #0x%X => 0x%08X  (N=%d Z=%d C=%d V=%d)\n",
                       Rd, Rn, val, cpu.r[Rd],
                       !!(cpu.cpsr & CPSR_N), !!(cpu.cpsr & CPSR_Z),
                       !!(cpu.cpsr & CPSR_C), !!(cpu.cpsr & CPSR_V));
        } else {
            log_printf("[ADD imm] r%u = r%u + #0x%X => 0x%08X\n",
                       Rd, Rn, val, cpu.r[Rd]);
        }
    } else {
        uint32_t Rm       =  instr        & 0xF;
        bool     by_reg   = ((instr >> 4) & 1u) != 0;  // shift-by-register?
        uint32_t stype    = (instr >> 5) & 0x3u;       // 0 LSL, 1 LSR, 2 ASR, 3 ROR
        uint32_t sh_imm   = (instr >> 7) & 0x1Fu;      // imm amount if !by_reg
        uint32_t Rs       = (instr >> 8) & 0xFu;       // shift register if by_reg
        const char *sname = (stype == 0) ? "LSL" : (stype == 1) ? "LSR" : (stype == 2) ? "ASR" : "ROR";

        if (!by_reg) {
            // special cases: RRX (ROR #0) and LSL #0 (no suffix)
            if (stype == 3 && sh_imm == 0) {
                // RRX
                if (S) {
                    log_printf("[ADD reg] r%u = r%u + r%u, RRX => 0x%08X  (N=%d Z=%d C=%d V=%d)\n",
                               Rd, Rn, Rm, cpu.r[Rd],
                               !!(cpu.cpsr & CPSR_N), !!(cpu.cpsr & CPSR_Z),
                               !!(cpu.cpsr & CPSR_C), !!(cpu.cpsr & CPSR_V));
                } else {
                    log_printf("[ADD reg] r%u = r%u + r%u, RRX => 0x%08X\n",
                               Rd, Rn, Rm, cpu.r[Rd]);
                }
            } else if (stype == 0 && sh_imm == 0) {
                // plain Rm
                if (S) {
                    log_printf("[ADD reg] r%u = r%u + r%u => 0x%08X  (N=%d Z=%d C=%d V=%d)\n",
                               Rd, Rn, Rm, cpu.r[Rd],
                               !!(cpu.cpsr & CPSR_N), !!(cpu.cpsr & CPSR_Z),
                               !!(cpu.cpsr & CPSR_C), !!(cpu.cpsr & CPSR_V));
                } else {
                    log_printf("[ADD reg] r%u = r%u + r%u => 0x%08X\n",
                               Rd, Rn, Rm, cpu.r[Rd]);
                }
            } else {
                // shift by immediate
                if (S) {
                    log_printf("[ADD reg] r%u = r%u + r%u, %s #%u => 0x%08X  (N=%d Z=%d C=%d V=%d)\n",
                               Rd, Rn, Rm, sname, sh_imm, cpu.r[Rd],
                               !!(cpu.cpsr & CPSR_N), !!(cpu.cpsr & CPSR_Z),
                               !!(cpu.cpsr & CPSR_C), !!(cpu.cpsr & CPSR_V));
                } else {
                    log_printf("[ADD reg] r%u = r%u + r%u, %s #%u => 0x%08X\n",
                               Rd, Rn, Rm, sname, sh_imm, cpu.r[Rd]);
                }
            }
        } else {
            // shift by register
            if (S) {
                log_printf("[ADD reg] r%u = r%u + r%u, %s r%u => 0x%08X  (N=%d Z=%d C=%d V=%d)\n",
                           Rd, Rn, Rm, sname, Rs, cpu.r[Rd],
                           !!(cpu.cpsr & CPSR_N), !!(cpu.cpsr & CPSR_Z),
                           !!(cpu.cpsr & CPSR_C), !!(cpu.cpsr & CPSR_V));
            } else {
                log_printf("[ADD reg] r%u = r%u + r%u, %s r%u => 0x%08X\n",
                           Rd, Rn, Rm, sname, Rs, cpu.r[Rd]);
            }
        }
    }
}

// Thin wrappers used by decoder
static inline bool handle_add(uint32_t instr)             { exec_arith(instr, OP_ADD); log_add_after(instr); return true; }
static inline bool handle_add_dp(uint32_t instr)          { exec_arith(instr, OP_ADD); log_add_after(instr); return true; }
static inline bool handle_add_reg(uint32_t instr)         { exec_arith(instr, OP_ADD); log_add_after(instr); return true; }
static inline bool handle_add_reg_simple(uint32_t instr)  { exec_arith(instr, OP_ADD); log_add_after(instr); return true; }
static inline bool handle_add_imm(uint32_t instr)         { exec_arith(instr, OP_ADD); log_add_after(instr); return true; }
static inline bool handle_add_imm_dp(uint32_t instr)      { exec_arith(instr, OP_ADD); log_add_after(instr); return true; }
// --------------


// -----------------------------------------------------------------------------
// Logical ops core (AND/EOR/ORR/BIC/TST/TEQ) — only the ones execute() uses
// -----------------------------------------------------------------------------
static inline bool handle_and_imm_dp(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    bool    s  = (instr >> 20) & 1;

    uint32_t imm8 = instr & 0xFF;
    uint32_t rot2 = ((instr >> 8) & 0xF) * 2;
    uint32_t op2  = rot2 ? ror32(imm8, rot2) : imm8;

    uint32_t res = cpu.r[rn] & op2;
    cpu.r[rd] = res;

    if (s) cpsr_set_NZ(res);

    if (debug_flags & DBG_INSTR) {
        log_printf("  [AND imm%s] r%d = r%d (0x%08X) & 0x%08X => 0x%08X\n",
                   s ? "s" : "", rd, rn, cpu.r[rn], op2, res);
    }
    return true;
}

static inline void handle_svc(uint32_t instr) {
    uint32_t A  = (cpu.r[15] - 4);          // address of SVC instruction
    uint32_t lr = cpu.r[15] + 4;            // A+8 (return target for SUBS pc, lr, #4)

    if (debug_flags & DBG_INSTR) {
        log_printf("[SVC] imm=0x%06X A=0x%08X -> LR_svc=0x%08X\n",
                   instr & 0x00FFFFFFu, A, lr);
    }

    // Save old CPSR and LR, then enter SVC (ARM, I=1)
    cpu.spsr   = cpu.cpsr;
    cpu.r[14]  = lr;

    uint32_t p = cpu.cpsr;
    p = (p & ~0x1Fu) | 0x13u;   // SVC mode
    p &= ~(1u << 5);            // T=0 (ARM)
    p |=  (1u << 7);            // I=1
    p &= ~((0x3Fu << 10) | (0x3u << 25)); // clear IT bits
    cpu.cpsr = p;

    // Branch to SVC vector
    cpu.r[15] = 0x00000008u;
}

static inline bool handle_and_reg_simple(uint32_t instr) {
    if ((instr & 0x00000FF0u) != 0) return false; // only "no shift" form
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint8_t rm =  instr        & 0xF;
    bool    s  = (instr >> 20) & 1;

    uint32_t res = cpu.r[rn] & cpu.r[rm];
    cpu.r[rd] = res;
    if (s) cpsr_set_NZ(res);

    if (debug_flags & DBG_INSTR) {
        log_printf("  [AND reg%s] r%d = r%d (0x%08X) & r%d (0x%08X) => 0x%08X\n",
                   s ? "s" : "", rd, rn, cpu.r[rn], rm, cpu.r[rm], res);
    }
    return true;
}

// -----------------------------------------------------------------------------
// Misc simple handlers referenced by execute()
// -----------------------------------------------------------------------------
static inline bool handle_nop(uint32_t instr) { (void)instr; if (debug_flags & DBG_INSTR) log_printf("  [NOP]\n"); return true; }

static inline bool handle_wfi(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR) {
        log_printf("[WFI] Wait for interrupt (simulated pause).\n");
    }
    // WFI behaves as a NOP in this VM: no state change, PC already advances.
    return true;
}

static inline bool handle_mov(uint32_t instr) {
    // MOV (register) simplified: Rd = Rm
    uint8_t rd = (instr >> 12) & 0xF;
    uint8_t rm =  instr        & 0xF;
    cpu.r[rd] = cpu.r[rm];
    if (debug_flags & DBG_INSTR) log_printf("  [MOV] r%d = r%d (0x%08X)\n", rd, rm, cpu.r[rd]);
    return true;
}

static inline bool handle_mov_imm(uint32_t instr) {
    int rd = (instr >> 12) & 0xF;
    uint32_t imm8 = instr & 0xFF;
    int rotate = ((instr >> 8) & 0xF) * 2;
    uint32_t imm = rotate ? ror32(imm8, (unsigned)rotate) : imm8;
    cpu.r[rd] = imm;
    if (debug_flags & DBG_INSTR) log_printf("[MOV imm] r%d = 0x%08X\n", rd, imm);
    return true;
}

static inline bool handle_movt(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t imm4  = (instr >> 16) & 0xF;
    uint32_t imm12 = instr & 0xFFF;
    uint32_t imm   = (imm4 << 12) | imm12;
    cpu.r[rd] = (cpu.r[rd] & 0xFFFFu) | (imm << 16);
    if (debug_flags & DBG_INSTR) log_printf("  [MOVT] r%d = 0x%08X\n", rd, cpu.r[rd]);
    return true;
}

static inline bool handle_cmp_reg(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rm =  instr        & 0xF;
    uint32_t result = cpu.r[rn] - cpu.r[rm];
    // N/Z only for now
    if (result & 0x80000000u) cpu.cpsr |=  CPSR_N; else cpu.cpsr &= ~CPSR_N;
    if (result == 0)          cpu.cpsr |=  CPSR_Z; else cpu.cpsr &= ~CPSR_Z;
    if (debug_flags & DBG_INSTR)
        log_printf("  [CMP reg] r%d(0x%08X) - r%d(0x%08X) => 0x%08X\n",
                   rn, cpu.r[rn], rm, cpu.r[rm], result);
    return true;
}

static inline bool handle_cmp_imm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t imm = instr & 0xFFF;
    uint32_t result = cpu.r[rn] - imm;
    if (result & 0x80000000u) cpu.cpsr |=  CPSR_N; else cpu.cpsr &= ~CPSR_N;
    if (result == 0)          cpu.cpsr |=  CPSR_Z; else cpu.cpsr &= ~CPSR_Z;
    if (debug_flags & DBG_INSTR)
        log_printf("  [CMP imm] r%d(0x%08X) - 0x%08X => 0x%08X\n", rn, cpu.r[rn], imm, result);
    return true;
}

static inline bool handle_sub(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t S  = (instr >> 20) & 1u;

    // DP immediate: imm = ROR(imm8, 2*rot)
    uint32_t imm8 = instr & 0xFFu;
    uint32_t rot  = ((instr >> 8) & 0xFu) * 2u;
    uint32_t imm  = rot ? ror32(imm8, rot) : imm8;

    uint32_t res = cpu.r[rn] - imm;

    // Exception return: SUBS pc, lr, #imm
    if (S && rd == 15) {
        if (!is_user_mode()) {
            cpu.cpsr = cpu.spsr;  // restore CPSR
        }
        cpu.r[15] = res;          // branch to (lr - imm)
        if (debug_flags & DBG_INSTR)
            log_printf("[SUBS pc, r%u, #0x%X] => 0x%08X; CPSR<=SPSR%s\n",
                       rn, imm, res, is_user_mode() ? " (user mode, no restore)" : "");
        return true;
    }

    // Normal SUB
    cpu.r[rd] = res;
    if (debug_flags & DBG_INSTR)
        log_printf("[SUB imm%s] r%u = r%u - 0x%X => 0x%08X\n",
                   S ? "s" : "", rd, rn, imm, cpu.r[rd]);
    return true;
}

static inline bool handle_b(uint32_t instr) {
    // Respect condition
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR) log_printf("[B] cond fail (0x%X) -> not taken\n", cond);
        return true;  // skip, PC already points past this instr
    }

    // B <label>
    int32_t offset = instr & 0x00FFFFFF;
    if (offset & 0x00800000) offset |= 0xFF000000; // sign-extend
    offset <<= 2;
    uint32_t fetch_pc = cpu.r[15] - 4;
    uint32_t target = (fetch_pc + 8) + (uint32_t)offset;

    if (debug_flags & DBG_INSTR) log_printf("[B] target=0x%08X\n", target);
    cpu.r[15] = target;
    return true;
}

static inline bool handle_bl(uint32_t instr) {
    // Respect condition
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR) log_printf("  [BL] cond fail (0x%X) -> not taken\n", cond);
        return true;
    }

    int32_t offset = instr & 0x00FFFFFF;
    if (offset & 0x00800000) offset |= 0xFF000000;
    offset <<= 2;
    uint32_t fetch_pc = cpu.r[15] - 4;
    uint32_t target = (fetch_pc + 8) + (uint32_t)offset;

    cpu.r[14] = cpu.r[15];   // LR = next PC
    if (debug_flags & DBG_INSTR) log_printf("[BL] target=0x%08X LR=0x%08X\n", target, cpu.r[14]);
    cpu.r[15] = target;
    return true;
}

static inline bool handle_bx(uint32_t instr) {
    // Respect condition (BX has a cond field too)
    uint8_t cond = (instr >> 28) & 0xF;
    if (cond != 0xF && !evaluate_condition(cond)) {
        if (debug_flags & DBG_INSTR) log_printf("  [BX] cond fail (0x%X) -> not taken\n", cond);
        return true;
    }

    int rm = instr & 0xF;
    uint32_t addr = cpu.r[rm];
    if (debug_flags & DBG_INSTR) log_printf("  [BX] r%d => 0x%08X\n", rm, addr);
    cpu.r[15] = addr;
    return true;
}

static inline bool handle_ldrb_reg(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t addr = cpu.r[rn];
    uint8_t byte = read_mem8(addr);
    cpu.r[rd] = byte;
    if (trace_all || (debug_flags & DBG_MEM_READ))
        log_printf("  [LDRB reg] r%d = mem8[0x%08X] => 0x%02X\n", rd, addr, byte);
    return true;
}

static inline bool handle_ldrb_post_imm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    uint32_t addr = cpu.r[rn];
    uint8_t val = read_mem8(addr);
    cpu.r[rd] = val;
    cpu.r[rn] += offset;
    if (debug_flags & DBG_MEM_READ)
        log_printf("  [LDRB post-imm] r%d = mem8[0x%08X] => 0x%02X; r%d += 0x%X\n",
                   rd, addr, val, rn, offset);
    return true;
}

static inline bool handle_ldrb_postimm(uint32_t instr) {
    // same as above (alias in your code paths)
    return handle_ldrb_post_imm(instr);
}

static inline bool handle_ldrb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;        // Base
    uint8_t rd = (instr >> 12) & 0xF;        // Dest
    uint32_t offset = instr & 0xFFF;         // imm12
    bool up = (instr >> 23) & 1u;            // U
    bool pre = (instr >> 24) & 1u;           // P
    bool wb  = (instr >> 21) & 1u;           // W

    uint32_t addr = cpu.r[rn];
    if (pre) addr = up ? addr + offset : addr - offset;

    uint8_t val = read_mem8(addr);
    cpu.r[rd] = val;

    if (wb || !pre) cpu.r[rn] = addr;

    if (debug_flags & DBG_INSTR)
        log_printf("  [LDRB pre-%s%s imm] r%d = mem8[0x%08X] => 0x%02X\n",
                   up ? "inc" : "dec", wb ? "!" : "", rd, addr, val);
    return true;
}

static inline bool handle_ldr_postimm(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xF;
    uint8_t rn = (instr >> 16) & 0xF;
    uint32_t imm = instr & 0xFFF;
    uint32_t U   = (instr >> 23) & 1u;

    uint32_t addr = cpu.r[rn];
    uint32_t val  = read_mem32(addr);
    cpu.r[rd] = val;
    cpu.r[rn] = U ? (addr + imm) : (addr - imm);

    if (debug_flags & DBG_INSTR || trace_all) {
        log_printf("[LDR post-imm] r%d = mem[0x%08X] => 0x%08X; r%d %c= 0x%X => 0x%08X\n",
                   rd, addr, val, rn, U?'+':'-', imm, cpu.r[rn]);
    }
    return true;
}

static inline bool handle_ldr_preimm(uint32_t instr) {
    // Caller already verified: single data transfer, I=0 (imm), P=1 (pre), L=1 (load)
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t imm = instr & 0xFFF;
    bool U = (instr >> 23) & 1u;  // add/sub

    uint32_t addr = cpu.r[rn];
    addr = U ? (addr + imm) : (addr - imm);

    uint32_t val = read_mem32(addr);
    cpu.r[rd] = val;

    if (debug_flags & DBG_INSTR) {
        log_printf("[LDR pre-%s imm] r%d = mem[0x%08X] => 0x%08X\n",
                   U ? "inc" : "dec", rd, addr, val);
    }
    return true;
}

static inline bool handle_ldr_literal(uint32_t instr) {
    // LDR (literal): Rn == PC, I=0, P=1, L=1
    uint8_t  rd   = (instr >> 12) & 0xF;
    uint32_t imm  = instr & 0xFFF;
    bool     U    = (instr >> 23) & 1u;

    // In this VM, execute() was called after fetch advanced PC by +4.
    // The architectural base for a literal load is (instr_addr + 8), then aligned.
    uint32_t fetch_pc = cpu.r[15] - 4;             // address of this instruction
    uint32_t base     = (fetch_pc + 8) & ~3u;      // PC+8, word-aligned
    uint32_t addr     = U ? (base + imm) : (base - imm);

    uint32_t val = read_mem32(addr);
    cpu.r[rd] = val;

    if (debug_flags & DBG_INSTR) {
        log_printf("[LDR literal] r%d = mem[0x%08X] => 0x%08X\n", rd, addr, val);
    }
    return true;
}

static inline bool handle_strb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    bool up = (instr >> 23) & 1u;
    bool pre = (instr >> 24) & 1u;

    uint32_t addr = cpu.r[rn];
    if (pre) addr = up ? addr + offset : addr - offset;

    uint8_t val = (uint8_t)(cpu.r[rd] & 0xFFu);
    write_mem8(addr, val);

    if (debug_flags & DBG_INSTR)
        log_printf("[STRB pre-%s imm] mem[0x%08X] <= r%d (0x%02X)\n",
                   up ? "inc" : "dec", addr, rd, val);
    return true;
}

bool handle_movw(uint32_t instr) {
    // MOVW: Move Wide immediate
    uint8_t rd    = (instr >> 12) & 0xF;
    uint16_t imm4 = (instr >> 16) & 0xF;
    uint16_t imm12 = instr & 0xFFF;
    uint32_t imm  = (imm4 << 12) | imm12;

    cpu.r[rd] = imm;

    if (debug_flags & DBG_INSTR) {
        log_printf("[MOVW] r%d = 0x%08X\n", rd, imm);
    }

    return true;
}

static inline bool handle_strb_postimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint8_t  byte = (uint8_t)(cpu.r[rd] & 0xFFu);
    write_mem8(addr, byte);
    cpu.r[rn] += offset;

    if (debug_flags & DBG_INSTR)
        log_printf("[STRB post-imm] mem[0x%08X] <= r%d (0x%02X); r%d += 0x%X\n",
                   addr, rd, byte, rn, offset);
    return true;
}

static inline bool handle_str_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    bool up = (instr >> 23) & 1u;
    bool pre = (instr >> 24) & 1u;

    uint32_t addr = cpu.r[rn];
    if (pre) addr = up ? addr + offset : addr - offset;

    write_mem32(addr, cpu.r[rd]);

    if (debug_flags & DBG_INSTR)
        log_printf("  [STR pre-%s imm] mem[0x%08X] <= r%d (0x%08X)\n",
                   up ? "inc" : "dec", addr, rd, cpu.r[rd]);
    return true;
}

static inline bool handle_str_predec(uint32_t instr) {
    int rd = (instr >> 12) & 0xF;
    int rn = (instr >> 16) & 0xF;
    uint32_t offset = instr & 0xFFF;
    cpu.r[rn] -= offset;
    write_mem32(cpu.r[rn], cpu.r[rd]);
    if (trace_all) {
        log_printf("  [STR pre-dec] mem[0x%08X] <= r%d (0x%08X)\n", cpu.r[rn], rd, cpu.r[rd]);
    }
    return true;
}

static inline bool handle_ldm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back = (instr >> 21) & 1u;
    uint32_t addr = cpu.r[rn];

    for (int i = 0; i < 16; i++) {
        if (reglist & (1u << i)) {
            uint32_t val = read_mem32(addr);
            cpu.r[i] = val;
            if (debug_flags & DBG_MEM_READ) {
                log_printf("[LDM] r%d <= mem[0x%08X] => 0x%08X\n", i, addr, val);
            }
            addr += 4;
        }
    }
    if (write_back) cpu.r[rn] = addr;
    return true;
}

static inline bool handle_stm(uint32_t instr) {
    uint32_t rn      = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back  = ((instr >> 21) & 1u) != 0;
    uint32_t base    = cpu.r[rn];

    int count = __builtin_popcount(reglist);
    uint32_t addr = base - count * 4;  // STMDB/STMFD pattern (matches your current behavior)

    for (int i = 0; i < 16; i++) {
        if (reglist & (1u << i)) {
            uint32_t value = cpu.r[i];                 // <-- this replaces the undefined 'val'
            if (debug_flags & DBG_MEM_WRITE) {
                log_printf("[STR] mem[0x%08x] <= 0x%08x\n", addr, value);
            }
            write_mem32(addr, value);
            addr += 4;
        }
    }

    if (write_back) {
        cpu.r[rn] = base - count * 4;
    }
    return true;
}

static inline bool handle_pop(uint32_t instr) {
    uint32_t reglist = instr & 0xFFFF;
    uint32_t addr = cpu.r[13];
    for (int i = 0; i < 16; i++) {
        if (reglist & (1u << i)) {
            uint32_t val = read_mem32(addr);
            if (i == 15) { // PC
                if (val < ENTRY_POINT || val >= RAM_SIZE) {
                    log_printf("  [ERROR] Invalid return address 0x%08X\n", val);
                    return false;
                }
                cpu.r[15] = val;
            } else {
                cpu.r[i] = val;
            }
            addr += 4;
        }
    }
    cpu.r[13] = addr;
    return true;
}

static inline bool handle_pop_pc(uint32_t instr) {
    int imm = instr & 0xFFF;
    uint32_t ret = read_mem32(cpu.r[13]);
    if (ret < ENTRY_POINT || ret >= RAM_SIZE) {
        log_printf("  [ERROR] Invalid return address 0x%08X from stack!\n", ret);
        return false;
    }
    cpu.r[15] = ret;
    cpu.r[13] += (uint32_t)imm;
    if (trace_all) log_printf("  [POP PC] => 0x%08X, SP=0x%08X\n", cpu.r[15], cpu.r[13]);
    return true;
}

// --- Barriers: treat as NOPs in this VM ---
static inline bool handle_dsb(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[DSB SY] Data Synchronization Barrier (nop)\n");
    return true;
}

static inline bool handle_dmb(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[DMB SY] Data Memory Barrier (nop)\n");
    return true;
}

static inline bool handle_isb(uint32_t instr) {
    (void)instr;
    if (debug_flags & DBG_INSTR)
        log_printf("[ISB SY] Instruction Synchronization Barrier (nop)\n");
    return true;
}

// ----- System register moves: MRS/MSR/SETEND/CPS -----
static inline bool handle_mrs(uint32_t instr) {
    uint32_t Rd  = (instr >> 12) & 0xF;
    uint32_t sps = (instr >> 22) & 1u;   // 0=CPSR, 1=SPSR
    uint32_t val = sps ? cpu.spsr : cpu.cpsr;
    cpu.r[Rd] = val;
    if (debug_flags & DBG_INSTR)
        log_printf("  [MRS] r%u = %s (0x%08X)\n", Rd, sps ? "SPSR" : "CPSR", val);
    return true;
}

static inline bool handle_msr(uint32_t instr) {
    int spsr_sel = (instr >> 22) & 1u;      // 0=CPSR, 1=SPSR
    uint32_t fields = (instr >> 16) & 0xFu; // {f s x c}
    uint32_t op;

    if ((instr >> 25) & 1u) {
        uint32_t imm8 = instr & 0xFFu;
        uint32_t rot2 = ((instr >> 8) & 0xFu) * 2u;
        op = rot2 ? ((imm8 >> rot2) | (imm8 << (32 - rot2))) : imm8;
    } else {
        uint8_t Rm = instr & 0xFu;
        op = cpu.r[Rm];
    }

    if (spsr_sel) {
        if (is_user_mode()) { if (debug_flags & DBG_INSTR) log_printf("  [MSR] SPSR write ignored in User mode\n"); return true; }
        psr_write(&cpu.spsr, op, fields, 0);
    } else {
        psr_write(&cpu.cpsr, op, fields, 1);
    }
    return true;
}
static inline bool handle_msr_reg(uint32_t instr) { return handle_msr(instr); }
static inline bool handle_msr_imm(uint32_t instr) { return handle_msr(instr); }

static inline bool handle_setend(uint32_t instr) {
    uint32_t E = (instr >> 9) & 1u;
    if (E) cpu.cpsr |=  CPSR_E; else cpu.cpsr &= ~CPSR_E;
    if (debug_flags & DBG_INSTR)
        log_printf("  [SETEND] E=%u -> CPSR=0x%08X (emulator memory remains LE)\n", E, cpu.cpsr);
    return true;
}

static inline bool handle_cps(uint32_t instr) {
    bool disable = ((instr >> 18) & 1u) != 0;
    bool Mbit    = ((instr >> 17) & 1u) != 0;
    uint32_t mask = 0;
    if (instr & (1u << 8)) mask |= (1u << 8);   // A
    if (instr & (1u << 7)) mask |= (1u << 7);   // I
    if (instr & (1u << 6)) mask |= (1u << 6);   // F

    if (disable) cpu.cpsr |= mask; else cpu.cpsr &= ~mask;

    if (Mbit) {
        uint32_t mode = instr & 0x1Fu;
        cpu.cpsr = (cpu.cpsr & ~0x1Fu) | (mode & 0x1Fu);
    }

    if (debug_flags & DBG_INSTR) {
        log_printf("  [CPS%s] AIF=%c%c%c mode=%s -> CPSR=0x%08X\n",
            disable ? "ID" : "IE",
            (instr & (1u<<8))?'A':'-',
            (instr & (1u<<7))?'I':'-',
            (instr & (1u<<6))?'F':'-',
            Mbit ? "set" : "unchanged",
            cpu.cpsr);
    }
    return true;
}

// -----------------------------------------------------------------------------
// Condition code evaluator (public in case other modules want it)
// -----------------------------------------------------------------------------
bool evaluate_condition(uint8_t cond) {
    bool N = (cpu.cpsr >> 31) & 1;
    bool Z = (cpu.cpsr >> 30) & 1;
    bool C = (cpu.cpsr >> 29) & 1;
    bool V = (cpu.cpsr >> 28) & 1;

    switch (cond) {
        case 0x0: return Z;                // EQ
        case 0x1: return !Z;               // NE
        case 0x2: return C;                // CS
        case 0x3: return !C;               // CC
        case 0x4: return N;                // MI
        case 0x5: return !N;               // PL
        case 0x6: return V;                // VS
        case 0x7: return !V;               // VC
        case 0x8: return C && !Z;          // HI
        case 0x9: return !C || Z;          // LS
        case 0xA: return N == V;           // GE
        case 0xB: return N != V;           // LT
        case 0xC: return !Z && (N == V);   // GT
        case 0xD: return Z || (N != V);    // LE
        case 0xE: return true;             // AL
        default:  return false;            // NV / undefined
    }
}

// -----------------------------------------------------------------------------
// Main single-step executor
// -----------------------------------------------------------------------------
bool execute(uint32_t instr) {
    uint32_t pc = cpu.r[15] - 4;

    if (debug_flags & DBG_INSTR) {
        log_printf("[TRACE] PC=0x%08X Instr=0x%08X\n", pc, instr);
        log_printf("[Cycle %08" PRIu64 "] PC=0x%08X Instr=0x%08X\n", cycle, pc, instr);
    }

	// Quick sentinel to halt
	if (instr == 0xDEADBEEF) {
		if (debug_flags & DBG_INSTR) {
			log_printf("[HALT] DEADBEEF.  Halting VM.\n");
		}
		cpu_halted = true;
		return true;  // indicate "handled" so caller knows we executed something
	}
	
	// Barriers (A32 encodings)
	if (instr == 0xF57FF04F) return handle_dsb(instr); // DSB SY
	if (instr == 0xF57FF05F) return handle_dmb(instr); // DMB SY (you may not hit this, but it's common)
	if (instr == 0xF57FF06F) return handle_isb(instr); // ISB SY


    // MVN (imm) quick path
    if ((instr & 0x0ff00000u) == 0x03e00000u) {
        int rd = (instr >> 12) & 0xF;
        uint32_t imm8 = instr & 0xFF;
        int rotate = ((instr >> 8) & 0xF) * 2;
        uint32_t imm = rotate ? ror32(imm8, (unsigned)rotate) : imm8;
        cpu.r[rd] = ~imm;
        if (debug_flags & DBG_INSTR) log_printf("[MVN imm] r%d = ~0x%08X => 0x%08X\n", rd, imm, cpu.r[rd]);
        return true;
    }

	if ((instr & 0x0F000000u) == 0x0F000000u) {   // SVC
		uint8_t cond = (instr >> 28) & 0xF;
		if (cond != 0xF && !evaluate_condition(cond)) {
			if (debug_flags & DBG_INSTR) log_printf("  [SVC] cond fail (0x%X) -> not taken\n", cond);
			return true;   // PC already advanced by fetch
		}
		handle_svc(instr);
		return true;
	}

    if ((instr & 0x0ff00000u) == 0x01500000u) return handle_cmp_reg(instr);

    // HINTs
    if (instr == 0xe320f000u) return handle_nop(instr);  // NOP
    if (instr == 0xe320f003u) return handle_wfi(instr);  // WFI

    if ((instr & 0x0fe00000u) == 0x01a00000u && ((instr >> 21) & 0xF) == 0xD) return handle_mov(instr);

    uint32_t L = (instr >> 20) & 1u;
    uint32_t W = (instr >> 21) & 1u;
    uint32_t B = (instr >> 22) & 1u;
    // uint32_t U = (instr >> 23) & 1u;
    uint32_t P = (instr >> 24) & 1u;
	uint32_t I = (instr >> 25) & 1u;

	// STR post-indexed (word, imm)
	if ( ((instr & 0x0C000000u) == 0x04000000u) &&
		 P==0 && I==0 && B==0 && L==0 ) {
		return handle_str_postimm(instr);
	}

	// ... now your LDR literal recognition, but add a guard to avoid coproc/sys space ...
	// LDR (literal) : Data transfer, I=0 (imm), P=1 (pre), L=1 (load), Rn==15
	if ( ((instr & 0x0C100000u) == 0x04100000u) &&
		 ((instr & (1u << 25)) == 0) &&        // I=0
		 ((instr & (1u << 24)) != 0) &&        // P=1
		 ((instr & (1u << 20)) != 0) &&        // L=1
		 (((instr >> 16) & 0xF) == 15) &&      // Rn==PC
		 ((instr & 0x0F000000u) != 0x0F000000u) )   // <-- NEW: exclude coproc/sys encodings
	{
		return handle_ldr_literal(instr);
	}

	// LDR post-indexed (word, imm)
	if ( ((instr & 0x0C000000u) == 0x04000000u) &&
		 P==0 && I==0 && B==0 && L==1 ) {
		return handle_ldr_postimm(instr);
	}

    // LDRB post-indexed forms
    if ((instr & 0x0e500000u) == 0x04500000u && P == 0 && L == 1 && B == 1) {
        if (W == 1) return handle_ldrb_post_imm(instr);
        else        return handle_ldrb_postimm(instr);
    }

    // LDR literal
    if ((instr & 0x0fff0000u) == 0x059f0000u || (instr & 0x0fff0000u) == 0x051f0000u) return handle_ldr_literal(instr);

    // ADD (various)
    if ((instr & 0x0DE00000u) == 0x00800000u) { handle_add_dp(instr); return true; }
    if ((instr & 0x0FE00000u) == 0x02800000u) return handle_add_imm_dp(instr);
    if ((instr & 0x0FE00010u) == 0x00800000u && (instr & 0x00000FF0u) == 0) return handle_add_reg(instr);
    if ((instr & 0x0FE00010u) == 0x00800000u) { if (handle_add_reg_simple(instr)) return true; }
    if ((instr & 0x0FF00000u) == 0x02800000u) return handle_add(instr);
    if ((instr & 0x0FE00000u) == 0x02800000u) return handle_add_imm(instr);

    // AND
    if ((instr & 0x0FE00000u) == 0x02000000u) return handle_and_imm_dp(instr);
    if ((instr & 0x0FE00010u) == 0x00000000u && (instr & 0x00000FF0u) == 0) return handle_and_reg_simple(instr);

    // PSR transfers / system
    if ((instr & 0x0FBF0FFFu) == 0x010F0000u) return handle_mrs(instr);      // MRS
    if ((instr & 0x0F61FFF0u) == 0x0161F000u) return handle_msr_reg(instr);  // MSR (reg)
    if ((instr & 0x0F6F0000u) == 0x066F0000u) return handle_msr_imm(instr);  // MSR (imm)
    if ((instr & 0xFFFF0FFFu) == 0xF1010000u) return handle_setend(instr);   // SETEND
    if ( ((instr >> 28) & 0xF) == 0xF && ((instr >> 20) & 0xFF) == 0x10 && ((instr >> 4) & 0xF) == 0x0 )
        return handle_cps(instr); // CPSIE/CPSID

    // Load/store multiple
    if ((instr & 0x0e000000u) == 0x08000000u) {
        if (instr & (1u << 20)) return handle_ldm(instr);
        else                    return handle_stm(instr);
    }

    // Byte store post-imm
    if ((instr & 0xFFF00FF0u) == 0xE4C00000u) return handle_strb_postimm(instr);

    // POP (register list)
    if ((instr & 0xFFFF0000u) == 0xE8BD0000u) return handle_pop(instr);

    // Branches
    if ((instr & 0x0f000000u) == 0x0a000000u) return handle_b(instr);
    if ((instr & 0x0f000000u) == 0x0b000000u) return handle_bl(instr);
    if ((instr & 0x0ffffff0u) == 0x012fff10u) return handle_bx(instr);

	// SUB / SUBS (both I=0 and I=1; class 00)
	if ((instr & 0x0DE00000u) == 0x00400000u) {  // opcode == 0b0010
		handle_sub_or_subs(instr);
		return true;
	}

    // LDRB register (simple form)
    if ((instr & 0xFFF000F0u) == 0xE5D00000u) return handle_ldrb_reg(instr);

    // CMP (imm)
    if ((instr & 0x0ff00000u) == 0x03500000u) return handle_cmp_imm(instr);

    // LDR pre-indexed
    if ((instr & 0x0c400000u) == 0x04000000u &&
        (instr & (1u << 20)) && !(instr & (1u << 25)) && (instr & (1u << 24))) {
        return handle_ldr_preimm(instr);
    }

    // MOVW/MOVT
    if ((instr & 0x0ff00000u) == 0x03000000u) return handle_movw(instr);
    if ((instr & 0x0ff00000u) == 0x03400000u) return handle_movt(instr);

    // MOV (imm)
    if ((instr & 0x0fe00000u) == 0x03a00000u) return handle_mov_imm(instr);

    // STR pre-dec
    if ((instr & 0xffff0000u) == 0xe52d0000u) return handle_str_predec(instr);

    // STRB pre-imm
    if ((instr & 0x0c500000u) == 0x04400000u &&
        !(instr & (1u << 20)) && (instr & (1u << 22)) && (instr & (1u << 24)))
        return handle_strb_preimm(instr);

    // STR pre-imm
    if ((instr & 0x0c500000u) == 0x04000000u &&
        !(instr & (1u << 20)) && !(instr & (1u << 25)) && (instr & (1u << 24)))
        return handle_str_preimm(instr);

    // POP {.., pc}
    if ((instr & 0xfffff000u) == 0xe49df000u) return handle_pop_pc(instr);

    // Unknown
    log_printf("[ERROR] Unknown instruction: 0x%08X at PC=0x%08X\n", instr, pc);
    uint32_t op = (instr >> 24) & 0xF;
    uint32_t subop = (instr >> 20) & 0xF;
    log_printf("  [Not matched] op=0x%X subop=0x%X\n", op, subop);
    cpu_halted = true;
    return false;
}
