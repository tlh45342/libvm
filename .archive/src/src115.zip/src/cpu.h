#ifndef CPU_H
#define CPU_H

#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint32_t r[16];   // General purpose registers R0–R15
    uint32_t cpsr;    // Current Program Status Register
    uint32_t spsr;    // Saved Program Status Register (optional for mode changes)
    // Add other CPU state members here if needed
	uint32_t spsr_svc;
    uint32_t lr_svc;
    uint32_t sp_svc;       // optional, only if/when you bank SP in SVC
} CPU;

extern CPU cpu;       // Global CPU instance (only declaration you need)

// -----------------------------------------------------------------------------
// Public configuration defaults
// -----------------------------------------------------------------------------
#ifndef RAM_SIZE
#define RAM_SIZE (512u * 1024u * 1024u)   // 512 MiB default; can be overridden
#endif

#ifndef ENTRY_POINT
#define ENTRY_POINT 0x8000u               // default reset PC
#endif

#ifndef BIT
#define BIT(x) (1u << (x))
#endif

// -----------------------------------------------------------------------------
// Global VM state shared across modules
// -----------------------------------------------------------------------------
extern uint64_t  cycle;        // global cycle counter
extern bool      cpu_halted;   // run/stop latch

// -----------------------------------------------------------------------------
// Debug / logging
// -----------------------------------------------------------------------------
typedef enum {
    DBG_NONE        = 0,
    DBG_INSTR       = 1u << 0,
    DBG_MEM_READ    = 1u << 1,
    DBG_MEM_WRITE   = 1u << 2,
    DBG_STACK       = 1u << 3,
    DBG_REG         = 1u << 4,
    DBG_ALL         = 0xFFFFFFFFu
} DebugFlags;

extern DebugFlags debug_flags;
extern bool       trace_all;

// printf-style logger implemented elsewhere
void log_printf(const char *fmt, ...);

// -----------------------------------------------------------------------------
// Public CPU entry point
// -----------------------------------------------------------------------------
bool execute(uint32_t instr);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // CPU_H
