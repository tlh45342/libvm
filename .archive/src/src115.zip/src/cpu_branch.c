// cpu_branch.c — corrected handle_b (brace + logging block)
// Adjust the include below to whatever header exposes: cpu, cycle,
// evaluate_condition(), debug_flags, log_printf(), and DBG_INSTR.
#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include "cpu.h"  // or "arm-vm.h" in your tree

bool handle_b(uint32_t instr) {
    uint32_t pc = cpu.r[15] - 4;          // address of current instruction
    uint32_t pc_effective = pc + 8;       // ARM PC-relative base

    int32_t offset = (int32_t)(instr & 0x00FFFFFF);
    if (offset & 0x00800000) {
        offset |= 0xFF000000;             // sign-extend 24-bit
    }
    offset <<= 2;

    uint8_t  cond   = (instr >> 28) & 0xF;
    uint32_t target = pc_effective + (uint32_t)offset;

    static const char *cond_names[16] = {
        "EQ", "NE", "CS", "CC", "MI", "PL", "VS", "VC",
        "HI", "LS", "GE", "LT", "GT", "LE", "AL", "NV"
    };

    bool taken = evaluate_condition(cond);

    // ✅ Wrap the multi-line logging block in braces to avoid -Wmisleading-indentation
    if (debug_flags & DBG_INSTR) {
        log_printf("[Cycle %08" PRIu64 "] PC=0x%08X Instr=0x%08X\n", cycle, pc, instr);
        log_printf("  [B] Condition: 0x%X (%s)\n", cond, cond_names[cond]);
        log_printf("      Offset:    0x%08X\n", (uint32_t)offset);
        log_printf("      PC base:   0x%08X (PC+8)\n", pc_effective);
        log_printf("      Target:    0x%08X\n", target);
    }

    if (taken) {
        if (debug_flags & DBG_INSTR) {
            log_printf("      Branch TAKEN\n");
        }
        cpu.r[15] = target;
    } else {
        if (debug_flags & DBG_INSTR) {
            log_printf("  [B] Branch NOT taken\n");
            log_printf("      Fallthrough: 0x%08X (PC+4)\n", pc + 4);
        }
        // PC already advanced by fetch; nothing else to do
    }

    return true;
}
