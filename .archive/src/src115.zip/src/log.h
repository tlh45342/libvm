#ifndef LOG_H
#define LOG_H

#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include "cpu.h"   // for DebugFlags, trace_all

// -----------------------------------------------------------------------------
// Extern globals
// -----------------------------------------------------------------------------
extern DebugFlags debug_flags;   // Current debug mask (default = DBG_NONE)
extern bool       trace_all;     // Enable full trace regardless of mask

// -----------------------------------------------------------------------------
// Logging helpers
// -----------------------------------------------------------------------------
void log_printf(const char *fmt, ...);
void log_info  (const char *fmt, ...);
void log_warn  (const char *fmt, ...);
void log_error (const char *fmt, ...);
bool log_set_file(const char *filename);
void start_log(const char *filename);
void stop_log(void);
bool log_is_active(void);

#endif // LOG_H
