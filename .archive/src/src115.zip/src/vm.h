#ifndef VM_H
#define VM_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// Opaque CPU/VM type
typedef struct VM VM;

// Debug flags (portable)
typedef enum {
    DBG_NONE        = 0,
    DBG_INSTR       = 1u << 0,
    DBG_MEM_READ    = 1u << 1,
    DBG_MEM_WRITE   = 1u << 2,
    DBG_BRANCH      = 1u << 3,
    DBG_MMIO        = 1u << 4,
    DBG_CALLS       = 1u << 5,
    DBG_ALL         = 0xFFFFFFFFu
} vm_debug_t;

// Lifecycle
VM*     vm_create(size_t ram_size);
void    vm_destroy(VM* vm);
void    vm_reset(VM* vm);

// Execution
bool    vm_step(VM* vm);                 // execute one instruction
bool    vm_run(VM* vm, uint64_t max_cycles);
void    vm_halt(VM* vm);
bool    vm_is_halted(const VM* vm);

// Memory
bool    vm_load_image(VM* vm, const void* data, size_t len, uint32_t addr);
bool    vm_read_mem(VM* vm, uint32_t addr, void* out, size_t len);
bool    vm_write_mem(VM* vm, uint32_t addr, const void* in, size_t len);

// Registers
uint32_t vm_get_reg(const VM* vm, int idx);   // 0..15
void     vm_set_reg(VM* vm, int idx, uint32_t value);
uint32_t vm_get_cpsr(const VM* vm);
void     vm_set_cpsr(VM* vm, uint32_t value);

// Debug / trace
void    vm_set_debug(VM* vm, vm_debug_t flags);
vm_debug_t vm_get_debug(const VM* vm);

// MMIO callback registration (portable)
typedef uint32_t (*vm_mmio_read_fn)(void* ctx, uint32_t addr);
typedef void     (*vm_mmio_write_fn)(void* ctx, uint32_t addr, uint32_t value);

bool    vm_map_mmio(VM* vm,
                    uint32_t base, uint32_t size,
                    vm_mmio_read_fn rfn, vm_mmio_write_fn wfn,
                    void* ctx);

#ifdef __cplusplus
}
#endif
#endif // VM_H