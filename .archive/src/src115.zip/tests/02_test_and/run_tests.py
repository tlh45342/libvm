import subprocess
import os
import sys

VM = "arm-vm.exe"
TEST_NAME = "test_and"

CHECKS = [
    ("Debug enabled", "[DEBUG] debug_flags set to 0x00000001"),

    # First trace (opcode may vary by toolchain; keep if you like it strict)
    ("Trace first instr", "[TRACE] PC=0x00008000 Instr=0xE30F00F0"),

    # AND operations
    ("AND r2 zero", "[AND reg] r2 = r0 (0xF0F0F0F0) & r1 (0x0F0F0F0F) => 0x00000000"),
    ("ANDS r3 nonzero", "[AND regs] r3 = r0 (0xF0F0F0F0) & r0 (0xF0F0F0F0) => 0xF0F0F0F0"),
    ("AND imm r4 mask", "[AND imm] r4 = r0 (0xF0F0F0F0) & 0xFF000000 => 0xF0000000"),

    # Halt
    ("[HALT] DEADBEEF", "[HALT] DEADBEEF"),

    # Final register snapshot (note lowercase hex in the dump)
    ("Registers header", "Registers:"),
    ("r2 zero", "r2  = 0x00000000"),
    ("r3 value", "r3  = 0xf0f0f0f0"),
    ("r4 value", "r4  = 0xf0000000"),
]

def run_test():
    print(f"Running {TEST_NAME}...")

    script_path = f"{TEST_NAME}.script"
    bin_path = f"{TEST_NAME}.bin"
    log_path = f"{TEST_NAME}.log"

    if not os.path.exists(script_path):
        print(f"❌ Missing script: {script_path}")
        return False

    if not os.path.exists(bin_path):
        print(f"❌ Missing binary: {bin_path}")
        return False

    try:
        subprocess.run(
            [VM],
            stdin=open(script_path, "r"),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
    except FileNotFoundError:
        print(f"❌ Error: '{VM}' not found in PATH.")
        return False

    if not os.path.exists(log_path):
        print(f"❌ Missing log file: {log_path}")
        return False

    with open(log_path, "r") as f:
        log = f.read()

    passed = True
    for label, expected in CHECKS:
        if expected not in log:
            print(f"  ❌ Check failed: {label}")
            print(f"     Missing: {expected}")
            passed = False
        else:
            print(f"  ✅ {label}")

    print(f"{TEST_NAME}: {'✅ passed' if passed else '❌ failed'}\n")
    return passed

if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)