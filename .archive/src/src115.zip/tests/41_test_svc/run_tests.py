import subprocess
import os
import sys

VM = "arm-vm.exe"
TEST_NAME = "test_svc"

CHECKS = [
    # confirm start of copy
    ("[LDR literal] r15 = mem[0x00008020]", "[LDR literal] r15 = mem[0x00008020]"),
    ("[MOV imm] r2 = 0x00000040", "[MOV imm] r2 = 0x00000040"),

    # loop exit when r2 hits zero
    ("[SUBS imm] r2 = r2 - 0x00000004 => 0x00000000", "[SUBS imm] r2 = r2 - 0x00000004 => 0x00000000"),
    ("[B] cond fail (0x1) -> not taken", "[B] cond fail (0x1) -> not taken"),

    # DSB and ISB barriers
    ("[DSB SY] Data Synchronization Barrier (nop)", "[DSB SY] Data Synchronization Barrier (nop)"),
    ("[ISB SY] Instruction Synchronization Barrier (nop)", "[ISB SY] Instruction Synchronization Barrier (nop)"),

    # SVC entry
    ("[SVC] imm=0x000042", "[SVC] imm=0x000042"),

    # (optional) if your SVC handler or test later halts:
    ("[HALT] DEADBEEF", "[HALT] DEADBEEF"),
]

def run_test():
    print(f"Running {TEST_NAME}...")

    script_path = f"{TEST_NAME}.script"
    bin_path = f"{TEST_NAME}.bin"
    log_path = f"{TEST_NAME}.log"

    if not os.path.exists(script_path):
        print(f"❌ Missing script: {script_path}")
        return False

    if not os.path.exists(bin_path):
        print(f"❌ Missing binary: {bin_path}")
        return False

    try:
        subprocess.run(
            [VM],
            stdin=open(script_path, "r"),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
    except FileNotFoundError:
        print(f"❌ Error: '{VM}' not found in PATH.")
        return False

    if not os.path.exists(log_path):
        print(f"❌ Missing log file: {log_path}")
        return False

    with open(log_path, "r") as f:
        log = f.read()

    passed = True
    for label, expected in CHECKS:
        if expected not in log:
            print(f"  ❌ Check failed: {label}")
            print(f"     Missing: {expected}")
            passed = False
        else:
            print(f"  ✅ {label}")

    print(f"{TEST_NAME}: {'✅ passed' if passed else '❌ failed'}\n")
    return passed

if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)