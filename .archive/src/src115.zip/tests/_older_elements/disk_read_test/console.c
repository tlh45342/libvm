#include "crt.h"
#include "console.h"

void console_init(void)            { crt_init(CRT_DEFAULT_ATTR); }
void console_putc(char c)          { crt_putc(c); }
void console_puts(const char *s)   { crt_puts(s); }
/* kprintf is implemented in crt.c; nothing else needed here */