#pragma once
void console_init(void);
void console_putc(char c);
void console_puts(const char *s);

/* Provided by crt.c; prototype here for convenience */
void kprintf(const char *fmt, ...);