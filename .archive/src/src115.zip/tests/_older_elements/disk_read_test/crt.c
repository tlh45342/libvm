// crt.c
#include "crt.h"
#include <stdarg.h>
#include <stdint.h>

static volatile uint8_t *const CRT = (volatile uint8_t*)CRT_BASE_ADDR;

static uint32_t s_col = 0, s_row = 0;
static uint8_t  s_attr = CRT_DEFAULT_ATTR;

static inline uint32_t idx_from_xy(uint32_t col, uint32_t row) {
    return (row * CRT_COLS + col) * CRT_CELL_B;
}

void crt_set_attr(uint8_t attr) { s_attr = attr; }

void crt_gotoxy(uint32_t col, uint32_t row) {
    if (col >= CRT_COLS) col = CRT_COLS - 1;
    if (row >= CRT_ROWS) row = CRT_ROWS - 1;
    s_col = col; s_row = row;
}

void crt_clear(uint8_t attr) {
    s_attr = attr;
    for (uint32_t r = 0; r < CRT_ROWS; ++r) {
        for (uint32_t c = 0; c < CRT_COLS; ++c) {
            uint32_t i = idx_from_xy(c, r);
            CRT[i+0] = ' ';
            CRT[i+1] = s_attr;
        }
    }
    s_col = s_row = 0;
}

void crt_init(uint8_t attr) {
    crt_clear(attr);
}

static void scroll_one_line(void) {
    // Move rows 1..(ROWS-1) up to 0..(ROWS-2)
    const uint32_t row_bytes = CRT_COLS * CRT_CELL_B;
    const uint32_t total_bytes = row_bytes * CRT_ROWS;

    // memmove up by one row (do it manually to avoid libc)
    for (uint32_t i = 0; i < total_bytes - row_bytes; ++i) {
        CRT[i] = CRT[i + row_bytes];
    }
    // Clear last row
    for (uint32_t c = 0; c < CRT_COLS; ++c) {
        uint32_t i = idx_from_xy(c, CRT_ROWS - 1);
        CRT[i+0] = ' ';
        CRT[i+1] = s_attr;
    }
}

static void advance_cursor(void) {
    ++s_col;
    if (s_col >= CRT_COLS) {
        s_col = 0;
        ++s_row;
        if (s_row >= CRT_ROWS) {
            scroll_one_line();
            s_row = CRT_ROWS - 1;
        }
    }
}

void crt_putc(char ch) {
    switch (ch) {
        case '\r':
            s_col = 0;
            return;
        case '\n':
            s_col = 0;
            ++s_row;
            if (s_row >= CRT_ROWS) {
                scroll_one_line();
                s_row = CRT_ROWS - 1;
            }
            return;
        case '\t': {
            uint32_t next = (s_col + 8) & ~7u;
            while (s_col < CRT_COLS && s_col < next) {
                crt_putc(' ');
            }
            return;
        }
        default:
            break;
    }
    uint32_t i = idx_from_xy(s_col, s_row);
    CRT[i+0] = (uint8_t)ch;
    CRT[i+1] = s_attr;
    advance_cursor();
}

void crt_puts(const char* s) { while (*s) crt_putc(*s++); }
void crt_write(const char* s, size_t n) { for (size_t i=0;i<n;i++) crt_putc(s[i]); }

// ---- minimal printf ----
static void put_hex32(uint32_t v) {
    static const char *hex="0123456789ABCDEF";
    for (int i=7;i>=0;--i) crt_putc(hex[(v>>(i*4)) & 0xF]);
}
static void put_uint(unsigned v) {
    char buf[16]; int i=0;
    if (v==0) { crt_putc('0'); return; }
    while (v && i<(int)sizeof(buf)) { buf[i++] = '0' + (v%10); v/=10; }
    while (i--) crt_putc(buf[i]);
}
void kprintf(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    for (; *fmt; ++fmt) {
        if (*fmt != '%') { crt_putc(*fmt); continue; }
        switch (*++fmt) {
            case 's': { const char* s = va_arg(ap, const char*); crt_puts(s ? s : "(null)"); } break;
            case 'x': put_hex32(va_arg(ap, unsigned)); break;
            case 'u': put_uint(va_arg(ap, unsigned)); break;
            case 'c': crt_putc((char)va_arg(ap, int)); break;
            case '%': crt_putc('%'); break;
            default:  crt_putc('?'); break;
        }
    }
    va_end(ap);
}