// crt.h — direct text buffer driver (char,attr) at 0x0A000000
#pragma once
#include <stdint.h>
#include <stddef.h>

// --- geometry; tweak if yours differs ---
#define CRT_COLS   80u
#define CRT_ROWS   25u
#define CRT_CELL_B 2u      // 1 byte char + 1 byte attribute

#define CRT_BASE_ADDR 0x0A000000u  // matches your ASM comment
#define CRT_DEFAULT_ATTR 0x07      // light grey on black

#ifdef __cplusplus
extern "C" {
#endif

void crt_init(uint8_t attr);               // sets cursor=0, clears screen to attr
void crt_clear(uint8_t attr);              // fill with spaces/attr
void crt_gotoxy(uint32_t col, uint32_t row);
void crt_set_attr(uint8_t attr);
void crt_putc(char c);                     // handles \n \r \t and scroll
void crt_puts(const char* s);
void crt_write(const char* s, size_t n);

// Tiny printf backed by crt_putc (supports %s %u %x %c %%)
void kprintf(const char *fmt, ...);

#ifdef __cplusplus
}
#endif