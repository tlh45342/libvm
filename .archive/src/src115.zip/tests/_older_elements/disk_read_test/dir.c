#include "dir.h"
#include "mmio_disk.h"
#include "crt.h"
#define printf kprintf

#pragma pack(push,1)
typedef struct {
    uint8_t  name[11];     // 8 + 3, space padded
    uint8_t  attr;         // 0x0F = LFN
    uint8_t  nt_res;
    uint8_t  crt_time_tenth;
    uint16_t crt_time;
    uint16_t crt_date;
    uint16_t lst_acc_date;
    uint16_t fst_clus_hi;  // FAT32 high
    uint16_t wrt_time;
    uint16_t wrt_date;
    uint16_t fst_clus_lo;
    uint32_t file_size;
} dirent_t;
#pragma pack(pop)

// ASCII-only uppercase helper (avoids <ctype.h> dependency)
static char up_ascii(char c) {
    return (c >= 'a' && c <= 'z') ? (char)(c - ('a' - 'A')) : c;
}

static void print_83_name(const uint8_t name[11]) {
    char out[13] = {0};
    int p = 0;

    // base name (up to 8 chars, stop at space)
    for (int i = 0; i < 8 && name[i] != ' '; ++i) {
        out[p++] = (char)name[i];
    }

    // extension (add dot only if there is one)
    if (name[8] != ' ') {
        out[p++] = '.';
        for (int i = 8; i < 11 && name[i] != ' '; ++i) {
            out[p++] = (char)name[i];
        }
    }
    out[p] = 0;

    // Uppercase for display (ASCII only)
    for (int i = 0; out[i]; ++i) {
        out[i] = up_ascii(out[i]);
    }

    printf("%s", out[0] ? out : "(blank)");
}

bool list_root_dir(const fat_bpb_info_t *bi) {
    // For now, only FAT12/16 root directory (fixed area). FAT32 root is cluster-based.
    if (bi->fat_type == 32) {
        printf("[FAT32] (cluster-based root) -- we'll hook this up next.\n");
        return false;
    }

    // How many 32-byte entries in the fixed root directory area?
    uint32_t entries = (bi->root_dir_sectors * bi->bytes_per_sec) / (uint32_t)sizeof(dirent_t);
    if (entries == 0) return false;

    // Read the entire root directory into a small scratch buffer.
    // For a 1.44MB FAT12 floppy: root_dir_sectors = 14 -> 14 * 512 = 7168 bytes.
    static uint8_t root_buf[32 * 512]; // 16 KiB scratch
    if ((bi->root_dir_sectors * SECTOR_SIZE) > sizeof(root_buf)) {
        printf("Root directory too large for temp buffer.\n");
        return false;
    }

    if (!disk_read(bi->first_root_dir_sector, bi->root_dir_sectors, root_buf)) {
        printf("disk_read root directory failed.\n");
        return false;
    }

    printf("ROOT DIR (FAT%u):\n", (unsigned)bi->fat_type);

    for (uint32_t i = 0; i < entries; ++i) {
        const dirent_t *de = (const dirent_t *)(root_buf + i * sizeof(dirent_t));

        // 0x00 = no more entries
        if (de->name[0] == 0x00) break;

        // 0xE5 = deleted entry
        if (de->name[0] == 0xE5) continue;

        // Long File Name entry (skip for now)
        if (de->attr == 0x0F) continue;

        // Compute starting cluster
        uint32_t clus = ((uint32_t)de->fst_clus_hi << 16) | (uint32_t)de->fst_clus_lo;
        if (bi->fat_type != 32) {
            // For FAT12/16, high word should be 0; use low part
            clus = de->fst_clus_lo;
        }

        printf("  ");
        print_83_name(de->name);
        printf("  attr=0x%02X  start=%u  size=%u\n",
               de->attr, (unsigned)clus, (unsigned)de->file_size);
    }

    return true;
}