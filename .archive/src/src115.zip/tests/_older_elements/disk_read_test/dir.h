#ifndef DIR_H
#define DIR_H

#include <stdint.h>
#include <stdbool.h>
#include "fat.h"

bool list_root_dir(const fat_bpb_info_t *bi);

#endif // DIR_H