#include "fat.h"
#include "mmio_disk.h"
#include <string.h>
#include "crt.h"
#define printf kprintf

#pragma pack(push,1)
typedef struct {
    uint8_t  jmp_boot[3];     // EB 3C 90
    uint8_t  oem_name[8];
    uint16_t bytes_per_sec;   // 0x0B
    uint8_t  sec_per_clus;    // 0x0D
    uint16_t rsvd_sec_cnt;    // 0x0E
    uint8_t  num_fats;        // 0x10
    uint16_t root_ent_cnt;    // 0x11 (0 for FAT32)
    uint16_t tot_sec16;       // 0x13
    uint8_t  media;           // 0x15
    uint16_t fatsz16;         // 0x16
    uint16_t sec_per_trk;     // 0x18
    uint16_t num_heads;       // 0x1A
    uint32_t hidd_sec;        // 0x1C
    uint32_t tot_sec32;       // 0x20

    // FAT12/16 Extended
    uint8_t  drv_num;
    uint8_t  reserved1;
    uint8_t  boot_sig;
    uint32_t vol_id;
    uint8_t  vol_lab[11];
    uint8_t  fil_sys_type[8];

    // For FAT32, these fields start at 0x24; but we read only sector 0 here
    // and will reinterpret if needed.
} BPB1216_t;

typedef struct {
    uint8_t  jmp_boot[3];
    uint8_t  oem_name[8];
    uint16_t bytes_per_sec;
    uint8_t  sec_per_clus;
    uint16_t rsvd_sec_cnt;
    uint8_t  num_fats;
    uint16_t root_ent_cnt;     // must be 0 for FAT32
    uint16_t tot_sec16;
    uint8_t  media;
    uint16_t fatsz16;          // must be 0 for FAT32
    uint16_t sec_per_trk;
    uint16_t num_heads;
    uint32_t hidd_sec;
    uint32_t tot_sec32;

    // FAT32 extended
    uint32_t fatsz32;
    uint16_t ext_flags;
    uint16_t fs_ver;
    uint32_t root_clus;        // usually 2
    uint16_t fs_info;
    uint16_t bk_boot_sec;
    uint8_t  reserved[12];

    uint8_t  drv_num;
    uint8_t  reserved1;
    uint8_t  boot_sig;
    uint32_t vol_id;
    uint8_t  vol_lab[11];
    uint8_t  fil_sys_type[8];
} BPB32_t;
#pragma pack(pop)

static uint8_t sector0[SECTOR_SIZE];

bool fat_read_bpb(fat_bpb_info_t *out) {
    if (!disk_read_sector(0, sector0)) return false;

    // We’ll peek at fatsz16; if zero and root_ent_cnt == 0, assume FAT32.
    const BPB1216_t *b = (const BPB1216_t *)sector0;

    memset(out, 0, sizeof(*out));
    out->bytes_per_sec  = b->bytes_per_sec;
    out->sec_per_clus   = b->sec_per_clus;
    out->rsvd_sec_cnt   = b->rsvd_sec_cnt;
    out->num_fats       = b->num_fats;
    out->root_ent_cnt   = b->root_ent_cnt;
    out->tot_sec        = (b->tot_sec16 != 0) ? b->tot_sec16 : b->tot_sec32;
    out->fatsz16        = b->fatsz16;
    out->hidd_sec       = b->hidd_sec;
    out->sec_per_trk    = b->sec_per_trk;
    out->num_heads      = b->num_heads;

    bool is_fat32 = (b->fatsz16 == 0 && b->root_ent_cnt == 0);
    if (is_fat32) {
        const BPB32_t *b32 = (const BPB32_t *)sector0;
        out->fatsz32 = b32->fatsz32;
        out->fat_sz  = b32->fatsz32;
        out->root_cluster = b32->root_clus;
    } else {
        out->fat_sz = b->fatsz16;
    }

    // Compute layout
    if (!is_fat32) {
        // FAT12/16:
        uint32_t root_dir_bytes = (uint32_t)out->root_ent_cnt * 32u;
        out->root_dir_sectors = (root_dir_bytes + (out->bytes_per_sec - 1)) / out->bytes_per_sec;
        out->first_root_dir_sector = out->rsvd_sec_cnt + (out->num_fats * out->fat_sz);
        out->first_data_sector = out->first_root_dir_sector + out->root_dir_sectors;
    } else {
        // FAT32:
        out->root_dir_sectors = 0;
        out->first_data_sector = out->rsvd_sec_cnt + (out->num_fats * out->fat_sz);
    }

    // Determine FAT type by data cluster count
    uint32_t tot_data_sectors = out->tot_sec - (out->rsvd_sec_cnt + (out->num_fats * out->fat_sz) + out->root_dir_sectors);
    uint32_t count_of_clusters = tot_data_sectors / out->sec_per_clus;

    if (is_fat32) {
        out->fat_type = 32;
    } else if (count_of_clusters < 4085) {
        out->fat_type = 12;
    } else {
        out->fat_type = 16;
    }

    return true;
}