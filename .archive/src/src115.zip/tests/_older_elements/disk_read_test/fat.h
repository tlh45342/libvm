#ifndef FAT_H
#define FAT_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
    uint16_t bytes_per_sec;
    uint8_t  sec_per_clus;
    uint16_t rsvd_sec_cnt;
    uint8_t  num_fats;
    uint16_t root_ent_cnt;   // 0 for FAT32
    uint32_t tot_sec;        // from 16 or 32
    uint16_t fatsz16;        // non-zero for FAT12/16
    uint32_t fatsz32;        // non-zero for FAT32
    uint32_t hidd_sec;
    uint16_t sec_per_trk;
    uint16_t num_heads;

    // computed
    uint32_t fat_sz;         // chosen from fatsz16/32
    uint32_t root_dir_sectors; // FAT12/16 only
    uint32_t first_data_sector;
    uint32_t first_root_dir_sector; // FAT12/16 only
    uint8_t  fat_type;       // 12, 16, or 32
    uint32_t root_cluster;   // FAT32 only (cluster number)
} fat_bpb_info_t;

bool fat_read_bpb(fat_bpb_info_t *out);

#endif // FAT_H