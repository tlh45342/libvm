#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "mmio_disk.h"
#include "fat.h"
#include "dir.h"
#include "crt.h"
#define printf kprintf

// If you have your own UART/print, replace printf calls accordingly.

int main(void) {
    printf("Disk probe...\n");

    // 1) Read BPB
    fat_bpb_info_t bi;
    if (!fat_read_bpb(&bi)) {
        printf("Failed to read BPB.\n");
        return 1;
    }

    printf("BPB: bytes/sect=%u  sec/clus=%u  rsvd=%u  FATs=%u  rootEnt=%u\n",
        bi.bytes_per_sec, bi.sec_per_clus, bi.rsvd_sec_cnt, bi.num_fats, bi.root_ent_cnt);
    printf("     totSec=%u  fatSz=%u  firstRoot=%u  firstData=%u  FAT%u\n",
        bi.tot_sec, bi.fat_sz, bi.first_root_dir_sector, bi.first_data_sector, bi.fat_type);

    // 2) List root directory (FAT12/16 path for now)
    if (!list_root_dir(&bi)) {
        printf("Root listing failed or not FAT12/16.\n");
        return 2;
    }

    printf("Done.\n");
    return 0;
}