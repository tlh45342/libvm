#include "mmio_disk.h"
#include <stdint.h>

static bool wait_mask_clear(volatile uint32_t *reg, uint32_t mask, uint32_t iters) {
    while (iters--) { if ( ((*reg) & mask) == 0 ) return true; }
    return false;
}
static bool wait_ready(uint32_t iters) {
    while (iters--) {
        uint32_t st = DISK_REG_STATUS;
        if (st & DISK_STATUS_ERROR) return false;
        if ((st & DISK_STATUS_READY) && !(st & DISK_STATUS_BUSY)) return true;
    }
    return false;
}

bool disk_read_sector(uint32_t lba, void *dst) {
    if (!wait_mask_clear(&DISK_REG_STATUS, DISK_STATUS_BUSY, 10000000)) return false;
    DISK_REG_LBA = lba;
    DISK_REG_COUNT = 1;
    DISK_REG_DMA_ADDR = (uint32_t)dst;
    DISK_REG_CMD = DISK_CMD_READ;
    return wait_ready(10000000);
}
bool disk_read(uint32_t lba, uint32_t count, void *dst) {
    uint8_t *p = (uint8_t*)dst;
    for (uint32_t i=0;i<count;++i)
        if (!disk_read_sector(lba+i, p + i*SECTOR_SIZE)) return false;
    return true;
}