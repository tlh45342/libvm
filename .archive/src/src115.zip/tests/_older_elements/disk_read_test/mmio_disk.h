#pragma once
#include <stdint.h>
#include <stdbool.h>

#define DISK_MMIO_BASE        0x40020000u
#define DISK_REG_CMD          (*(volatile uint32_t*)(DISK_MMIO_BASE + 0x00))
#define DISK_REG_STATUS       (*(volatile uint32_t*)(DISK_MMIO_BASE + 0x04))
#define DISK_REG_LBA          (*(volatile uint32_t*)(DISK_MMIO_BASE + 0x08))
#define DISK_REG_COUNT        (*(volatile uint32_t*)(DISK_MMIO_BASE + 0x0C))
#define DISK_REG_DMA_ADDR     (*(volatile uint32_t*)(DISK_MMIO_BASE + 0x10))

#define DISK_CMD_READ         (1u << 0)
#define DISK_STATUS_BUSY      (1u << 0)
#define DISK_STATUS_READY     (1u << 1)
#define DISK_STATUS_ERROR     (1u << 2)

#define SECTOR_SIZE           512u

bool disk_read_sector(uint32_t lba, void *dst);
bool disk_read(uint32_t lba, uint32_t count, void *dst);