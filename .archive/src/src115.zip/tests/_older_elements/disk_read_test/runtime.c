// runtime.c — tiny shims for freestanding builds
#include <stdint.h>
#include <stddef.h>

void *memcpy(void *dst, const void *src, size_t n) {
    uint8_t *d = (uint8_t*)dst; const uint8_t *s = (const uint8_t*)src;
    while (n--) *d++ = *s++;
    return dst;
}
void *memset(void *dst, int c, size_t n) {
    uint8_t *d = (uint8_t*)dst; uint8_t v = (uint8_t)c;
    while (n--) *d++ = v;
    return dst;
}
int memcmp(const void *a, const void *b, size_t n) {
    const uint8_t *p=(const uint8_t*)a,*q=(const uint8_t*)b;
    while (n--) { if (*p!=*q) return (int)*p - (int)*q; ++p; ++q; }
    return 0;
}
size_t strlen(const char *s) { const char *p=s; while (*p) ++p; return (size_t)(p-s); }