arm-none-eabi-as start.S -o start.o arm-none-eabi-gcc -c -nostdlib -nostartfiles -ffreestanding kernel.c -o kernel.o C:\Users\User\AppData\Local\Temp\ccQfitvl.s: Assembler messages: C:\Users\User\AppData\Local\Temp\ccQfitvl.s:95: Error: selected processor does not support `wfi' in ARM mode `make: *** [Makefile:13: kernel.o] Error 1



###### ChatGPT said:

Great — you're almost there. The new error:

```
vbnet


CopyEdit
Error: selected processor does not support `wfi' in ARM mode
```

means that you're compiling for an ARM architecture that **doesn’t support the `wfi` instruction** (Wait For Interrupt) in **ARM (A32) mode**.

------

## ✅ Solution Options

You have two ways to fix this:

------

### ✅ **Option 1: Use a modern architecture that supports `wfi`**

Pass an explicit architecture flag that supports `wfi`, such as **Cortex-A7 or A15** (both common in QEMU):

#### Modify your `Makefile` or command line:

```
bash


CopyEdit
arm-none-eabi-gcc -c -nostdlib -nostartfiles -ffreestanding -mcpu=cortex-a7 kernel.c -o kernel.o
```

Or for Cortex-A15:

```
bash


CopyEdit
arm-none-eabi-gcc -c -nostdlib -nostartfiles -ffreestanding -mcpu=cortex-a15 kernel.c -o kernel.o
```

These CPUs support `wfi` in ARM mode.

------

### ✅ **Option 2: Use inline assembly that avoids `wfi` if not needed**

If you just want to **halt in place**, you can use a tight loop instead of `wfi`:

#### Replace in `kernel.c`:

```
c


CopyEdit
while (1) __asm__ volatile ("wfi");
```

with:

```
c


CopyEdit
while (1);
```

> This won't sleep the CPU, but it works for now, especially in QEMU.

------

### 🧠 Bonus: What is `wfi`?

`wfi` = **Wait For Interrupt** — it's a low-power instruction that pauses the core until an IRQ or FIQ. Used in idle loops on ARM.

Only available on CPUs that support it **in the current mode (AArch32 or AArch64)**.

------

## ✅ Final Checklist

| Action                                  | Status        |
| --------------------------------------- | ------------- |
| Use `.global` in assembly               | ✅ Fixed       |
| Use `arm-none-eabi-gcc` to compile `.S` | ✅ Confirmed   |
| Use `-mcpu=cortex-a7` to enable `wfi`   | ✅ RECOMMENDED |
| Can remove `wfi` for non-sleep testing  | ✅ ALTERNATIVE |

