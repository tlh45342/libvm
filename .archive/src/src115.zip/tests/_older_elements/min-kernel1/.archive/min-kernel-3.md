O:\min-kernel>arm-none-eabi-nm kernel.bin arm-none-eabi-nm: kernel.bin: file format not recognized



###### ChatGPT said:

You're getting:

```
less


CopyEdit
arm-none-eabi-nm: kernel.bin: file format not recognized
```

because `kernel.bin` is a **raw flat binary**, not an ELF executable. Tools like `nm`, `objdump`, etc. expect an **ELF file** with symbol tables, sections, etc.

------

## ✅ Fix

Use `nm` on the **ELF version**, not the raw binary.

If your `Makefile` built `kernel.elf` and then stripped out `kernel.bin`, use:

```
bash


CopyEdit
arm-none-eabi-nm kernel.elf
```

✅ `kernel.elf` is the correct file to inspect symbols, debug info, and disassembly.

------

## ✅ Summary

| File         | Format | Use with tools?                     |
| ------------ | ------ | ----------------------------------- |
| `kernel.elf` | ELF    | ✅ `nm`, `objdump`, `gdb`            |
| `kernel.bin` | raw    | ❌ `nm` won’t work (no symbol table) |



------

## 🧠 Optional: See Symbols and Addresses

```
bash


CopyEdit
arm-none-eabi-nm -n kernel.elf
```

To list symbols in order by address.