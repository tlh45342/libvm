arm-none-eabi-objdump -D -b binary -m arm -M reg-names-std -EL --adjust-vma=0x8000 kernel.bin



can you explain " --adjust-vma"



###### ChatGPT said:

Absolutely.

### 🔧 `--adjust-vma` Explained

`--adjust-vma` is a flag used with `objdump` to **adjust the Virtual Memory Address (VMA)** when disassembling or displaying sections from a file.

------

### 📦 Context

When you're disassembling a **raw binary** (like `kernel.bin`), it has **no metadata** — no information about:

- Where in memory it's supposed to be loaded
- Symbol addresses
- Section headers

By default, `objdump` assumes the file starts at address `0x0`.

But if your bootloader (or QEMU) **loads it at a known address**, like `0x8000`, you want disassembly to reflect that real address.

------

### ✅ Syntax

```
bash


CopyEdit
--adjust-vma=<hex address>
```

This tells `objdump`:

> “Pretend this file is loaded starting at this address.”

------

### 🔍 Example

Say `kernel.bin` is loaded at **0x8000**.

Without `--adjust-vma`:

```
bashCopyEdit00000000 <.data>:
   0:   e59fd008    ldr r0, [pc, #8]
   4:   eb000002    bl 0x14
```

With `--adjust-vma=0x8000`:

```
bashCopyEdit00008000 <.data>:
   8000:   e59fd008    ldr r0, [pc, #8]
   8004:   eb000002    bl 0x8014
```

Much better: you now see **real memory addresses**, useful when:

- Debugging in QEMU with `gdb`
- Tracing branches and absolute addresses
- Comparing against hardware behavior

------

### 📚 Summary

| Flag                | Purpose                                             |
| ------------------- | --------------------------------------------------- |
| `--adjust-vma=ADDR` | Adjusts base address in disassembly output          |
| When used?          | For flat binaries or non-relocatable sections       |
| Why?                | To match real memory layout, e.g. loaded at `0x800` |