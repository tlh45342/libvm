After updating start.s to initialize FP as well as SP, as we intend to call C routines.



O:\min-kernel\src>make
arm-none-eabi-as start.s -o start.o
arm-none-eabi-gcc -c -nostdlib -nostartfiles -ffreestanding -mcpu=cortex-a15 -Wall -Werror kernel.c -o kernel.o
arm-none-eabi-ld -T linker.ld -o kernel.elf start.o kernel.o
arm-none-eabi-objcopy -O binary kernel.elf kernel.bin

O:\min-kernel\src>arm-none-eabi-nm kernel.elf
00008280 r .LC0
00008000 T _start
0000827c R crt
000080f8 T crt_putc
0000802c T crt_putc_at
00008204 T crt_puts
000082a4 B cursor_col
000082a0 B cursor_row
00008014 t halt_loop
0000825c T kmain
00008020 t stack_top

O:\min-kernel\src>arm-none-eabi-objdump -d kernel.elf

kernel.elf:     file format elf32-littlearm


Disassembly of section .text:

00008000 <_start>:
    8000:       e59fd01c        ldr     sp, [pc, #28]   ; 8024 <stack_top+0x4>
    8004:       e1a0b00d        mov     fp, sp
    8008:       e59fe018        ldr     lr, [pc, #24]   ; 8028 <stack_top+0x8>
    800c:       e52de004        push    {lr}            ; (str lr, [sp, #-4]!)
    8010:       eb000091        bl      825c <kmain>

00008014 <halt_loop>:
    8014:       e320f003        wfi
    8018:       eafffffd        b       8014 <halt_loop>
    801c:       e1a00000        nop                     ; (mov r0, r0)

00008020 <stack_top>:
    8020:       1fffff00        .word   0x1fffff00
    8024:       00008020        .word   0x00008020
    8028:       00008014        .word   0x00008014

0000802c <crt_putc_at>:
    802c:       e52db004        push    {fp}            ; (str fp, [sp, #-4]!)
    8030:       e28db000        add     fp, sp, #0
    8034:       e24dd014        sub     sp, sp, #20
    8038:       e50b200c        str     r2, [fp, #-12]
    803c:       e50b3010        str     r3, [fp, #-16]
    8040:       e1a03000        mov     r3, r0
    8044:       e54b3005        strb    r3, [fp, #-5]
    8048:       e1a03001        mov     r3, r1
    804c:       e54b3006        strb    r3, [fp, #-6]
    8050:       e51b300c        ldr     r3, [fp, #-12]
    8054:       e3530000        cmp     r3, #0
    8058:       ba000022        blt     80e8 <crt_putc_at+0xbc>
    805c:       e51b300c        ldr     r3, [fp, #-12]
    8060:       e3530018        cmp     r3, #24
    8064:       ca00001f        bgt     80e8 <crt_putc_at+0xbc>
    8068:       e51b3010        ldr     r3, [fp, #-16]
    806c:       e3530000        cmp     r3, #0
    8070:       ba00001c        blt     80e8 <crt_putc_at+0xbc>
    8074:       e51b3010        ldr     r3, [fp, #-16]
    8078:       e353004f        cmp     r3, #79 ; 0x4f
    807c:       ca000019        bgt     80e8 <crt_putc_at+0xbc>
    8080:       e3a01202        mov     r1, #536870912  ; 0x20000000
    8084:       e51b200c        ldr     r2, [fp, #-12]
    8088:       e1a03002        mov     r3, r2
    808c:       e1a03103        lsl     r3, r3, #2
    8090:       e0833002        add     r3, r3, r2
    8094:       e1a03203        lsl     r3, r3, #4
    8098:       e1a02003        mov     r2, r3
    809c:       e51b3010        ldr     r3, [fp, #-16]
    80a0:       e0823003        add     r3, r2, r3
    80a4:       e1a03083        lsl     r3, r3, #1
    80a8:       e0813003        add     r3, r1, r3
    80ac:       e55b2005        ldrb    r2, [fp, #-5]
    80b0:       e5c32000        strb    r2, [r3]
    80b4:       e3a01202        mov     r1, #536870912  ; 0x20000000
    80b8:       e51b200c        ldr     r2, [fp, #-12]
    80bc:       e1a03002        mov     r3, r2
    80c0:       e1a03103        lsl     r3, r3, #2
    80c4:       e0833002        add     r3, r3, r2
    80c8:       e1a03203        lsl     r3, r3, #4
    80cc:       e1a02003        mov     r2, r3
    80d0:       e51b3010        ldr     r3, [fp, #-16]
    80d4:       e0823003        add     r3, r2, r3
    80d8:       e1a03083        lsl     r3, r3, #1
    80dc:       e0813003        add     r3, r1, r3
    80e0:       e55b2006        ldrb    r2, [fp, #-6]
    80e4:       e5c32001        strb    r2, [r3, #1]
    80e8:       e320f000        nop     {0}
    80ec:       e28bd000        add     sp, fp, #0
    80f0:       e49db004        pop     {fp}            ; (ldr fp, [sp], #4)
    80f4:       e12fff1e        bx      lr

000080f8 <crt_putc>:
    80f8:       e52db008        str     fp, [sp, #-8]!
    80fc:       e58de004        str     lr, [sp, #4]
    8100:       e28db004        add     fp, sp, #4
    8104:       e24dd008        sub     sp, sp, #8
    8108:       e1a03000        mov     r3, r0
    810c:       e54b3005        strb    r3, [fp, #-5]
    8110:       e55b3005        ldrb    r3, [fp, #-5]
    8114:       e353000a        cmp     r3, #10
    8118:       1a00000b        bne     814c <crt_putc+0x54>
    811c:       e30832a4        movw    r3, #33444      ; 0x82a4
    8120:       e3403000        movt    r3, #0
    8124:       e3a02000        mov     r2, #0
    8128:       e5832000        str     r2, [r3]
    812c:       e30832a0        movw    r3, #33440      ; 0x82a0
    8130:       e3403000        movt    r3, #0
    8134:       e5933000        ldr     r3, [r3]
    8138:       e2832001        add     r2, r3, #1
    813c:       e30832a0        movw    r3, #33440      ; 0x82a0
    8140:       e3403000        movt    r3, #0
    8144:       e5832000        str     r2, [r3]
    8148:       ea00001f        b       81cc <crt_putc+0xd4>
    814c:       e30832a0        movw    r3, #33440      ; 0x82a0
    8150:       e3403000        movt    r3, #0
    8154:       e5932000        ldr     r2, [r3]
    8158:       e30832a4        movw    r3, #33444      ; 0x82a4
    815c:       e3403000        movt    r3, #0
    8160:       e5933000        ldr     r3, [r3]
    8164:       e55b0005        ldrb    r0, [fp, #-5]
    8168:       e3a01007        mov     r1, #7
    816c:       ebffffae        bl      802c <crt_putc_at>
    8170:       e30832a4        movw    r3, #33444      ; 0x82a4
    8174:       e3403000        movt    r3, #0
    8178:       e5933000        ldr     r3, [r3]
    817c:       e2832001        add     r2, r3, #1
    8180:       e30832a4        movw    r3, #33444      ; 0x82a4
    8184:       e3403000        movt    r3, #0
    8188:       e5832000        str     r2, [r3]
    818c:       e30832a4        movw    r3, #33444      ; 0x82a4
    8190:       e3403000        movt    r3, #0
    8194:       e5933000        ldr     r3, [r3]
    8198:       e353004f        cmp     r3, #79 ; 0x4f
    819c:       da00000a        ble     81cc <crt_putc+0xd4>
    81a0:       e30832a4        movw    r3, #33444      ; 0x82a4
    81a4:       e3403000        movt    r3, #0
    81a8:       e3a02000        mov     r2, #0
    81ac:       e5832000        str     r2, [r3]
    81b0:       e30832a0        movw    r3, #33440      ; 0x82a0
    81b4:       e3403000        movt    r3, #0
    81b8:       e5933000        ldr     r3, [r3]
    81bc:       e2832001        add     r2, r3, #1
    81c0:       e30832a0        movw    r3, #33440      ; 0x82a0
    81c4:       e3403000        movt    r3, #0
    81c8:       e5832000        str     r2, [r3]
    81cc:       e30832a0        movw    r3, #33440      ; 0x82a0
    81d0:       e3403000        movt    r3, #0
    81d4:       e5933000        ldr     r3, [r3]
    81d8:       e3530018        cmp     r3, #24
    81dc:       da000003        ble     81f0 <crt_putc+0xf8>
    81e0:       e30832a0        movw    r3, #33440      ; 0x82a0
    81e4:       e3403000        movt    r3, #0
    81e8:       e3a02000        mov     r2, #0
    81ec:       e5832000        str     r2, [r3]
    81f0:       e320f000        nop     {0}
    81f4:       e24bd004        sub     sp, fp, #4
    81f8:       e59db000        ldr     fp, [sp]
    81fc:       e28dd004        add     sp, sp, #4
    8200:       e49df004        pop     {pc}            ; (ldr pc, [sp], #4)

00008204 <crt_puts>:
    8204:       e52db008        str     fp, [sp, #-8]!
    8208:       e58de004        str     lr, [sp, #4]
    820c:       e28db004        add     fp, sp, #4
    8210:       e24dd008        sub     sp, sp, #8
    8214:       e50b0008        str     r0, [fp, #-8]
    8218:       ea000005        b       8234 <crt_puts+0x30>
    821c:       e51b3008        ldr     r3, [fp, #-8]
    8220:       e2832001        add     r2, r3, #1
    8224:       e50b2008        str     r2, [fp, #-8]
    8228:       e5d33000        ldrb    r3, [r3]
    822c:       e1a00003        mov     r0, r3
    8230:       ebffffb0        bl      80f8 <crt_putc>
    8234:       e51b3008        ldr     r3, [fp, #-8]
    8238:       e5d33000        ldrb    r3, [r3]
    823c:       e3530000        cmp     r3, #0
    8240:       1afffff5        bne     821c <crt_puts+0x18>
    8244:       e320f000        nop     {0}
    8248:       e320f000        nop     {0}
    824c:       e24bd004        sub     sp, fp, #4
    8250:       e59db000        ldr     fp, [sp]
    8254:       e28dd004        add     sp, sp, #4
    8258:       e49df004        pop     {pc}            ; (ldr pc, [sp], #4)

0000825c <kmain>:
    825c:       e52db008        str     fp, [sp, #-8]!
    8260:       e58de004        str     lr, [sp, #4]
    8264:       e28db004        add     fp, sp, #4
    8268:       e3080280        movw    r0, #33408      ; 0x8280
    826c:       e3400000        movt    r0, #0
    8270:       ebffffe3        bl      8204 <crt_puts>
    8274:       e320f003        wfi
    8278:       eafffffd        b       8274 <kmain+0x18>

O:\min-kernel\src>hexdump kernel.bin
0000000 d01c e59f b00d e1a0 e018 e59f e004 e52d
0000010 0091 eb00 f003 e320 fffd eaff 0000 e1a0
0000020 ff00 1fff 8020 0000 8014 0000 b004 e52d
0000030 b000 e28d d014 e24d 200c e50b 3010 e50b
0000040 3000 e1a0 3005 e54b 3001 e1a0 3006 e54b
0000050 300c e51b 0000 e353 0022 ba00 300c e51b
0000060 0018 e353 001f ca00 3010 e51b 0000 e353
0000070 001c ba00 3010 e51b 004f e353 0019 ca00
0000080 1202 e3a0 200c e51b 3002 e1a0 3103 e1a0
0000090 3002 e083 3203 e1a0 2003 e1a0 3010 e51b
00000a0 3003 e082 3083 e1a0 3003 e081 2005 e55b
00000b0 2000 e5c3 1202 e3a0 200c e51b 3002 e1a0
00000c0 3103 e1a0 3002 e083 3203 e1a0 2003 e1a0
00000d0 3010 e51b 3003 e082 3083 e1a0 3003 e081
00000e0 2006 e55b 2001 e5c3 f000 e320 d000 e28b
00000f0 b004 e49d ff1e e12f b008 e52d e004 e58d
0000100 b004 e28d d008 e24d 3000 e1a0 3005 e54b
0000110 3005 e55b 000a e353 000b 1a00 32a4 e308
0000120 3000 e340 2000 e3a0 2000 e583 32a0 e308
0000130 3000 e340 3000 e593 2001 e283 32a0 e308
0000140 3000 e340 2000 e583 001f ea00 32a0 e308
0000150 3000 e340 2000 e593 32a4 e308 3000 e340
0000160 3000 e593 0005 e55b 1007 e3a0 ffae ebff
0000170 32a4 e308 3000 e340 3000 e593 2001 e283
0000180 32a4 e308 3000 e340 2000 e583 32a4 e308
0000190 3000 e340 3000 e593 004f e353 000a da00
00001a0 32a4 e308 3000 e340 2000 e3a0 2000 e583
00001b0 32a0 e308 3000 e340 3000 e593 2001 e283
00001c0 32a0 e308 3000 e340 2000 e583 32a0 e308
00001d0 3000 e340 3000 e593 0018 e353 0003 da00
00001e0 32a0 e308 3000 e340 2000 e3a0 2000 e583
00001f0 f000 e320 d004 e24b b000 e59d d004 e28d
0000200 f004 e49d b008 e52d e004 e58d b004 e28d
0000210 d008 e24d 0008 e50b 0005 ea00 3008 e51b
0000220 2001 e283 2008 e50b 3000 e5d3 0003 e1a0
0000230 ffb0 ebff 3008 e51b 3000 e5d3 0000 e353
0000240 fff5 1aff f000 e320 f000 e320 d004 e24b
0000250 b000 e59d d004 e28d f004 e49d b008 e52d
0000260 e004 e58d b004 e28d 0280 e308 0000 e340
0000270 ffe3 ebff f003 e320 fffd eaff 0000 2000
0000280 6548 6c6c 206f 7266 6d6f 7620 7269 7574
0000290 6c61 4320 5452 6b20 7265 656e 216c 000a
00002a0