:\min-kernel-2>arm-none-eabi-objdump -d start.o

start.o:     file format elf32-littlearm


Disassembly of section .text:

00000000 <_start>:
   0:   e3e0d23e        mvn     sp, #-536870909 ; 0xe0000003
   4:   e59fe008        ldr     lr, [pc, #8]    ; 14 <halt_loop+0x8>
   8:   ebfffffe        bl      0 <kmain>

0000000c <halt_loop>:
   c:   e320f003        wfi
  10:   eafffffd        b       c <halt_loop>
  14:   0000000c        .word   0x0000000c