/* kernel_crt.c - Minimal kernel using virtual CRT */
#include <stdint.h>

#define CRT_ROWS 25
#define CRT_COLS 80
#define CRT_BASE 0x0A000000

typedef struct {
    uint8_t ch;
    uint8_t attr;
} crt_cell_t;

volatile crt_cell_t* const crt = (crt_cell_t*) CRT_BASE;

int cursor_row = 0;
int cursor_col = 0;

void crt_putc_at(char c, uint8_t attr, int row, int col) {
    if (row >= 0 && row < CRT_ROWS && col >= 0 && col < CRT_COLS) {
        crt[row * CRT_COLS + col].ch = c;
        crt[row * CRT_COLS + col].attr = attr;
    }
}

void crt_putc(char c) {
    if (c == '\n') {
        cursor_col = 0;
        cursor_row++;
    } else {
        crt_putc_at(c, 0x07, cursor_row, cursor_col);
        cursor_col++;
        if (cursor_col >= CRT_COLS) {
            cursor_col = 0;
            cursor_row++;
        }
    }
    if (cursor_row >= CRT_ROWS) {
        cursor_row = 0; // no scrolling for now
    }
}

void crt_puts(const char* str) {
    while (*str) crt_putc(*str++);
}

void kmain(void) {
    crt_puts("Hello from virtual CRT kernel!\n");
    __asm__ volatile(".word 0xDEADBEEF");
}