import subprocess
import os

VM = "arm-vm.exe"
SCRIPT = "test_crt.script"
LOG = "test_crt.log"

def run_test():
    print("Running test_crt...")

    if not os.path.exists(SCRIPT):
        print(f"❌ Missing script: {SCRIPT}")
        return False

    # Run the emulator
    try:
        result = subprocess.run(
            [VM],
            stdin=open(SCRIPT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10
        )
    except subprocess.TimeoutExpired:
        print("❌ Emulator timed out")
        return False

    if not os.path.exists(LOG):
        print("❌ Log file not found")
        return False

    with open(LOG) as f:
        log_data = f.read()

    # Define expected debug outputs
    checks = [
        ("Registers shown", "r0  = 0x00000000"),
        ("CRT write A", "mem8[0x0a000000] <= 0x41"),
        ("CRT write B", "mem8[0x0a000002] <= 0x42"),
        ("CRT write C", "mem8[0x0a000004] <= 0x43"),
        ("Reached DEADBEEF", "PC=0x0000801C Instr=0xDEADBEEF"),
        ("Halt message", "[HALT] Reached DEADBEEF sentinel. Halting VM."),
    ]

    passed = True
    for label, expect in checks:
        if expect in log_data:
            print(f"  ✅ {label}")
        else:
            print(f"  ❌ {label} missing")
            passed = False

    print("test_crt:", "✅ passed" if passed else "❌ failed")
    return passed

if __name__ == "__main__":
    result = run_test()
    print("\nSummary:", "1 passed, 0 failed" if result else "0 passed, 1 failed")