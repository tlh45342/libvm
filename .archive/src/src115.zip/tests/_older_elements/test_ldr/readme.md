O:\arm-vm\test-cases\test_ldr>arm-none-eabi-objdump.exe -d test_ldr.elf

test_ldr.elf:     file format elf32-littlearm


Disassembly of section .text:

00008000 <_start>:
    8000:       e59f001c        ldr     r0, [pc, #28]   ; 8024 <end+0x4>
    8004:       e59f1018        ldr     r1, [pc, #24]   ; 8024 <end+0x4>
    8008:       e1500001        cmp     r0, r1
    800c:       1a000000        bne     8014 <test_failed>
    8010:       ea000001        b       801c <test_passed>

00008014 <test_failed>:
    8014:       e3a02001        mov     r2, #1
    8018:       ea000000        b       8020 <end>

0000801c <test_passed>:
    801c:       e3a02000        mov     r2, #0

00008020 <end>:
    8020:       deadbeef        .word   0xdeadbeef
    8024:       cafebabe        .word   0xcafebabe