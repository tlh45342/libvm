#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdbool.h>

#define VERSION "0.0.87"
#define RAM_SIZE (512 * 1024 * 1024)
#define ENTRY_POINT 0x8000
#define UART_BASE 0x09000000
#define UART_DR   0x00

#define CRT_BASE   0x0A000000  // 160MB (just above UART)
#define CRT_ROWS 25
#define CRT_COLS 80
#define CRT_SIZE (CRT_ROWS * CRT_COLS * 2)
#define MAX_CYCLES 1000000

bool trace_all = true;

#define MAX_BACKTRACE 64
uint32_t call_stack[MAX_BACKTRACE];
int call_depth = 0;
bool cpu_halted = false;

typedef enum {
    DBG_NONE        = 0,
    DBG_INSTR       = 1 << 0,  // Instruction decode
    DBG_MEM_READ    = 1 << 1,  // Memory read access
    DBG_MEM_WRITE   = 1 << 2,  // Memory write access
    DBG_STACK       = 1 << 3,  // Stack-specific access
    DBG_REG         = 1 << 4,  // Register set/read
    DBG_ALL         = 0xFFFFFFFF
} DebugFlags;

DebugFlags debug_flags = DBG_NONE;

struct arm_cpu {
    uint32_t r[16];
    uint32_t cpsr;
};

uint64_t cycle = 0;

uint8_t *ram;
struct arm_cpu cpu;

FILE* log_file = NULL;

// ----------

void execute_line(char* line);
void show_crt(void);  
bool execute(uint32_t instr);
void load_binary(const char* path, uint32_t addr);
void dump_backtrace(void);
uint8_t read_mem8(uint32_t addr);
void write_mem8(uint32_t addr, uint8_t val);
void start_log(const char* filename);
void stop_log(void);
void log_printf(const char* fmt, ...);

// ----- logging -----

void start_log(const char* filename) {
    if (log_file) fclose(log_file);  // Close any existing log file
    log_file = fopen(filename, "w");
    if (!log_file) {
        perror("Failed to open log file");
        exit(1);
    }
}

void stop_log(void) {
    if (log_file) {
        fclose(log_file);
        log_file = NULL;
    }
}

// Wrapper: sends output to both file and console
void log_printf(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    if (log_file) {
        vfprintf(log_file, fmt, args);
        fflush(log_file);  // Ensure it's written
    }
    vprintf(fmt, args);  // Console output too
    va_end(args);
}

// ----------

void examine_memory(uint32_t start, uint32_t end) {
    if (start >= RAM_SIZE || end >= RAM_SIZE || start > end) {
        log_printf("[ERROR] Invalid memory range 0x%08x - 0x%08x\n", start, end);
        return;
    }

    for (uint32_t addr = start; addr <= end; addr += 16) {
        log_printf("0x%08x: ", addr);
        for (int i = 0; i < 16 && (addr + i) <= end; i++) {
            log_printf("%02x ", ram[addr + i]);
        }
        log_printf(" |");
        for (int i = 0; i < 16 && (addr + i) <= end; i++) {
            uint8_t c = ram[addr + i];
           log_printf("%c", (c >= 32 && c < 127) ? c : '.');
        }
        log_printf("|\n");
    }
}

static inline uint32_t ror(uint32_t val, int r) {
    return (val >> r) | (val << (32 - r));
}

void dump_registers() {
    printf("Registers:\n");
    for (int i = 0; i < 16; i++) {
        log_printf("r%-2d = 0x%08x  ", i, cpu.r[i]);
        if ((i + 1) % 4 == 0) log_printf("\n");
    }
}

uint32_t fetch_instruction() {
    uint32_t pc = cpu.r[15];
    if (pc >= RAM_SIZE - 4) {
        fprintf(stderr, "[ERROR] PC out of range: 0x%08x\n", pc);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xDEADDEAD;
    }
    uint8_t *p = ram + pc;
    uint32_t instr = p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
    cpu.r[15] += 4;
    return instr;
}

void write_uart(uint8_t val) {
    putchar(val);
    fflush(stdout);
}

void show_crt() {
    printf("\n==== CRT OUTPUT ====\n");
    for (int row = 0; row < CRT_ROWS; row++) {
        for (int col = 0; col < CRT_COLS; col++) {
            uint32_t offset = CRT_BASE + (row * CRT_COLS + col) * 2;
            char ch = ram[offset];
            putchar((ch >= 32 && ch < 127) ? ch : '.');
        }
        printf("\n");
    }
    printf("====================\n");
}

uint8_t read_mem8(uint32_t addr) {
    if (addr >= UART_BASE && addr < UART_BASE + 0x1000)
        return 0;

    if (addr >= RAM_SIZE) {
        fprintf(stderr, "Read8 out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
        cpu_halted = true;
        return 0xFF;
    }

    return ram[addr];
}

uint32_t read_mem32(uint32_t addr) {
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "[ERROR] Read out of bounds: 0x%08x\n", addr);
        dump_registers();
        dump_backtrace();
       cpu_halted = true;
       return 0xDEADDEAD;
   }
   return *(uint32_t*)(ram + addr);  // ✅ FIX: perform the actual read
}

void write_mem8(uint32_t addr, uint8_t val) {
    if (addr == UART_BASE + UART_DR) {
        write_uart(val);
        return;
    }
    if (addr >= RAM_SIZE) {
        fprintf(stderr, "Write8 out of bounds: 0x%08x\n", addr);
        exit(1);
    }

    *(uint8_t*)(ram + addr) = val;

    if (debug_flags & DBG_INSTR) {
        log_printf("  [STRB] mem8[0x%08x] <= 0x%02x\n", addr, val);
    }
}

void write_mem32(uint32_t addr, uint32_t val) {
    if (addr == UART_BASE + UART_DR) {
        write_uart(val & 0xFF);
        return;
    }
    if (addr >= RAM_SIZE - 4) {
        fprintf(stderr, "Write out of bounds: 0x%08x\n", addr);
        exit(1);
    }

    *(uint32_t*)(ram + addr) = val;

    // Optional: dump only if in DEBUG mode
    if (debug_flags & DBG_INSTR) {
        log_printf("  [STR] mem[0x%08x] <= 0x%08x\n", addr, val);
    }
}

bool handle_mov(uint32_t instr) {
    // MOV (register) format: Rd = Rm
    //  |cond|00|I|0100|S| Rn | Rd |0000|0000| Rm |
    // Simplified detection assumes I == 0 and standard format

    uint8_t rd = (instr >> 12) & 0xf;
    uint8_t rm = instr & 0xf;

    cpu.r[rd] = cpu.r[rm];

    if (debug_flags & DBG_INSTR) {
        log_printf("  [MOV] r%d = r%d (0x%08x)\n", rd, rm, cpu.r[rd]);
    }

    return true;
}

bool handle_add(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rn = (instr >> 16) & 0xf;
    int imm = instr & 0xfff;
    cpu.r[rd] = cpu.r[rn] + imm;
    if (trace_all) log_printf("  [ADD] r%d = r%d + 0x%x => 0x%08x\n", rd, rn, imm, cpu.r[rd]);
    return true;
}

bool handle_ldrb_reg(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf;
    uint8_t rd = (instr >> 12) & 0xf;
    uint32_t addr = cpu.r[rn];

    uint8_t byte = read_mem8(addr);  // ✅ Safe access with bounds check

    cpu.r[rd] = byte;

    if (trace_all || (debug_flags & DBG_MEM_READ)) {
        log_printf("  [LDRB reg] r%d = mem[0x%08x] => 0x%02x\n", rd, addr, byte);
    }

    return true;
}

bool handle_sub(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t imm = instr & 0xFFF;

    cpu.r[rd] = cpu.r[rn] - imm;

    if ((rd == 13 || rn == 13) && (debug_flags & DBG_INSTR)) {
        printf("  [SUB] SP adjustment: r13 = r13 - 0x%x => 0x%08x\n", imm, cpu.r[13]);
    } else if (debug_flags & DBG_INSTR) {
        printf("  [SUB imm] r%d = r%d (0x%08x) - 0x%x => 0x%08x\n",
               rd, rn, cpu.r[rn], imm, cpu.r[rd]);
    }

    return true;
}

bool handle_mov_imm(uint32_t instr) {
    if (debug_flags & DBG_INSTR) {
        printf("  [DEBUG] Inside handle_mov_imm: instr = 0x%08x\n", instr);
    }

    if ((instr & 0x0ff00000) != 0x03a00000) {
        if (debug_flags & DBG_INSTR) {
            log_printf("  [DEBUG] MOV IMM check failed: instr & 0x0ff00000 = 0x%08x\n", instr & 0x0ff00000);
        }
        return false;
    }

    int rd = (instr >> 12) & 0xF;
    uint32_t imm8 = instr & 0xFF;
    int rotate = ((instr >> 8) & 0xF) * 2;
    uint32_t imm = (rotate == 0) ? imm8 : ror(imm8, rotate);

    cpu.r[rd] = imm;

    if (debug_flags & DBG_INSTR) {
        log_printf("  [MOV imm] r%d = 0x%08x\n", rd, imm);
    }

    return true;
}

bool handle_ldr_literal(uint32_t instr) {
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;
    uint32_t addr = (cpu.r[15] - 4 + 8) + offset;  // ✅ Fix: adjust for PC already advanced

    if (debug_flags & DBG_INSTR) {
        log_printf("  [LDR literal] r%d = mem[0x%08x]\n", rd, addr);
    }

    cpu.r[rd] = read_mem32(addr);
    return true;
}

bool handle_str_predec(uint32_t instr) {
    int rd = (instr >> 12) & 0xf;
    int rn = (instr >> 16) & 0xf;
    int offset = instr & 0xfff;
    cpu.r[rn] -= offset;
    write_mem32(cpu.r[rn], cpu.r[rd]);
    if (trace_all) {
        log_printf("  [mem write] mem[0x%08x] <= 0x%08x\n", cpu.r[rn], cpu.r[rd]);
        log_printf("  [STR pre-dec] mem[SP=0x%08x] = r%d (0x%08x)\n", cpu.r[rn], rd, cpu.r[rd]);
    }
    return true;
}

bool evaluate_condition(uint8_t cond) {
    bool N = (cpu.cpsr >> 31) & 1;
    bool Z = (cpu.cpsr >> 30) & 1;
    bool C = (cpu.cpsr >> 29) & 1;
    bool V = (cpu.cpsr >> 28) & 1;

    switch (cond) {
        case 0x0: return Z;                // EQ
        case 0x1: return !Z;               // NE
        case 0x2: return C;                // CS
        case 0x3: return !C;               // CC
        case 0x4: return N;                // MI
        case 0x5: return !N;               // PL
        case 0x6: return V;                // VS
        case 0x7: return !V;               // VC
        case 0x8: return C && !Z;          // HI
        case 0x9: return !C || Z;          // LS
        case 0xA: return N == V;           // GE
        case 0xB: return N != V;           // LT
        case 0xC: return !Z && (N == V);   // GT
        case 0xD: return Z || (N != V);    // LE
        case 0xE: return true;             // AL (Always)
        default: return false;             // NV or undefined
    }
}

bool handle_b(uint32_t instr) {
    uint32_t pc = cpu.r[15] - 4;  // actual address of current instruction
    uint32_t pc_effective = pc + 8;  // ARM PC-relative base
    int32_t offset = (int32_t)(instr & 0x00FFFFFF);
    if (offset & 0x00800000) {
        offset |= 0xFF000000;  // sign-extend 24-bit to 32-bit
    }
    offset <<= 2;

    uint8_t cond = (instr >> 28) & 0xF;
    uint32_t target = pc_effective + offset;

    static const char *cond_names[16] = {
        "EQ", "NE", "CS", "CC", "MI", "PL", "VS", "VC",
        "HI", "LS", "GE", "LT", "GT", "LE", "AL", "NV"
    };

    bool taken = evaluate_condition(cond);

    log_printf("[Cycle %08u] PC=0x%08X Instr=0x%08X\n", cycle, pc, instr);
    log_printf("  [B] Condition: 0x%X (%s)\n", cond, cond_names[cond]);
    log_printf("      Offset:    0x%08X\n", offset);
    log_printf("      PC base:   0x%08X (PC+8)\n", pc_effective);
    log_printf("      Target:    0x%08X\n", target);

    if (taken) {
        log_printf("      Branch TAKEN\n");
        cpu.r[15] = target;
    } else {
        log_printf("      Branch SKIPPED\n");
        log_printf("      Fallthrough: 0x%08X (PC+4)\n", pc + 4);
        // Leave cpu.r[15] unchanged; already PC + 8
    }
	
    return true;
}

bool handle_strb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf; // base register
    uint8_t rd = (instr >> 12) & 0xf; // source register
    uint32_t offset = instr & 0xfff;  // 12-bit immediate
    bool up = instr & (1 << 23);      // U bit
    bool pre = instr & (1 << 24);     // P bit

    uint32_t addr = cpu.r[rn];
    if (pre) {
        addr = up ? addr + offset : addr - offset;
    }

    uint8_t val = cpu.r[rd] & 0xFF;
    write_mem8(addr, val);

    if (debug_flags & DBG_INSTR) {
        log_printf("  [STRB pre-%s imm] mem[0x%08x] <= r%d (byte=0x%02x)\n",
               up ? "inc" : "dec", addr, rd, val);
    }

    return true;
}

bool handle_strb_postimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xF;  // base register
    uint8_t rd = (instr >> 12) & 0xF;  // source register
    uint32_t offset = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint8_t byte = cpu.r[rd] & 0xFF;

    write_mem8(addr, byte);  // ✅ use proper memory write

    cpu.r[rn] += offset;     // ✅ post-increment

    if (debug_flags & DBG_INSTR) {
        log_printf("  [STRB post-imm] mem[0x%08x] <= r%d (byte=0x%02x); r%d += 0x%x => 0x%08x\n",
               addr, rd, byte, rn, offset, cpu.r[rn]);
    }

    return true;
}

bool handle_bl(uint32_t instr) {
    // BL <label>  --> Branch with Link
    // Encoding: cond | 1011 | offset (24 bits)
    int32_t offset = instr & 0x00FFFFFF;

    // Sign-extend 24-bit offset to 32-bit signed value
    if (offset & 0x00800000)
        offset |= 0xFF000000;

    offset <<= 2;  // Shift left by 2 per ARM encoding

    // Calculate effective PC as (PC at fetch) + 8
    uint32_t fetch_pc = cpu.r[15] - 4;
    uint32_t pc_effective = fetch_pc + 8;
    uint32_t target = pc_effective + offset;

    // Store return address in LR (PC of next instruction)
    cpu.r[14] = cpu.r[15];

    if (debug_flags & DBG_INSTR) {
        log_printf("[BL] Decode: instr=0x%08X\n", instr);
        log_printf("     fetch PC = 0x%08X\n", fetch_pc);
        log_printf("     raw offset = 0x%06X\n", instr & 0x00FFFFFF);
        log_printf("     sign-extended offset = 0x%08X\n", offset);
        log_printf("     effective PC (PC+8) = 0x%08X\n", pc_effective);
        log_printf("     computed target = 0x%08X\n", target);
        log_printf("     return address (LR) = 0x%08X\n", cpu.r[14]);
    }

    // Branch to target
    cpu.r[15] = target;
    return true;
}

bool handle_str_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf; // base register (e.g., SP)
    uint8_t rd = (instr >> 12) & 0xf; // source register to store
    uint32_t offset = instr & 0xfff;  // 12-bit immediate offset
    bool up = instr & (1 << 23);      // U bit (1 = add, 0 = subtract)
    bool pre = instr & (1 << 24);     // P bit (1 = pre-indexing)

    uint32_t addr = cpu.r[rn];
    if (pre) {
        addr = up ? addr + offset : addr - offset;
    }

    write_mem32(addr, cpu.r[rd]);

    if (debug_flags & DBG_INSTR) {
        log_printf("  [STR pre-%s imm] mem[0x%08x] <= r%d (0x%08x)\n",
               up ? "inc" : "dec", addr, rd, cpu.r[rd]);
    }

    return true;
}
bool handle_cmp_reg(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rm = instr & 0xF;

    uint32_t op1 = cpu.r[rn];
    uint32_t op2 = cpu.r[rm];
    uint32_t result = op1 - op2;

    // Set flags: N (bit 31), Z (bit 30)
    bool negative = (result >> 31) & 1;
    bool zero = (result == 0);

    // Clear N and Z bits
    cpu.cpsr &= ~((1 << 31) | (1 << 30));

    // Set N and Z as appropriate
    if (negative) cpu.cpsr |= (1 << 31);
    if (zero)     cpu.cpsr |= (1 << 30);

    if (debug_flags & DBG_INSTR) {
        log_printf("  [CMP reg] r%d (0x%08x) - r%d (0x%08x) => 0x%08x  [N=%d Z=%d]\n",
               rn, op1, rm, op2, result, negative, zero);
    }

    return true;
}

bool handle_add_imm(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xf;
    uint8_t rn = (instr >> 16) & 0xf;
    uint32_t imm = instr & 0xfff;  // simplified case: immediate form

    uint32_t result = cpu.r[rn] + imm;
    cpu.r[rd] = result;

    if (debug_flags & DBG_INSTR) {
        log_printf("  [ADD imm] r%d = r%d (0x%08x) + 0x%x => 0x%08x\n",
               rd, rn, cpu.r[rn], imm, result);
    }

    return true;
}

bool handle_movw(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xf;
    uint16_t imm4 = (instr >> 16) & 0xf;
    uint16_t imm12 = instr & 0xfff;
    uint32_t imm16 = (imm4 << 12) | imm12;

    cpu.r[rd] = (cpu.r[rd] & 0xffff0000) | imm16;

    if (debug_flags & DBG_INSTR) {
        log_printf("  [MOVW] r%d = 0x%08x (imm4=0x%x, imm12=0x%x)\n",
               rd, cpu.r[rd], imm4, imm12);
    }

    return true;
}

bool handle_cmp_imm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf;
    uint32_t imm = instr & 0xfff;

    uint32_t result = cpu.r[rn] - imm;

    // Set N (bit 31) and Z (bit 30) flags in cpsr
    if (result == 0)
        cpu.cpsr |= (1 << 30);  // Set Z
    else
        cpu.cpsr &= ~(1 << 30); // Clear Z

    if (result & 0x80000000)
        cpu.cpsr |= (1 << 31);  // Set N
    else
        cpu.cpsr &= ~(1 << 31); // Clear N

    if (debug_flags & DBG_INSTR) {
        log_printf("  [CMP imm] r%d (0x%08x) - 0x%08x => 0x%08x  [N=%d Z=%d]\n",
               rn, cpu.r[rn], imm, result,
               !!(cpu.cpsr & (1 << 31)),  // N flag
               !!(cpu.cpsr & (1 << 30))); // Z flag
    }

    return true;
}

bool handle_ldrb_preimm(uint32_t instr) {
    uint8_t rn = (instr >> 16) & 0xf;        // Base register
    uint8_t rd = (instr >> 12) & 0xf;        // Destination register
    uint32_t offset = instr & 0xfff;         // 12-bit immediate
    bool up = instr & (1 << 23);             // U bit
    bool pre = instr & (1 << 24);            // P bit
    bool writeback = instr & (1 << 21);      // W bit

    uint32_t addr = cpu.r[rn];
    if (pre) {
        addr = up ? addr + offset : addr - offset;
    }

    uint8_t val = read_mem8(addr);
    cpu.r[rd] = val;

    if (writeback || !pre) {
        cpu.r[rn] = addr;
    }

    if (debug_flags & DBG_INSTR) {
        log_printf("  [LDRB pre-%s%s imm] r%d = mem8[0x%08x] => 0x%02x\n",
               up ? "inc" : "dec",
               writeback ? "!" : "",
               rd, addr, val);
    }

    return true;
}

bool handle_stm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back = (instr >> 21) & 1;
    uint32_t base = cpu.r[rn];

    int count = __builtin_popcount(reglist);
    uint32_t addr = base - count * 4;

    if (debug_flags & DBG_INSTR) {
        log_printf("[STM] Store Multiple from r%d base=0x%08X write_back=%d\n",
                   rn, base, write_back);
        log_printf("      Register list: ");
        for (int i = 0; i < 16; i++) {
            if (reglist & (1 << i)) {
                log_printf("r%d ", i);
            }
        }
        log_printf("\n");
    }

    for (int i = 0; i < 16; i++) {
        if (reglist & (1 << i)) {
            if (debug_flags & DBG_MEM_WRITE) {
                log_printf("    [MEM] mem[0x%08X] <- r%d (0x%08X)\n", addr, i, cpu.r[i]);
            }
            write_mem32(addr, cpu.r[i]);
            addr += 4;
        }
    }

    if (write_back) {
        cpu.r[rn] = base - count * 4;
        if (debug_flags & DBG_INSTR) {
            log_printf("      r%d updated (write-back) => 0x%08X\n", rn, cpu.r[rn]);
        }
    }

    return true;
}

bool handle_ldmfd_sp_pc(__attribute__((unused)) uint32_t instr) {
    uint32_t addr = cpu.r[13];
    uint32_t ret = read_mem32(addr);

    if (ret < 0x8000 || ret >= RAM_SIZE) {
        printf("  [ERROR] Invalid return address 0x%08x from LDMFD!\n", ret);
        dump_registers();
        return false;
    }

    cpu.r[15] = ret;
    cpu.r[13] += 4;  // Only one register: pc

    if (trace_all)
        printf("  [LDMFD] PC <= mem[SP]=0x%08x; SP += 4 => 0x%08x\n", ret, cpu.r[13]);

    if (call_depth > 0) call_depth--;

    return true;
}

bool handle_ldr_preimm(uint32_t instr) {
	if ((instr & 0x0ff00000) == 0x05100000) {
        int rn = (instr >> 16) & 0xf;
        int rd = (instr >> 12) & 0xf;
        uint32_t offset = instr & 0xfff;
        bool u = instr & (1 << 23);
        uint32_t addr = cpu.r[rn];

        addr = u ? addr + offset : addr - offset;
        uint32_t val = read_mem32(addr);
        cpu.r[rd] = val;

        if (debug_flags & DBG_INSTR) {
            printf("  [LDR pre-%s imm] r%d = mem[0x%08x] => 0x%08x\n",
                   u ? "inc" : "dec", rd, addr, val);
        }

        return true;
    }
    return false;
}

bool handle_pop(uint32_t instr) {
    uint32_t reglist = instr & 0xffff;
    uint32_t addr = cpu.r[13];
    for (int i = 0; i < 16; i++) {
        if (reglist & (1 << i)) {
            uint32_t val = read_mem32(addr);
            if (i == 15) {
                if (val < 0x8000 || val >= RAM_SIZE) {
                    printf("  [ERROR] Invalid return address 0x%08x\n", val);
                    dump_registers();
                    return false;
                }
                cpu.r[15] = val;
                if (call_depth > 0) call_depth--;
                if (trace_all)
                    printf("  [POP] PC <= 0x%08x\n", val);
            } else {
                cpu.r[i] = val;
                if (trace_all)
                    printf("  [POP] r%d <= 0x%08x\n", i, val);
            }
            addr += 4;
        }
    }
    cpu.r[13] = addr;
    return true;
}

bool handle_sub_sp_imm(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xF;
    uint8_t rn = (instr >> 16) & 0xF;
    uint32_t imm = instr & 0xFFF;

    if (rd == 13 && rn == 13) {  // SUB SP, SP, #imm
        cpu.r[13] -= imm;

        if (debug_flags & DBG_INSTR) {
            log_printf("  [SUB] SP adjustment: r13 = r13 - 0x%x => 0x%08x\n", imm, cpu.r[13]);
        }
        return true;
    }

    // Other forms of SUB can be handled here or ignored
    return false;
}

bool handle_nop(uint32_t instr) {
    if (instr == 0xe1a00000) {  // MOV r0, r0
        if (debug_flags & DBG_INSTR) {
            log_printf("  [NOP]\n");
        }
        return true;
    }
    return false;
}

bool handle_wfi(__attribute__((unused)) uint32_t instr) {
    if (debug_flags & DBG_INSTR) {
        log_printf("  [WFI] Wait for interrupt (simulated pause).\n");
    }

    // Simulate a pause, but don't halt the VM completely.
    // You could optionally add a "paused" flag or just return true here.
    return true;
}

bool handle_movt(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xF;
    uint32_t imm4 = (instr >> 16) & 0xF;
    uint32_t imm12 = instr & 0xFFF;
    uint32_t imm = (imm4 << 12) | imm12;
    cpu.r[rd] = (cpu.r[rd] & 0xFFFF) | (imm << 16);

    if (debug_flags & DBG_INSTR) {
        log_printf("  [MOVT] r%d = 0x%08x (imm4=0x%x, imm12=0x%03x)\n", rd, cpu.r[rd], imm4, imm12);
    }

    return true;
}

bool handle_pop_pc(uint32_t instr) {
    int imm = instr & 0xfff;
    uint32_t ret = read_mem32(cpu.r[13]);

    if (trace_all)
        log_printf("  [stack read]  PC <= mem[SP=0x%08x] = 0x%08x\n", cpu.r[13], ret);

    // 🔴 Add check: return address must be valid
    if (ret < 0x8000 || ret >= RAM_SIZE) {
        log_printf("  [ERROR] Invalid return address 0x%08x from stack!\n", ret);
        dump_registers();
        return false;
    }

    cpu.r[15] = ret;
    cpu.r[13] += imm;

    if (call_depth > 0) {
        call_depth--;
    }

    if (trace_all)
        log_printf("  [LDR post] PC <= mem[SP]=0x%08x; SP += 0x%x => 0x%08x\n", cpu.r[15], imm, cpu.r[13]);

    return true;
}

void dump_backtrace() {
    log_printf("Backtrace (%d calls):\n", call_depth);
    for (int i = call_depth - 1; i >= 0; i--) {
        log_printf("  #%d 0x%08x\n", i, call_stack[i]);
    }
}

bool handle_ldm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t reglist = instr & 0xFFFF;
    bool write_back = (instr >> 21) & 1;
    uint32_t addr = cpu.r[rn];

    for (int i = 0; i < 16; i++) {
        if (reglist & (1 << i)) {
            uint32_t val = read_mem32(addr);    // ✅ capture the loaded value
            cpu.r[i] = val;                      // ✅ store into register

            if (debug_flags & DBG_MEM_READ) {
                printf("  [LDM] r%d <= mem[0x%08x] => 0x%08x\n", i, addr, val);  // ✅ use correct vars
            }

            addr += 4;
        }
    }

    if (write_back)
        cpu.r[rn] = addr;

    return true;
}

bool handle_ldrb_post_imm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t offset = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint8_t val = read_mem8(addr);
    cpu.r[rd] = val;

    if (DBG_MEM_READ)
        log_printf("  [LDRB post-imm] r%d = mem[0x%08x] => 0x%02x\n", rd, addr, val);

    cpu.r[rn] += offset;
    cpu.r[15] += 4;

    return true;  // ✅ fixes the warning
}

bool handle_add_reg(uint32_t instr) {
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rm = instr & 0xF;
    cpu.r[rd] = cpu.r[rn] + cpu.r[rm];
    if (debug_flags & DBG_INSTR) {
        log_printf("  [ADD reg] r%d = r%d + r%d => 0x%08X\n", rd, rn, rm, cpu.r[rd]);
    }
	
	return true;
}

bool handle_ldrb_postimm(uint32_t instr) {
    uint32_t rn = (instr >> 16) & 0xF;
    uint32_t rd = (instr >> 12) & 0xF;
    uint32_t imm = instr & 0xFFF;  // 12-bit immediate
    uint32_t addr = cpu.r[rn];

    uint8_t value = read_mem8(addr);
    cpu.r[rd] = value;

    // ✅ FIXED: post-increment base register
    cpu.r[rn] += imm;

    if (debug_flags & DBG_INSTR) {
        log_printf("  [LDRB post-imm] r%d = mem[0x%08x] => 0x%02x\n",
               rd, addr, value);
    }

    return true;
}

bool handle_bx(uint32_t instr) {
    int rm = instr & 0xF;
    uint32_t addr = cpu.r[rm];

    if (debug_flags & DBG_INSTR) {
        log_printf("  [BX] Branch to 0x%08x (r%d)\n", addr, rm);
    }

    cpu.r[15] = addr;
    return true;
}

bool handle_ldr_postimm(uint32_t instr) {
    uint8_t rd = (instr >> 12) & 0xF;
    uint8_t rn = (instr >> 16) & 0xF;
    uint32_t imm = instr & 0xFFF;

    uint32_t addr = cpu.r[rn];
    uint32_t val = read_mem32(addr);
    cpu.r[rd] = val;
    cpu.r[rn] += imm;

    if (debug_flags & DBG_INSTR || trace_all) {
        log_printf("  [LDR post-imm] r%d = mem[0x%08x] => 0x%08x; ", rd, addr, val);
        log_printf("r%d += 0x%x => 0x%08x\n", rn, imm, cpu.r[rn]);
    }

    if (debug_flags & DBG_MEM_READ) {
        log_printf("  [MEM READ] mem[0x%08x] => 0x%08x (LDR)\n", addr, val);
    }

    return true;
}

void execute_script(const char* filename) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        perror("fopen");
        return;
    }

    char buf[256];
    while (fgets(buf, sizeof(buf), f)) {
        // Remove newline
        buf[strcspn(buf, "\r\n")] = 0;

        // Skip blank or comment lines
        char* trimmed = buf;
        while (*trimmed == ' ' || *trimmed == '\t') trimmed++; // skip leading whitespace

        if (*trimmed == '\0' || *trimmed == ';') {
            continue;  // blank line or comment
        }

        printf(">> %s\n", buf);
        execute_line(trimmed);
    }

    fclose(f);
}

void execute_line(char* line) {
    // First: strip out comments (semicolon to end-of-line) unless inside quotes
    char* p = line;
    bool in_quotes = false;
    while (*p) {
        if (*p == '"') {
            in_quotes = !in_quotes;
        } else if (*p == ';' && !in_quotes) {
            *p = '\0';  // strip the comment
            break;
        }
        p++;
    }

    // Skip leading whitespace
    while (*line == ' ' || *line == '\t') line++;

    if (*line == '\0') return;  // Blank or comment-only line

    // Tokenize command
    char* cmd = strtok(line, " \t\r\n");
    if (!cmd || cmd[0] == '#') return;

    if (strcmp(cmd, "load") == 0) {
        char* path = strtok(NULL, " \t\r\n");
        char* addr_str = strtok(NULL, " \t\r\n");
        if (!path || !addr_str) {
            printf("Usage: load <file> <addr>\n");
            return;
        }
        uint32_t addr = strtoul(addr_str, NULL, 0);
        load_binary(path, addr);
        printf("Loaded %s at 0x%08x\n", path, addr);
    }

    else if (strcmp(cmd, "run") == 0) {
        cpu_halted = false;
		cycle = 0;
        while (!cpu_halted) {
            uint32_t instr = fetch_instruction();
            execute(instr);
			cycle++;
        }
    }

    else if (strcasecmp(cmd, "e") == 0 || strcasecmp(cmd, "examine") == 0) {
        char* range = strtok(NULL, " \t\r\n");
        if (!range) {
            printf("Usage: e <start>-<end> or e <start> <end>\n");
            return;
        }

        uint32_t start = 0, end = 0;
        char* dash = strchr(range, '-');
        if (dash) {
            *dash = '\0';
            start = strtoul(range, NULL, 0);
            end = strtoul(dash + 1, NULL, 0);
        } else {
            char* end_str = strtok(NULL, " \t\r\n");
            if (!end_str) {
                printf("Usage: e <start>-<end> or e <start> <end>\n");
                return;
            }
            start = strtoul(range, NULL, 0);
            end = strtoul(end_str, NULL, 0);
        }

        examine_memory(start, end);
    }

    else if (strcmp(cmd, "set") == 0) {
        char* arg1 = strtok(NULL, " \t\r\n");
        char* arg2 = strtok(NULL, " \t\r\n");

        // set cpu debug=XXX
        if (arg1 && arg2 &&
            strcasecmp(arg1, "cpu") == 0 &&
            strncasecmp(arg2, "debug=", 6) == 0) {

            const char* level = arg2 + 6;

            if (strcasecmp(level, "all") == 0) {
                debug_flags = DBG_ALL;
                trace_all = true;
            } else if (strcasecmp(level, "none") == 0) {
                debug_flags = DBG_NONE;
                trace_all = false;
            } else if (strcasecmp(level, "instruction") == 0) {
                debug_flags = DBG_INSTR;
            } else if (strcasecmp(level, "read") == 0) {
                debug_flags = DBG_MEM_READ;
            } else if (strcasecmp(level, "write") == 0) {
                debug_flags = DBG_MEM_WRITE;
            } else if (strcasecmp(level, "memory") == 0) {
                debug_flags = DBG_MEM_READ | DBG_MEM_WRITE;
            } else {
                printf("Unknown debug level: %s\n", level);
                return;
            }

            printf("[DEBUG] debug_flags set to 0x%08x\n", debug_flags);
            return;
        }

        // fallback: set rX Y
        if (!arg1 || !arg2 || arg1[0] != 'r') {
            printf("Usage: set r<regnum> <value>\n");
            return;
        }

        int regnum = atoi(arg1 + 1);
        if (regnum < 0 || regnum > 15) {
            printf("Invalid register: %s\n", arg1);
            return;
        }

        cpu.r[regnum] = strtoul(arg2, NULL, 0);
        printf("Set r%d = 0x%08x\n", regnum, cpu.r[regnum]);
    }

	else if (strcmp(cmd, "do") == 0) {
		char* script_path = strtok(NULL, " \t\r\n");
		if (!script_path) {
			log_printf("Usage: do <scriptfile>\n");
			return;
		}

		FILE* f = fopen(script_path, "r");
		if (!f) {
			log_printf("Could not open script file: %s\n", script_path);
			return;
		}

		char buf[256];
		while (fgets(buf, sizeof(buf), f)) {
			// Trim newline and print to console/log
			buf[strcspn(buf, "\r\n")] = '\0';
			log_printf(">> %s\n", buf);
			execute_line(buf);
		}

		fclose(f);
	}

    else if (strcmp(cmd, "step") == 0) {
        char* count_str = strtok(NULL, " \t\r\n");
        int steps = count_str ? atoi(count_str) : 1;
        if (steps <= 0) {
            printf("Step count must be positive.\n");
            return;
        }
        cpu_halted = false;
        for (int i = 0; i < steps && !cpu_halted; i++) {
            uint32_t instr = fetch_instruction();
            execute(instr);
			cycle++;
        }
    }

    else if (strcmp(cmd, "bt") == 0) {
        dump_backtrace();
    }

    else if (strcmp(cmd, "regs") == 0) {
        dump_registers();
    }

    else if (strcmp(cmd, "show") == 0) {
        char* what = strtok(NULL, " \t\r\n");
        if (!what) {
            printf("Usage: show <crt>\n");
        } else if (strcasecmp(what, "crt") == 0) {
            show_crt();
        } else {
            printf("Unknown show target: %s\n", what);
        }
    }

	else if (strcmp(cmd, "logfile") == 0) {
		char* filename = strtok(NULL, " \t\r\n");
		if (!filename) {
			printf("Usage: logfile <filename>\n");
			return;
		}
		if (log_file && log_file != stdout) {
			fclose(log_file);
		}
		log_file = fopen(filename, "w");
		if (!log_file) {
			printf("Failed to open logfile: %s\n", filename);
			log_file = stdout;
		} else {
			printf("Logging to %s\n", filename);
		}
	}

    else if (strcmp(cmd, "version") == 0) {
		log_printf("VERSION %s\n", VERSION);
    }

	else if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
		exit(0);
	}

    else {
        printf("Unknown command: %s\n", cmd);
    }
}

bool execute(uint32_t instr) {

    uint32_t pc = cpu.r[15] - 4;

    if (debug_flags & DBG_INSTR)
        log_printf("[Cycle %08d] PC=0x%08X Instr=0x%08X\n", cycle, pc, instr);

    if (instr == 0xDEADBEEF) {
        if (debug_flags & DBG_INSTR) {
            log_printf("  [HALT] Reached DEADBEEF sentinel. Halting VM.\n");     
        }
        cpu_halted = true;
        return false;
    }

	if ((instr & 0x0ff00000) == 0x03e00000) {
		int rd = (instr >> 12) & 0xf;
		uint32_t imm8 = instr & 0xff;
		int rotate = ((instr >> 8) & 0xf) * 2;
		uint32_t imm = (imm8 >> rotate) | (imm8 << (32 - rotate));
		cpu.r[rd] = ~imm;
		if (DBG_INSTR) log_printf("[MVN imm] r%d = ~0x%08x => 0x%08x\n", rd, imm, cpu.r[rd]);
		return true;
	}

	if ((instr & 0x0ff00000) == 0x01500000) {
		return handle_cmp_reg(instr);
	}

	// Handle ARM HINT instructions
	if (instr == 0xe320f000) return handle_nop(instr);  // NOP
	if (instr == 0xe320f003) return handle_wfi(instr);  // WFI

	if ((instr & 0x0fe00000) == 0x01a00000 && ((instr >> 21) & 0xf) == 0xd) {
		return handle_mov(instr);
	}

	uint32_t P = (instr >> 24) & 0x1;
	uint32_t W = (instr >> 21) & 0x1;
	uint32_t L = (instr >> 20) & 0x1;
	uint32_t B = (instr >> 22) & 0x1;

	// Handles: LDRB rX, [rY], #imm  (post-indexed, W = 1)
	if ((instr & 0x0e500000) == 0x04500000 && P == 0 && W == 1 && L == 1 && B == 1)
		return handle_ldrb_post_imm(instr);

	// Handles: LDRB rX, [rY], #imm  (post-indexed, W = 0) ← this is what your test needs
	if ((instr & 0x0e500000) == 0x04500000 && P == 0 && W == 0 && L == 1 && B == 1)
		return handle_ldrb_postimm(instr);

    if ((instr & 0x0fff0000) == 0x059f0000)
        return handle_ldr_literal(instr);

    if ((instr & 0x0e000000) == 0x08000000) {
        if (instr & (1 << 20))
            return handle_ldm(instr);
        else
            return handle_stm(instr);
    }

	if ((instr & 0x0e500000) == 0x04100000)
		return handle_ldr_postimm(instr);

	if ((instr & 0xFFF00FF0) == 0xE4C00000) {
		return handle_strb_postimm(instr);
	}

	if ((instr & 0x0FE00010) == 0x00800000) {
		return handle_add_reg(instr);  // ✅ Fix: return the result!
	}

    if ((instr & 0xFFFF0000) == 0xE8BD0000) {
        return handle_pop(instr);
	}

    if ((instr & 0xFFF00000) == 0xE2800000) {
        return handle_add(instr);
	}

    if ((instr & 0x0f000000) == 0x0a000000) {
        return handle_b(instr);
	}

    if ((instr & 0x0fe00000) == 0x02400000) {
        return handle_sub(instr);
	}

	if ((instr & 0xFFF000F0) == 0xE5D00000) {
        return handle_ldrb_reg(instr);
	}

    if ((instr & 0x0ff00000) == 0x03500000) {
        return handle_cmp_imm(instr);
	}

    if ((instr & 0x0c400000) == 0x04000000 &&
        (instr & (1 << 20)) && !(instr & (1 << 25)) && (instr & (1 << 24))) {
        return handle_ldr_preimm(instr);
    }

    if ((instr & 0x0ff00000) == 0x03400000)
        return handle_movt(instr);

    if ((instr & 0x0fe00000) == 0x03a00000)
        return handle_mov_imm(instr);

    if ((instr & 0xffff0000) == 0xe52d0000) {
        return handle_str_predec(instr);
	}

    if ((instr & 0xffff0000) == 0xe4c00000) {
        return handle_strb_postimm(instr);
	}

    if ((instr & 0x0ff00000) == 0x03000000) {
        return handle_movw(instr);
	}
	
    if ((instr & 0x0fe00000) == 0x02800000) {
        return handle_add_imm(instr);
	}

    if ((instr & 0x0c500000) == 0x04400000 &&
        !(instr & (1 << 20)) && (instr & (1 << 22)) && (instr & (1 << 24)))
        return handle_strb_preimm(instr);

    if ((instr & 0x0c500000) == 0x04000000 &&
        !(instr & (1 << 20)) && !(instr & (1 << 25)) && (instr & (1 << 24))) {
        return handle_str_preimm(instr);
	}

	if ((instr & 0x0e5f0000) == 0x041f0000) {
		return handle_ldr_postimm(instr);
	}

    if ((instr & 0x0f000000) == 0x0b000000) {
        return handle_bl(instr);
	}
	
    if ((instr & 0x0c500000) == 0x04500000 &&
        (instr & (1 << 20)) && (instr & (1 << 22)) && (instr & (1 << 24))) {
        return handle_ldrb_preimm(instr);
		}

    if ((instr & 0xfffff000) == 0xe49df000) {
        return handle_pop_pc(instr);
	}

	if ((instr & 0x0ffffff0) == 0x012fff10) {
		return handle_bx(instr);
	}

    // 🛑 Unknown instruction fallback
    log_printf("[ERROR] Unknown instruction: 0x%08x at PC=0x%08x\n", instr, pc);
    uint32_t op = (instr >> 24) & 0xF;
    uint32_t subop = (instr >> 20) & 0xF;
    log_printf("  [Not matched] op=0x%x subop=0x%x\n", op, subop);
    cpu_halted = true;
    return false;
}
void load_binary(const char* path, uint32_t addr) {
    FILE* f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "[ERROR] Cannot open file: %s\n", path);    
        cpu_halted = true;
        return;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    fread(ram + addr, 1, size, f);
    fclose(f);
   // write_mem32(RAM_SIZE - 8, 0xDEADDEAD);  // now it's safely within bounds
}

void repl_shell() {
    char line[256];
    // printf("[DEBUG] debug_flags at startup: 0x%08x\n", debug_flags)	;
    while (1) {
        printf("arm-vm> ");
        if (!fgets(line, sizeof(line), stdin)) break;
        execute_line(line);
    }
}

int main(int argc, char* argv[]) {
    if (argc > 1 && strcmp(argv[1], "-V") == 0) {
        printf("ARM VM Emulator %s\n", VERSION);
        return 0;
    }

    ram = calloc(1, RAM_SIZE);
    if (!ram) { perror("calloc"); return 1; }

    memset(&cpu, 0, sizeof(cpu));
    cpu.r[13] = RAM_SIZE - 4; // SP
    cpu.r[15] = ENTRY_POINT;  // PC

    repl_shell();

    free(ram);
    return 0;
}
